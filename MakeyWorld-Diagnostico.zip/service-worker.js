// MakeyWorld v11 service worker: update-safe cache with offline fallback.
const CACHE_NAME = 'makeyworld-v11';
const CORE_ASSETS = ["./assets/icons/icon.svg", "./index.html", "./manifest.json", "./service-worker.js", "./src/assets/asset-manager.js", "./src/core/app.js", "./src/core/commands.js", "./src/core/events.js", "./src/core/history.js", "./src/core/state.js", "./src/core/storage.js", "./src/editor/canvas.js", "./src/editor/inspector.js", "./src/editor/object-editor.js", "./src/editor/scene-editor.js", "./src/editor/selection.js", "./src/editor/transform.js", "./src/editor/workspace.js", "./src/engine/animation.js", "./src/engine/audio.js", "./src/engine/collision.js", "./src/engine/input.js", "./src/engine/physics.js", "./src/engine/renderer.js", "./src/engine/runtime-api.js", "./src/engine/runtime.js", "./src/help/assistant-ui.js", "./src/help/assistant.js", "./src/help/documentation.js", "./src/help/tutorials.js", "./src/logic/blocks.js", "./src/logic/compiler.js", "./src/main.js", "./src/project/exporter.js", "./src/project/importer.js", "./src/project/project-manager.js", "./src/project/serializer.js", "./src/sprite-editor/sprite-editor.js", "./src/ui/dialogs.js", "./src/ui/dom.js", "./src/ui/notifications.js", "./src/ui/panels.js", "./src/ui/shortcuts.js", "./src/ui/toolbar.js", "./styles/animations.css", "./styles/components.css", "./styles/editor.css", "./styles/layout.css", "./styles/main.css", "./styles/responsive.css", "./styles/sprite-editor.css", "./styles/variables.css"];

self.addEventListener('install', event => {
  event.waitUntil((async () => {
    const cache = await caches.open(CACHE_NAME);
    await Promise.all(CORE_ASSETS.map(async asset => {
      try {
        const response = await fetch(asset, { cache: 'reload' });
        if (response.ok) await cache.put(asset, response);
      } catch (error) {
        console.warn('[MakeyWorld] No se pudo precargar:', asset, error);
      }
    }));
    await self.skipWaiting();
  })());
});

self.addEventListener('activate', event => {
  event.waitUntil((async () => {
    const keys = await caches.keys();
    await Promise.all(keys.filter(key => key.startsWith('makeyworld-') && key !== CACHE_NAME).map(key => caches.delete(key)));
    await self.clients.claim();
  })());
});

self.addEventListener('fetch', event => {
  const request = event.request;
  if (request.method !== 'GET') return;
  const url = new URL(request.url);
  if (url.origin !== self.location.origin) return;
  event.respondWith((async () => {
    const cached = await caches.match(request);
    if (cached) return cached;
    try {
      const response = await fetch(request);
      if (response.ok && response.type === 'basic') {
        const cache = await caches.open(CACHE_NAME);
        cache.put(request, response.clone()).catch(() => {});
      }
      return response;
    } catch (error) {
      if (request.mode === 'navigate') {
        const fallback = await caches.match('./index.html');
        if (fallback) return fallback;
      }
      return new Response('Recurso no disponible sin conexión.', { status: 503, headers: { 'Content-Type': 'text/plain; charset=utf-8' } });
    }
  })());
});

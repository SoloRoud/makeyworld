# MakeyWorld — recuperación de sprites y orden de animación (v12)

## Correcciones
- La carga de un sprite existente conserva el PNG aplanado cuando las capas guardadas de versiones anteriores están vacías o transparentes.
- Se mantiene la relación entre cada fotograma y su propia imagen, sin desplazar índices cuando falta un recurso.
- Los objetos con referencias de imagen que no se pueden recuperar bloquean el guardado para evitar sustituir el diseño por un lienzo vacío.
- La carga de imágenes tiene un tiempo límite para evitar que Pixel Studio se quede esperando indefinidamente.
- La vista previa precarga las imágenes de los fotogramas antes de reproducir y evita perder fotogramas por decodificación lenta.
- El motor y la exportación HTML5 reconocen fotogramas guardados como `sprite`, `src`, `dataUrl`, `image`, `assetId`, `asset` y referencias `asset:`.
- Al iniciar o cambiar de escena, las animaciones se reinician mostrando el primer fotograma.

## Reordenación de fotogramas
- Arrastra las miniaturas de la línea de tiempo para cambiar el orden.
- Usa los botones `⇦ Orden` y `Orden ⇨` para mover el fotograma seleccionado.
- Atajos `Alt + ←` y `Alt + →` para reordenar el fotograma actual.
- El orden nuevo se conserva al guardar el sprite y al exportar el juego.
- Añadido deshacer/rehacer para crear, duplicar, eliminar, reordenar y redimensionar fotogramas/canvas.

## Validación
- Sintaxis JavaScript de todos los módulos.
- Pruebas unitarias del cambio de fotograma, reinicio, FPS, bucle y referencias a recursos en el motor.
- Verificación de que la exportación incluye el mismo resolvedor de fotogramas y respeta el orden del array.
# MakeyWorld — sprites recuperables y texto mejorado (v11)

## Correcciones de Pixel Studio
- Corregida la creación de objetos para que los presets conserven todas sus propiedades específicas. Esto evita perder valores iniciales al crear objetos de texto u otros tipos especiales.
- Verificado el flujo de edición de un sprite ya asignado/importado: carga la imagen existente, permite guardarla y vuelve a abrirla sin vaciar el lienzo.
- Verificada la compatibilidad con animaciones antiguas cuyos fotogramas solo contienen imágenes y no datos de capas.
- Las capas, opacidad y fotogramas continúan guardándose en el objeto y en el proyecto.
- Se mantiene la protección que bloquea el guardado si la imagen original no se ha podido cargar.

## Mejoras de texto
- Añadidos estilos rápidos: título, subtítulo, texto normal y etiqueta pequeña.
- Añadido autoajuste de anchura, además de autoaltura.
- Las palabras muy largas y las URL sin espacios se parten para no salirse del cuadro.
- Los objetos de texto pueden mostrar a la vez un sprite de fondo y el texto por encima.
- El motor del editor y la exportación HTML5 mantienen el mismo ajuste de texto multilínea.

## Pruebas realizadas en Chromium
- Apertura, guardado y reapertura de sprites existentes/importados, comprobando píxeles y capas.
- Apertura de animaciones heredadas de dos fotogramas sin metadatos de capas.
- Guardado y reapertura de animaciones nuevas con capas por fotograma.
- Autoaltura, autoancho, presets tipográficos, texto multilínea y cadenas largas sin espacios.
- Exportación HTML5 y ejecución del contenido exportado sin errores de JavaScript.
- Comprobación de sintaxis, imports y archivos del Service Worker.

# MakeyWorld — mejoras de Pixel Studio y edición (v9)

## Pixel Studio
- Al abrir Pixel Studio desde un objeto seleccionado, carga su sprite actual en lugar de empezar con un lienzo vacío.
- Si el objeto ya tiene animación, carga sus fotogramas, FPS y modo de repetición.
- Los fotogramas se guardan en `object.animation.frames` y se reproducen en el modo Play.
- La exportación HTML5 también reproduce las animaciones guardadas.
- Añadidos vista previa, control de FPS, bucle, miniaturas de fotogramas, eliminar fotograma y herramienta de elipse.
- Añadidos deshacer/rehacer de las operaciones de dibujo y capas.
- Redimensionar el lienzo conserva todos los fotogramas.

## Editor de escenas
- Copiar uno o varios objetos con `Ctrl+C` y pegarlos con `Ctrl+V`.
- Añadidos botones Copiar y Pegar a la barra del escenario.
- `Ctrl+A` selecciona todos los objetos visibles de la escena.
- Las flechas mueven los objetos seleccionados 1 píxel; `Shift` + flechas los mueve 10 píxeles.
- La duplicación y el pegado asignan identificadores nuevos a objetos y reglas lógicas.

## Comprobaciones realizadas
- Sintaxis de los 41 módulos JavaScript.
- Resolución de todos los imports relativos.
- Correspondencia de los archivos JavaScript/CSS con el precache del Service Worker.
- Pruebas de la lógica de animación, del runtime, de copiar/pegar/duplicar y de sintaxis del HTML5 exportado.

La prueba visual interactiva en Chromium no se pudo completar en este entorno porque sus políticas administradas bloquean todas las direcciones (`URLBlocklist: *`). Conviene probar esta versión en el Chromebook después de publicarla.


## v10 — sprites estables y texto enriquecido
- Corregida la referencia a `record()` al guardar sprites, que impedía aplicar los cambios al objeto.
- El cargador de Pixel Studio reconoce sprites en datos URL, rutas y referencias a recursos del proyecto; si el original no se puede leer, bloquea el guardado para evitar sobrescribirlo con un lienzo vacío.
- Añadidos voltear horizontal/vertical, limpiar capa y atajos de herramientas en Pixel Studio.
- Los textos ahora admiten varias líneas, ajuste automático, tamaño, fuente, negrita, cursiva, alineación, contorno y fondo.
- El motor del editor y el HTML exportado comparten el mismo comportamiento de texto.

- La versión actual conserva las capas separadas de cada fotograma entre sesiones; añade recuperación desde la imagen original si faltan datos de una capa.
- Añadidas opciones de interlineado y margen interno para cajas de texto.

# MakeyWorld — mejoras de Pixel Studio y edición (v9)

## Pixel Studio
- Al abrir Pixel Studio desde un objeto seleccionado, carga su sprite actual en lugar de empezar con un lienzo vacío.
- Si el objeto ya tiene animación, carga sus fotogramas, FPS y modo de repetición.
- Los fotogramas se guardan en `object.animation.frames` y se reproducen en el modo Play.
- La exportación HTML5 también reproduce las animaciones guardadas.
- Añadidos vista previa, control de FPS, bucle, miniaturas de fotogramas, eliminar fotograma y herramienta de elipse.
- Añadidos deshacer/rehacer de las operaciones de dibujo y capas.
- Redimensionar el lienzo conserva todos los fotogramas.

## Editor de escenas
- Copiar uno o varios objetos con `Ctrl+C` y pegarlos con `Ctrl+V`.
- Añadidos botones Copiar y Pegar a la barra del escenario.
- `Ctrl+A` selecciona todos los objetos visibles de la escena.
- Las flechas mueven los objetos seleccionados 1 píxel; `Shift` + flechas los mueve 10 píxeles.
- La duplicación y el pegado asignan identificadores nuevos a objetos y reglas lógicas.

## Comprobaciones realizadas
- Sintaxis de los 41 módulos JavaScript.
- Resolución de todos los imports relativos.
- Correspondencia de los archivos JavaScript/CSS con el precache del Service Worker.
- Pruebas de la lógica de animación, del runtime, de copiar/pegar/duplicar y de sintaxis del HTML5 exportado.

La prueba visual interactiva en Chromium no se pudo completar en este entorno porque sus políticas administradas bloquean todas las direcciones (`URLBlocklist: *`). Conviene probar esta versión en el Chromebook después de publicarla.

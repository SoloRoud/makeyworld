# MakeyWorld

**Your ideas. Your world. Your game.**

MakeyWorld es un estudio de videojuegos 2D que funciona en el navegador. Está construido con HTML, CSS y JavaScript modular (ES Modules), sin Node.js, npm, Linux, claves API ni backend obligatorio.

## Abrir MakeyWorld

MakeyWorld utiliza módulos JavaScript, así que debe abrirse desde una dirección web (`https://` o un servidor local). No abras `index.html` directamente con `file://`.

La opción más sencilla para un Chromebook es publicar la carpeta en un alojamiento estático, por ejemplo GitHub Pages. También funciona en cualquier hosting estático HTTPS.

## Funciones incluidas en esta versión (v11)

- Pantalla de inicio, creación de proyectos y plantillas Plataformas, Top-down, Puzles y Vacío.
- Editor de escenas con lienzo Canvas, cuadrícula, ajuste, selección, movimiento, selección múltiple, copiar/pegar, duplicado, borrado y ajuste fino con las flechas.
- Jerarquía de escenas y objetos, inspector de propiedades y componentes básicos de física.
- Motor Canvas 2D con cámara fija, sprites estáticos y animados, formas, texto multilínea con ajuste, autoaltura, autoancho, estilos rápidos (título, subtítulo, cuerpo y etiqueta), tamaño, fuente, peso, cursiva, alineación, contorno y fondo, movimiento, gravedad, salto, colisiones AABB y enemigos sencillos.
- Monedas, variables y reglas visuales de contacto (sumar variables, restar vidas, ocultar objetos, sonido, mensaje y cambio de escena).
- Makey Pixel Studio con lápiz, goma, relleno, cuentagotas, línea, rectángulo, elipse, capas persistentes por fotograma, reordenación y volteo de capas, opacidad, deshacer/rehacer, vista previa con FPS y bucle, edición segura de sprites existentes e importación/exportación PNG/spritesheet, compatibilidad con animaciones antiguas y capas persistentes.
- Importación de recursos y almacenamiento de los archivos dentro del proyecto.
- Makey Code: scripts JavaScript con una API básica para objetos, jugador, variables, entrada, audio, escenas y consola.
- Guardado manual y automático con IndexedDB (fallback a LocalStorage), deshacer/rehacer e importación/exportación `.mwproject`.
- Exportación de un HTML5 autónomo para el escenario activo.
- PWA con caché para uso sin conexión después de la primera carga, cuando el navegador lo permita.

## Controles de juego

- Izquierda: `A` o `←`.
- Derecha: `D` o `→`.
- Saltar: `Espacio`, `W` o `↑` (en proyectos con gravedad).
- Movimiento vertical: `WASD` o flechas en un jugador con gravedad desactivada.

## Atajos del editor

- `Ctrl + S`: guardar.
- `Ctrl + Z`: deshacer.
- `Ctrl + Y` o `Ctrl + Shift + Z`: rehacer.
- `Ctrl + A`: seleccionar todos los objetos visibles de la escena.
- `Ctrl + C` / `Ctrl + V`: copiar y pegar uno o varios objetos.
- `Ctrl + D`: duplicar selección.
- `Flechas`: mover la selección 1 píxel; `Shift + Flechas`: mover 10 píxeles.
- `Supr`: eliminar selección.
- `F5`: ejecutar.
- `Esc`: detener el juego.
- `F2`: renombrar el objeto seleccionado.

## API de Makey Code

Los scripts activados se ejecutan durante el modo Play. Ejemplo:

```javascript
function update(deltaTime) {
  if (input.isDown("ArrowRight")) {
    player.move(1, 0);
  }
  if (input.isPressed("Space")) {
    player.jump();
  }
  api.variables.puntos = (api.variables.puntos || 0) + 0;
}
```

También están disponibles `api.objects.get("Nombre")`, `api.scene.change("Escena 2")`, `api.audio.beep(660, 0.1)`, `api.log("Mensaje")` y `api.create("coin", 100, 100)`.

## Límites de esta versión

Esta entrega implementa una primera versión funcional y una ruta de creación de principio a fin, no todos los sistemas de un motor comercial. Todavía no incluye un editor de nodos libre con conexiones, autotiling, editor completo de UI, física poligonal/circular, cámara con seguimiento y zoom, audio importado asignable por eventos, curvas de animación, ni exportación de proyectos con motor multiarchivo. La exportación HTML5 actual es autónoma y funcional para el conjunto de funciones básicas indicado arriba.

Los proyectos permanecen en el almacenamiento del navegador. Exporta `.mwproject` periódicamente para tener una copia que puedas mover entre dispositivos.

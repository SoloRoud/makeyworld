import { state } from '../core/state.js';
import { undo, redo } from '../core/history.js';
import { removeSelected, duplicateSelected } from '../core/commands.js';
import { events } from '../core/events.js';
let currentHandlers = null;
let installed = false;
function onKeyDown(e) {
  const handlers = currentHandlers; if (!handlers) return;
  const mod = e.ctrlKey || e.metaKey;
  if (mod && e.key.toLowerCase() === 's') { e.preventDefault(); handlers.save?.(); }
  else if (mod && e.key.toLowerCase() === 'z') { e.preventDefault(); undo(); }
  else if (mod && e.key.toLowerCase() === 'y') { e.preventDefault(); redo(); }
  else if (mod && e.key.toLowerCase() === 'd') { e.preventDefault(); duplicateSelected(); }
  else if ((e.key === 'Delete' || e.key === 'Backspace') && !['INPUT', 'TEXTAREA'].includes(document.activeElement.tagName)) { if (state.selectedIds.length) { e.preventDefault(); removeSelected(); } }
  else if (e.key === 'F5') { e.preventDefault(); handlers.play?.(); }
  else if (e.key === 'Escape' && state.running) handlers.stop?.();
  else if (e.key === 'F2' && state.selected[0]) { const name = prompt('Nombre del objeto:', state.selected[0].name); if (name) { state.selected[0].name = name; state.touch('Objeto renombrado'); events.emit('selection:changed', state.selected); } }
}
export function installShortcuts(handlers) { currentHandlers = handlers; if (!installed) { window.addEventListener('keydown', onKeyDown); installed = true; } }
export function clearShortcuts() { currentHandlers = null; }

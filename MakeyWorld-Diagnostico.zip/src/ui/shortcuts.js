import { state } from '../core/state.js';
import { undo, redo, record } from '../core/history.js';
import { removeSelected, duplicateSelected, copySelected, pasteCopied } from '../core/commands.js';
import { events } from '../core/events.js';

let currentHandlers = null;
let installed = false;

function editingText() {
  const active = document.activeElement;
  return !!active && (['INPUT', 'TEXTAREA', 'SELECT'].includes(active.tagName) || active.isContentEditable);
}

function onKeyDown(event) {
  const handlers = currentHandlers;
  if (!handlers) return;
  const mod = event.ctrlKey || event.metaKey;
  const key = event.key.toLowerCase();
  const textFocus = editingText();

  if (mod && key === 's') { event.preventDefault(); handlers.save?.(); return; }
  if (mod && key === 'z' && !textFocus) { event.preventDefault(); if (event.shiftKey) redo(); else undo(); return; }
  if (mod && key === 'y' && !textFocus) { event.preventDefault(); redo(); return; }
  if (textFocus) return;
  if (mod && key === 'a' && state.scene) { event.preventDefault(); state.select(state.scene.objects.filter(object => object.visible !== false).map(object => object.id)); return; }
  if (mod && key === 'c') {
    if (copySelected()) event.preventDefault();
  } else if (mod && key === 'v') {
    if (pasteCopied().length) event.preventDefault();
  } else if (mod && key === 'd') { event.preventDefault(); duplicateSelected(); }
  else if ((event.key === 'Delete' || event.key === 'Backspace') && state.selectedIds.length) { event.preventDefault(); removeSelected(); }
  else if (event.key === 'F5') { event.preventDefault(); handlers.play?.(); }
  else if (event.key === 'Escape' && state.running) handlers.stop?.();
  else if (event.key === 'F2' && state.selected[0]) {
    const name = prompt('Nombre del objeto:', state.selected[0].name);
    if (name?.trim()) {
      state.selected[0].name = name.trim();
      state.touch('Objeto renombrado');
      events.emit('selection:changed', state.selected);
    }
  } else if (['ArrowLeft', 'ArrowRight', 'ArrowUp', 'ArrowDown'].includes(event.key) && state.selected.length) {
    event.preventDefault();
    const amount = event.shiftKey ? 10 : 1;
    const dx = event.key === 'ArrowLeft' ? -amount : event.key === 'ArrowRight' ? amount : 0;
    const dy = event.key === 'ArrowUp' ? -amount : event.key === 'ArrowDown' ? amount : 0;
    const movable = state.selected.filter(object => !object.locked);
    if (!movable.length) return;
    record('Mover objetos con teclado');
    for (const object of movable) { object.x += dx; object.y += dy; }
    state.touch('Objetos movidos');
  }
}

export function installShortcuts(handlers) {
  currentHandlers = handlers;
  if (!installed) {
    window.addEventListener('keydown', onKeyDown);
    installed = true;
  }
}

export function clearShortcuts() { currentHandlers = null; }

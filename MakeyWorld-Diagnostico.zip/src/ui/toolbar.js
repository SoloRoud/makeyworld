import { state } from '../core/state.js';
import { undo, redo, canUndo, canRedo } from '../core/history.js';
import { addObject, removeSelected, duplicateSelected } from '../core/commands.js';
import { saveProject } from '../core/storage.js';
import { exportProject, exportHTML } from '../project/exporter.js';
import { openSpriteEditor } from '../sprite-editor/sprite-editor.js';
import { toast } from './dom.js';
import { events } from '../core/events.js';

export function bindToolbar(root, { onPlay, onPause, onStop, onHelp, onHome }) {
  root.querySelector('[data-save]').onclick = async () => {
    try {
      await saveProject(state.project);
      state.dirty = false;
      events.emit('saved');
      toast('Proyecto guardado.', 'success');
    } catch (error) { toast(error.message, 'error'); }
  };
  root.querySelector('[data-undo]').onclick = () => undo();
  root.querySelector('[data-redo]').onclick = () => redo();
  root.querySelectorAll('[data-add-object]').forEach(button => button.onclick = () => addObject(button.dataset.addObject));
  root.querySelector('[data-sprite]').onclick = () => openSpriteEditor();
  root.querySelector('[data-delete]').onclick = () => removeSelected();
  root.querySelector('[data-duplicate]').onclick = () => duplicateSelected();
  root.querySelector('[data-play]').onclick = onPlay;
  root.querySelector('[data-pause]').onclick = onPause;
  root.querySelector('[data-stop]').onclick = onStop;
  root.querySelector('[data-export-project]').onclick = () => exportProject(state.project);
  root.querySelector('[data-export-html]').onclick = () => exportHTML(state.project);
  root.querySelector('[data-help]').onclick = onHelp;
  root.querySelector('[data-home]').onclick = onHome;
  root.querySelector('[data-grid]').onclick = event => {
    state.grid = !state.grid;
    event.currentTarget.classList.toggle('selected', state.grid);
    events.emit('scene:changed', state.scene);
  };
  root.querySelector('[data-snap]').onclick = event => {
    state.snap = !state.snap;
    event.currentTarget.classList.toggle('selected', state.snap);
  };
  root.querySelector('[data-zoom]').onchange = event => {
    state.zoom = Number(event.target.value);
    events.emit('resolution:changed');
  };
  const offHistory = events.on('history:changed', () => {
    const undoButton = root.querySelector('[data-undo]');
    const redoButton = root.querySelector('[data-redo]');
    if (undoButton) undoButton.disabled = !canUndo();
    if (redoButton) redoButton.disabled = !canRedo();
  });
  const undoButton = root.querySelector('[data-undo]');
  const redoButton = root.querySelector('[data-redo]');
  if (undoButton) undoButton.disabled = !canUndo();
  if (redoButton) redoButton.disabled = !canRedo();
  return offHistory;
}

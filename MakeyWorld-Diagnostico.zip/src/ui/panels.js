import { state } from '../core/state.js';
import { renderSceneList } from '../editor/scene-editor.js';
import { renderObjectList } from '../editor/object-editor.js';
import { renderInspector } from '../editor/inspector.js';
import { renderAssets } from '../assets/asset-manager.js';
import { events } from '../core/events.js';
import { esc } from './dom.js';
import { record } from '../core/history.js';

export function renderLeft(root) {
  const sceneBox = root.querySelector('[data-scenes]');
  const objectsBox = root.querySelector('[data-objects]');
  const assetsBox = root.querySelector('[data-assets]');
  if (!sceneBox || !objectsBox || !assetsBox) return;
  renderSceneList(sceneBox);
  renderObjectList(objectsBox);
  renderAssets(assetsBox);
  for (const tab of root.querySelectorAll('[data-left-tab]')) {
    tab.classList.toggle('active', tab.dataset.leftTab === state.leftTab);
  }
  sceneBox.hidden = state.leftTab !== 'scene';
  objectsBox.hidden = state.leftTab !== 'objects';
  assetsBox.hidden = state.leftTab !== 'assets';
}

export function renderRight(root) {
  const inspector = root.querySelector('.inspector');
  if (inspector) renderInspector(inspector);
}

export function renderDock(root, logs) {
  const content = root.querySelector('[data-dock-content]');
  if (!content) return;
  root.querySelectorAll('[data-dock-tab]').forEach(button => {
    button.classList.toggle('active', button.dataset.dockTab === state.bottomTab);
  });

  if (state.bottomTab === 'console') {
    content.innerHTML = `<div class="dock-log">${logs.map(item => `<div class="${item.type === 'error' ? 'bad' : item.type === 'success' ? 'good' : ''}">[${esc(item.time)}] ${esc(item.message)}</div>`).join('') || 'MakeyWorld listo. Aquí aparecerán los mensajes del motor y los errores.'}</div>`;
    return;
  }

  if (state.bottomTab === 'variables') {
    const variables = state.project.variables || (state.project.variables = {});
    content.innerHTML = `<div class="field-row">${Object.entries(variables).map(([key, value]) => `<div class="field"><label>${esc(key)}</label><input data-variable="${esc(key)}" value="${esc(value)}"></div>`).join('')}</div><button class="btn small" data-new-variable>＋ Nueva variable</button>`;
    content.querySelectorAll('[data-variable]').forEach(input => input.onchange = () => {
      const key = input.dataset.variable;
      const oldValue = variables[key];
      if (String(oldValue) === input.value) return;
      record('Editar variable');
      const numeric = input.value.trim() !== '' && Number.isFinite(Number(input.value));
      variables[key] = numeric ? Number(input.value) : input.value;
      state.touch('Variable editada');
    });
    content.querySelector('[data-new-variable]').onclick = () => {
      const name = prompt('Nombre de la variable:');
      if (!name || !name.trim() || Object.hasOwn(variables, name.trim())) return;
      record('Crear variable');
      variables[name.trim()] = 0;
      state.touch('Variable creada');
      renderDock(root, logs);
    };
    return;
  }

  if (state.bottomTab === 'scripts') {
    const savedScript = state.project.scripts?.[0] || null;
    const script = savedScript || {
      id: 'script_main', name: 'main.js',
      code: '// Se ejecuta una vez por fotograma.\nfunction update(deltaTime) {\n  if (input.isDown("ArrowRight")) player.move(1, 0);\n}',
      enabled: true
    };
    content.innerHTML = `<div style="display:flex;gap:7px;align-items:center;margin-bottom:6px"><strong>${esc(script.name)}</strong><span class="muted tiny">JavaScript · Makey Code</span><label class="muted tiny" style="margin-left:auto"><input type="checkbox" data-script-enabled ${script.enabled ? 'checked' : ''}> Activar en Play</label><button class="btn small" data-save-script>Guardar script</button></div><textarea class="code-area" spellcheck="false" data-code>${esc(script.code)}</textarea>`;
    const persistScript = reason => {
      const code = content.querySelector('[data-code]').value;
      const enabled = content.querySelector('[data-script-enabled]').checked;
      const current = state.project.scripts?.[0];
      if (current && current.code === code && current.enabled === enabled) return;
      record(reason);
      const target = current || { id: 'script_main', name: 'main.js' };
      target.code = code;
      target.enabled = enabled;
      if (!state.project.scripts) state.project.scripts = [];
      if (!state.project.scripts.length) state.project.scripts.push(target);
      state.touch(reason);
    };
    content.querySelector('[data-save-script]').onclick = () => persistScript('Guardar script');
    content.querySelector('[data-script-enabled]').onchange = () => persistScript('Cambiar estado del script');
    return;
  }

  if (state.bottomTab === 'logic') {
    const object = state.selected[0];
    content.innerHTML = object
      ? `<div style="display:flex;align-items:center;gap:8px;margin-bottom:8px"><strong>Lógica de ${esc(object.name)}</strong><span class="pill">${(object.logic || []).length} reglas</span></div>${(object.logic || []).map(rule => `<div class="logic-rule"><div class="rule-title">CUANDO · ${rule.event === 'touch-player' ? 'El jugador toca este objeto' : esc(rule.event)}</div><div>ENTONCES · ${{'add-variable':'Sumar variable','subtract-life':'Restar vida','destroy-object':'Ocultar objeto','play-sound':'Reproducir sonido','show-message':'Mostrar mensaje','change-scene':'Cambiar escena'}[rule.action] || esc(rule.action)}</div><div class="tiny muted">${esc(rule.variable || '')} ${rule.value ?? ''}</div></div>`).join('') || '<div class="empty-state">Este objeto todavía no tiene reglas. Añade una desde el Inspector.</div>'}`
      : '<div class="empty-state">Selecciona un objeto para ver sus bloques de lógica.</div>';
    return;
  }

  content.innerHTML = '<div class="muted">Selecciona un objeto para ver sus comportamientos en el Inspector.</div>';
}

export function bindPanels(root, logs) {
  const off = [];
  root.querySelectorAll('[data-left-tab]').forEach(button => button.onclick = () => {
    state.leftTab = button.dataset.leftTab;
    renderLeft(root);
  });
  root.querySelectorAll('[data-dock-tab]').forEach(button => button.onclick = () => {
    state.bottomTab = button.dataset.dockTab;
    renderDock(root, logs);
  });
  off.push(events.on('scene:changed', () => {
    renderLeft(root);
    if (state.bottomTab === 'logic') renderDock(root, logs);
  }));
  off.push(events.on('selection:changed', () => {
    renderLeft(root);
    renderRight(root);
    if (state.bottomTab === 'logic') renderDock(root, logs);
  }));
  off.push(events.on('assets:changed', () => renderLeft(root)));
  off.push(events.on('project:changed', () => {
    renderLeft(root);
    renderRight(root);
    renderDock(root, logs);
  }));
  off.push(events.on('inspector:changed', () => renderRight(root)));
  return () => off.splice(0).forEach(dispose => dispose());
}

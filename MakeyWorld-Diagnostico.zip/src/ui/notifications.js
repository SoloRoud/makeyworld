import { toast } from './dom.js';
export const notify=toast;

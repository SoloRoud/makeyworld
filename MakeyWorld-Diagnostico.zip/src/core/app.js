import { listProjects, saveProject, openProject } from '../project/project-manager.js';
import { openCreateDialog, showOpenProjects, importProjectFromFile } from '../ui/dialogs.js';
import { mountWorkspace } from '../editor/workspace.js';
import { installShortcuts, clearShortcuts } from '../ui/shortcuts.js';
import { openHelp } from '../help/assistant-ui.js';
import { toast } from '../ui/dom.js';
import { state } from './state.js';
import { events } from './events.js';

let root;
let autosaveOff = null;
let autosaveTimer = null;
let workspaceControls = null;

export async function startApp(element) {
  root = element;
  await showHome();
}

async function showHome() {
  workspaceControls?.destroy?.();
  workspaceControls = null;
  state.running = false;
  clearShortcuts();
  if (autosaveOff) { autosaveOff(); autosaveOff = null; }
  clearTimeout(autosaveTimer);
  const projects = await listProjects();
  root.innerHTML = `<main class="home-screen"><nav class="home-nav"><div class="brand"><div class="brand-mark">M</div><span>MakeyWorld</span></div><span class="pill">BETA · 1.0</span><div style="margin-left:auto;display:flex;gap:7px"><button class="btn" data-import-project>Importar proyecto</button><button class="btn primary" data-create>＋ Crear proyecto</button></div></nav><section class="home-content"><div class="hero"><div class="eyebrow">Your ideas. Your world. Your game.</div><h1>Tu próximo videojuego<br><span style="color:var(--orange)">empieza aquí.</span></h1><p>Un estudio 2D dentro del navegador. Dibuja sprites, construye escenarios, crea reglas y exporta juegos HTML5, sin instalar programas.</p><button class="btn primary" data-create style="padding:10px 16px">＋ Crear mi primer proyecto</button> <button class="btn" data-open>Abrir proyecto</button></div><div style="display:flex;align-items:center;justify-content:space-between;margin:24px 0 12px"><h2 style="font-size:17px;margin:0">Empezar con MakeyWorld</h2><span class="muted tiny">No requiere cuenta ni claves API</span></div><div class="home-grid"><button class="card home-card" data-create><span class="card-icon">＋</span><strong>Crear proyecto</strong><p>Empieza desde cero o utiliza una plantilla editable.</p></button><button class="card home-card" data-open><span class="card-icon">▧</span><strong>Abrir proyecto</strong><p>Continúa trabajando en un proyecto guardado.</p></button><button class="card home-card" data-templates><span class="card-icon">◇</span><strong>Plantillas</strong><p>Plataformas, top-down, puzles y proyectos vacíos.</p></button><button class="card home-card" data-help><span class="card-icon">ⓘ</span><strong>Makey Assist</strong><p>Tutoriales prácticos para aprender a crear tu juego.</p></button><button class="card home-card" data-import-project><span class="card-icon">⇧</span><strong>Importar proyecto</strong><p>Abre un archivo .mwproject existente.</p></button><button class="card home-card" data-features><span class="card-icon">⚙</span><strong>Qué incluye</strong><p>Editor de escenas, motor Canvas, Pixel Studio y exportación.</p></button></div><div style="display:flex;align-items:center;justify-content:space-between;margin:34px 0 12px"><h2 style="font-size:17px;margin:0">Proyectos recientes</h2><span class="muted tiny">Guardados en este navegador</span></div><div class="project-grid" data-recent>${projects.length ? projects.sort((a,b)=>(b.updatedAt||0)-(a.updatedAt||0)).slice(0,8).map(p=>`<article class="card project-card" data-project="${escapeText(p.id)}"><div class="project-thumb">◈</div><strong>${escapeText(p.name)}</strong><small>${new Date(p.updatedAt||p.createdAt).toLocaleString('es-ES',{dateStyle:'medium'})} · ${p.scenes?.length||0} escenas</small></article>`).join('') : '<div class="muted">Aún no tienes proyectos. Crea uno para empezar.</div>'}</div><footer style="margin-top:45px;padding-top:16px;border-top:1px solid #ffffff12;color:#77818e;font-size:11px">MakeyWorld · Aplicación local para crear y exportar videojuegos 2D · Los proyectos permanecen en tu navegador.</footer></section></main>`;
  root.querySelectorAll('[data-create]').forEach(button => button.onclick = () => openCreateDialog(project => enterEditor(project)));
  root.querySelectorAll('[data-open]').forEach(button => button.onclick = () => showOpenProjects(project => enterEditor(project)));
  root.querySelectorAll('[data-import-project]').forEach(button => button.onclick = () => chooseProjectFile());
  root.querySelectorAll('[data-help]').forEach(button => button.onclick = openHelp);
  root.querySelector('[data-templates]').onclick = () => openCreateDialog(project => enterEditor(project));
  root.querySelector('[data-features]').onclick = () => toast('Incluye editor de escenas, motor Canvas 2D, física básica, lógica de contacto, Pixel Studio, recursos, scripts y exportación HTML5.');
  root.querySelectorAll('[data-project]').forEach(card => card.onclick = async () => {
    try { enterEditor(await openProject(card.dataset.project)); }
    catch (error) { toast(error.message, 'error'); }
  });
}

function escapeText(value) {
  return String(value ?? '').replace(/[&<>"']/g, char => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[char]));
}

function chooseProjectFile() {
  const input = document.createElement('input');
  input.type = 'file';
  input.accept = '.mwproject,.json,application/json';
  input.onchange = () => {
    const file = input.files?.[0];
    if (file) importProjectFromFile(file, project => enterEditor(project));
  };
  input.click();
}

async function enterEditor(project) {
  workspaceControls?.destroy?.();
  workspaceControls = null;
  if (project) state.setProject(project);
  root.innerHTML = '';
  const controls = mountWorkspace(root, {
    onHome: async () => {
      if (state.dirty) {
        try { await saveProject(state.project); }
        catch (error) { toast(error.message, 'error'); }
      }
      await showHome();
    },
    onHelp: openHelp
  });
  workspaceControls = controls;
  const save = async () => {
    try {
      await saveProject(state.project);
      state.dirty = false;
      events.emit('saved');
    } catch (error) { toast(error.message, 'error'); }
  };
  installShortcuts({ save, play: controls.play, stop: controls.stop });
  if (autosaveOff) autosaveOff();
  autosaveOff = events.on('project:dirty', () => {
    clearTimeout(autosaveTimer);
    autosaveTimer = setTimeout(save, 1200);
  });
  events.emit('project:changed', state.project);
  await save();
}

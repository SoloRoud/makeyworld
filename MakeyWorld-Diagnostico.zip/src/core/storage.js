const DB_NAME = 'MakeyWorldDB';
const STORE = 'projects';
let dbPromise;

function openDB() {
  if (!('indexedDB' in window)) {
    return Promise.reject(new Error('IndexedDB no está disponible'));
  }

  if (!dbPromise) {
    dbPromise = new Promise((resolve, reject) => {
      let settled = false;
      const request = indexedDB.open(DB_NAME, 1);

      const finish = (callback, value) => {
        if (settled) return;
        settled = true;
        clearTimeout(timeout);
        callback(value);
      };

      // Evita que la pantalla inicial se quede cargando indefinidamente
      // si otra pestaña mantiene bloqueada la base de datos.
      const timeout = setTimeout(() => {
        finish(reject, new Error('La base de datos está tardando demasiado'));
      }, 2500);

      request.onupgradeneeded = () => {
        const db = request.result;
        if (!db.objectStoreNames.contains(STORE)) {
          db.createObjectStore(STORE, { keyPath: 'id' });
        }
      };

      request.onsuccess = () => {
        const db = request.result;
        if (settled) {
          db.close();
          return;
        }
        db.onversionchange = () => db.close();
        finish(resolve, db);
      };

      request.onerror = () => {
        finish(reject, request.error || new Error('No se pudo abrir la base de datos'));
      };

      request.onblocked = () => {
        finish(reject, new Error('La base de datos está bloqueada por otra pestaña'));
      };
    }).catch(error => {
      // Permite volver a intentarlo en operaciones posteriores.
      dbPromise = null;
      throw error;
    });
  }

  return dbPromise;
}

function readLocalProjects() {
  try {
    return Object.keys(localStorage)
      .filter(key => key.startsWith('mw-project-'))
      .map(key => {
        try { return JSON.parse(localStorage.getItem(key)); }
        catch { return null; }
      })
      .filter(Boolean);
  } catch {
    return [];
  }
}

export async function saveProject(project) {
  project.updatedAt = Date.now();

  try {
    const db = await openDB();
    await new Promise((resolve, reject) => {
      const transaction = db.transaction(STORE, 'readwrite');
      transaction.objectStore(STORE).put(project);
      transaction.oncomplete = resolve;
      transaction.onerror = () => reject(transaction.error);
      transaction.onabort = () => reject(transaction.error || new Error('Guardado cancelado'));
    });
  } catch (error) {
    try {
      localStorage.setItem(`mw-project-${project.id}`, JSON.stringify(project));
    } catch {
      throw new Error('No se ha podido guardar. El almacenamiento del navegador puede estar bloqueado o lleno.');
    }
  }

  try { localStorage.setItem('mw-last-project', project.id); } catch {}
}

export async function listProjects() {
  try {
    const db = await openDB();
    return await new Promise((resolve, reject) => {
      const request = db.transaction(STORE).objectStore(STORE).getAll();
      request.onsuccess = () => resolve(request.result || []);
      request.onerror = () => reject(request.error);
    });
  } catch {
    return readLocalProjects();
  }
}

export async function loadProject(id) {
  try {
    const db = await openDB();
    const result = await new Promise((resolve, reject) => {
      const request = db.transaction(STORE).objectStore(STORE).get(id);
      request.onsuccess = () => resolve(request.result);
      request.onerror = () => reject(request.error);
    });
    if (result) return result;
  } catch {}

  try {
    const raw = localStorage.getItem(`mw-project-${id}`);
    return raw ? JSON.parse(raw) : null;
  } catch {
    return null;
  }
}

export async function deleteProject(id) {
  try {
    const db = await openDB();
    await new Promise((resolve, reject) => {
      const transaction = db.transaction(STORE, 'readwrite');
      transaction.objectStore(STORE).delete(id);
      transaction.oncomplete = resolve;
      transaction.onerror = () => reject(transaction.error);
    });
  } catch {}

  try { localStorage.removeItem(`mw-project-${id}`); } catch {}
}

export function savePreference(key, value) {
  try { localStorage.setItem(`mw-pref-${key}`, JSON.stringify(value)); } catch {}
}

export function getPreference(key, fallback) {
  try {
    const value = localStorage.getItem(`mw-pref-${key}`);
    return value === null ? fallback : JSON.parse(value);
  } catch {
    return fallback;
  }
}

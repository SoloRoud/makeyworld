import { events } from './events.js';
import { state } from './state.js';
const undoStack=[],redoStack=[];let replaying=false;
function snapshot(){return JSON.stringify(state.project);}
export function record(label='Cambio'){if(!state.project||replaying)return;undoStack.push({label,data:snapshot()});if(undoStack.length>60)undoStack.shift();redoStack.length=0;events.emit('history:changed');}
export function undo(){if(!state.project||!undoStack.length)return false;redoStack.push({data:snapshot()});const item=undoStack.pop();replaying=true;state.setProject(JSON.parse(item.data));replaying=false;state.touch(`Deshacer: ${item.label}`);events.emit('history:changed');return true;}
export function redo(){if(!state.project||!redoStack.length)return false;undoStack.push({data:snapshot()});const item=redoStack.pop();replaying=true;state.setProject(JSON.parse(item.data));replaying=false;state.touch('Rehacer');events.emit('history:changed');return true;}
export function canUndo(){return undoStack.length>0}export function canRedo(){return redoStack.length>0}
export function clearHistory(){undoStack.length=0;redoStack.length=0;events.emit('history:changed');}

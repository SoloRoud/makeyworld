import { state, createObject, uid } from './state.js';
import { record } from './history.js';

export function addObject(type, overrides = {}) {
  if (!state.scene) return null;
  record('Añadir objeto');
  const object = createObject(type, overrides);
  state.scene.objects.push(object);
  state.select(object.id);
  state.touch('Objeto añadido');
  return object;
}

export function removeSelected() {
  if (!state.scene || !state.selectedIds.length) return false;
  record('Eliminar objeto');
  state.scene.objects = state.scene.objects.filter(object => !state.selectedIds.includes(object.id));
  state.select([]);
  state.touch('Objeto eliminado');
  return true;
}

export function duplicateSelected() {
  if (!state.scene || !state.selected.length) return [];
  record('Duplicar objeto');
  const copies = state.selected.map(object => ({
    ...structuredClone(object),
    id: uid('obj'),
    name: `${object.name} copia`,
    x: object.x + 18,
    y: object.y + 18
  }));
  state.scene.objects.push(...copies);
  state.select(copies.map(object => object.id));
  state.touch('Objetos duplicados');
  return copies;
}

export function addScene() {
  if (!state.project) return null;
  record('Crear escena');
  const scene = {
    id: uid('scene'),
    name: `Escena ${state.project.scenes.length + 1}`,
    background: state.project.settings.background,
    objects: [],
    logic: []
  };
  state.project.scenes.push(scene);
  state.activeSceneId = scene.id;
  state.project.activeSceneId = scene.id;
  state.select([]);
  state.touch('Escena creada');
  return scene;
}

export function renameScene(id, name) {
  const scene = state.project?.scenes.find(item => item.id === id);
  const cleanName = String(name || '').trim();
  if (!scene || !cleanName || scene.name === cleanName) return false;
  record('Renombrar escena');
  scene.name = cleanName;
  state.touch('Escena renombrada');
  return true;
}

export function deleteScene(id) {
  if (!state.project || state.project.scenes.length <= 1) return false;
  const scene = state.project.scenes.find(item => item.id === id);
  if (!scene) return false;
  record('Eliminar escena');
  state.project.scenes = state.project.scenes.filter(item => item.id !== id);
  if (state.activeSceneId === id) {
    state.activeSceneId = state.project.scenes[0].id;
    state.project.activeSceneId = state.activeSceneId;
  }
  state.select([]);
  state.touch('Escena eliminada');
  return true;
}

export function setActiveScene(id) {
  if (!state.project?.scenes.some(scene => scene.id === id) || state.activeSceneId === id) return false;
  record('Cambiar escena');
  state.activeSceneId = id;
  state.project.activeSceneId = id;
  state.select([]);
  state.touch('Escena cambiada');
  return true;
}

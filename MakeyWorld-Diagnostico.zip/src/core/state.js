import { events } from './events.js';
export const state = {
  project: null, selectedIds: [], activeSceneId: null, leftTab: 'scene', bottomTab: 'console',
  tool: 'select', grid: true, snap: true, zoom: 1, running: false, paused: false,
  dirty: false, mode: 'basic', camera: { x: 0, y: 0 },
  setProject(project) { this.project = project; this.activeSceneId = project.activeSceneId || project.scenes[0]?.id || null; project.activeSceneId=this.activeSceneId; this.selectedIds = []; this.dirty = false; events.emit('project:changed', project); },
  get scene() { return this.project?.scenes.find(s => s.id === this.activeSceneId) || null; },
  get selected() { return this.scene?.objects.filter(o => this.selectedIds.includes(o.id)) || []; },
  select(ids) { this.selectedIds = [...new Set((Array.isArray(ids) ? ids : [ids]).filter(Boolean))]; events.emit('selection:changed', this.selected); },
  touch(reason='Cambio realizado') { this.dirty = true; events.emit('project:dirty', reason); events.emit('scene:changed', this.scene); }
};
export function uid(prefix='mw') { return `${prefix}_${Math.random().toString(36).slice(2,8)}${Date.now().toString(36).slice(-4)}`; }
export function createObject(type='rect', overrides={}) {
  const presets = {
    player: {name:'Jugador',type:'player',x:90,y:210,width:32,height:42,color:'#ff8a24',physics:{enabled:true,gravity:true,solid:true},components:['Sprite','Física','Movimiento']},
    platform: {name:'Plataforma',type:'platform',x:100,y:315,width:180,height:24,color:'#688b65',physics:{enabled:true,gravity:false,solid:true},components:['Sprite','Colisiones']},
    coin: {name:'Moneda',type:'coin',x:230,y:240,width:20,height:20,color:'#ffd34e',physics:{enabled:false,gravity:false,solid:false},components:['Sprite','Coleccionable']},
    enemy: {name:'Enemigo',type:'enemy',x:310,y:280,width:30,height:34,color:'#e96d6d',physics:{enabled:true,gravity:true,solid:true},components:['Sprite','Física','IA básica']},
    text: {name:'Texto',type:'text',x:40,y:40,width:280,height:90,color:'#ffffff',text:'¡Hola, mundo!',fontSize:28,fontFamily:'Arial',fontWeight:'normal',fontStyle:'normal',textAlign:'left',verticalAlign:'middle',lineHeight:1.2,wrap:true,autoFitText:true,autoFitWidth:false,outlineColor:'#111111',outlineWidth:0,textBackground:false,backgroundColor:'#202631',textPadding:6,physics:{enabled:false,gravity:false,solid:false},components:['Texto']},
    rect: {name:'Rectángulo',type:'rect',x:140,y:120,width:64,height:64,color:'#6ba8ff',physics:{enabled:false,gravity:false,solid:false},components:['Sprite']},
    circle: {name:'Círculo',type:'circle',x:220,y:120,width:54,height:54,color:'#62c9a0',physics:{enabled:false,gravity:false,solid:false},components:['Sprite']}
  };
  const p = presets[type] || presets.rect;
  const object = {
    ...structuredClone(p),
    id: uid('obj'),
    rotation: 0,
    opacity: 1,
    visible: true,
    locked: false,
    z: 0,
    components: [...(p.components || [])],
    physics: { ...(p.physics || {}) },
    logic: [],
    script: '',
    ...overrides
  };
  // Clone mutable defaults after applying overrides so objects never share arrays
  // or nested physics/logic values with a preset or with another object.
  object.components = [...(overrides.components ?? p.components ?? [])];
  object.physics = { ...(p.physics || {}), ...(overrides.physics || {}) };
  object.logic = structuredClone(overrides.logic ?? []);
  return object;
}
export function createProject(name='Mi primer juego', options={}) {
  const width=Number(options.width)||1280, height=Number(options.height)||720;
  const floor=createObject('platform',{name:'Suelo',x:0,y:height-70,width,height:70,color:'#4a6d55'});
  const player=createObject('player',{x:100,y:height-150});
  const scene={id:uid('scene'),name:'Escena 1',objects:[floor,player],background:options.background||'#202631',logic:[]};
  return {format:'mwproject',version:1,id:uid('project'),name,createdAt:Date.now(),updatedAt:Date.now(),activeSceneId:scene.id,settings:{width,height,background:options.background||'#202631',orientation:width>=height?'landscape':'portrait',fps:60,gravity:900},variables:{monedas:0,vidas:3,puntos:0},scenes:[scene],assets:[],scripts:[],metadata:{engine:'MakeyWorld 1.0'}};
}

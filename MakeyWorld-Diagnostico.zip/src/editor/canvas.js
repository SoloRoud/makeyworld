import { state } from '../core/state.js';
import { events } from '../core/events.js';
import { record } from '../core/history.js';
import { hitTest } from './selection.js';
import { snapValue } from './transform.js';
import { drawWorld } from '../engine/renderer.js';

let canvas = null;
let wrap = null;
let drag = null;
let dirtyMove = false;
let resizeObserver = null;
const GRID_SIZE = 32;

export function mountCanvas(element) {
  canvas = element;
  wrap = canvas.parentElement;
  drag = null;
  dirtyMove = false;
  state.camera = { x: 0, y: 0 };
  canvas.style.transform = 'translate(0px, 0px)';
  canvas.addEventListener('pointerdown', down);
  canvas.addEventListener('pointermove', move);
  canvas.addEventListener('pointerup', up);
  canvas.addEventListener('pointercancel', up);
  canvas.addEventListener('dblclick', doubleClick);
  window.addEventListener('makey:image-ready', renderCanvas);
  if (typeof ResizeObserver !== 'undefined') {
    resizeObserver = new ResizeObserver(resize);
    resizeObserver.observe(wrap);
  } else {
    window.addEventListener('resize', resize);
  }
  resize();
  renderCanvas();
  return () => {
    resizeObserver?.disconnect();
    resizeObserver = null;
    window.removeEventListener('resize', resize);
    canvas?.removeEventListener('pointerdown', down);
    canvas?.removeEventListener('pointermove', move);
    canvas?.removeEventListener('pointerup', up);
    canvas?.removeEventListener('pointercancel', up);
    canvas?.removeEventListener('dblclick', doubleClick);
    window.removeEventListener('makey:image-ready', renderCanvas);
    canvas = null;
    wrap = null;
    drag = null;
    dirtyMove = false;
  };
}

function resize() {
  if (!canvas || !wrap || !state.project) return;
  const width = state.project.settings.width;
  const height = state.project.settings.height;
  canvas.width = width;
  canvas.height = height;
  const availableWidth = Math.max(120, wrap.clientWidth - 44);
  const availableHeight = Math.max(100, wrap.clientHeight - 44);
  const scale = Math.max(0.1, Math.min(availableWidth / width, availableHeight / height, 1.5) * state.zoom);
  canvas.style.width = `${Math.max(100, width * scale)}px`;
  canvas.style.height = `${Math.max(80, height * scale)}px`;
  renderCanvas();
}

function point(event) {
  const rect = canvas.getBoundingClientRect();
  return {
    x: (event.clientX - rect.left) * canvas.width / Math.max(1, rect.width),
    y: (event.clientY - rect.top) * canvas.height / Math.max(1, rect.height)
  };
}

function objectAt(event) {
  const position = point(event);
  return hitTest(state.scene?.objects || [], position.x, position.y);
}

function doubleClick(event) {
  const object = objectAt(event);
  if (object) {
    state.select(object.id);
    events.emit('object:rename', object);
  }
}

function down(event) {
  if (!state.scene || !canvas) return;
  canvas.setPointerCapture(event.pointerId);
  const position = point(event);
  const object = hitTest(state.scene.objects, position.x, position.y);
  if (state.tool === 'hand') {
    drag = { kind: 'pan', x: event.clientX, y: event.clientY, ox: state.camera.x, oy: state.camera.y };
    return;
  }
  if (!object) {
    if (!event.shiftKey) state.select([]);
    renderCanvas();
    return;
  }
  if (event.shiftKey) {
    state.select([...state.selectedIds, object.id]);
    renderCanvas();
    return;
  }
  if (!state.selectedIds.includes(object.id)) state.select(object.id);
  if (object.locked) return;
  record('Mover objeto');
  drag = { kind: 'move', id: object.id, start: position, ox: object.x, oy: object.y, lastDx: 0, lastDy: 0 };
  dirtyMove = false;
}

function move(event) {
  if (!drag || !canvas) return;
  if (drag.kind === 'pan') {
    state.camera.x = drag.ox + event.clientX - drag.x;
    state.camera.y = drag.oy + event.clientY - drag.y;
    canvas.style.transform = `translate(${state.camera.x}px, ${state.camera.y}px)`;
    return;
  }
  if (drag.kind !== 'move') return;
  const position = point(event);
  const object = state.scene?.objects.find(item => item.id === drag.id);
  if (!object) return;
  let dx = position.x - drag.start.x;
  let dy = position.y - drag.start.y;
  if (state.snap) {
    dx = snapValue(drag.ox + dx, true, GRID_SIZE) - drag.ox;
    dy = snapValue(drag.oy + dy, true, GRID_SIZE) - drag.oy;
  }
  for (const id of state.selectedIds) {
    const target = state.scene.objects.find(item => item.id === id);
    if (target) {
      target.x += dx - drag.lastDx;
      target.y += dy - drag.lastDy;
    }
  }
  drag.lastDx = dx;
  drag.lastDy = dy;
  dirtyMove = true;
  renderCanvas();
}

function up() {
  if (drag?.kind === 'move' && dirtyMove) state.touch('Objeto movido');
  drag = null;
  dirtyMove = false;
}

export function renderCanvas() {
  if (!canvas || !state.scene || !state.project) return;
  const context = canvas.getContext('2d');
  drawWorld(context, state.scene, state.project.settings);
  if (state.grid) {
    context.save();
    context.strokeStyle = '#ffffff17';
    context.lineWidth = 1;
    context.beginPath();
    for (let x = 0; x <= canvas.width; x += GRID_SIZE) { context.moveTo(x, 0); context.lineTo(x, canvas.height); }
    for (let y = 0; y <= canvas.height; y += GRID_SIZE) { context.moveTo(0, y); context.lineTo(canvas.width, y); }
    context.stroke();
    context.restore();
  }
  for (const object of state.selected) {
    context.save();
    context.strokeStyle = '#ff9a3d';
    context.lineWidth = 2;
    context.setLineDash([5, 3]);
    context.strokeRect(object.x - 3, object.y - 3, object.width + 6, object.height + 6);
    context.setLineDash([]);
    context.fillStyle = '#ff9a3d';
    for (const [x, y] of [[object.x, object.y], [object.x + object.width, object.y], [object.x, object.y + object.height], [object.x + object.width, object.y + object.height]]) {
      context.fillRect(x - 3, y - 3, 6, 6);
    }
    context.restore();
  }
}

export function refreshCanvasSize() { resize(); }

export function snapValue(n,enabled,size=16){return enabled?Math.round(n/size)*size:n;}

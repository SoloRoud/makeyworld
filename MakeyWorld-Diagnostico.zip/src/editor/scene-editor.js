import { state } from '../core/state.js';
import { addScene, deleteScene, renameScene, setActiveScene } from '../core/commands.js';
import { esc } from '../ui/dom.js';

export function activateScene(id) {
  setActiveScene(id);
}

export function renderSceneList(container) {
  if (!container || !state.project) return;
  const scenes = state.project.scenes || [];
  const sceneMarkup = scenes.map(scene => {
    const activeClass = scene.id === state.activeSceneId ? 'active' : '';
    const id = esc(scene.id);
    return `<div class="tree-item ${activeClass}" data-scene="${id}">
      <span>▧</span>
      <span class="scene-label">${esc(scene.name || 'Escena')}</span>
      <span class="tree-meta">${Array.isArray(scene.objects) ? scene.objects.length : 0}</span>
      <button class="btn ghost small" data-scene-delete="${id}" title="Eliminar escena" aria-label="Eliminar ${esc(scene.name || 'escena')}">×</button>
    </div>`;
  }).join('');

  container.innerHTML = `<div class="section-head">Escenas <button class="btn small" data-add-scene aria-label="Añadir escena">＋</button></div>${sceneMarkup}`;

  const addButton = container.querySelector('[data-add-scene]');
  if (addButton) addButton.onclick = () => addScene();

  container.querySelectorAll('[data-scene]').forEach(element => {
    element.onclick = () => activateScene(element.dataset.scene);
    element.ondblclick = event => {
      event.preventDefault();
      const scene = state.project.scenes.find(item => item.id === element.dataset.scene);
      if (!scene) return;
      const name = prompt('Nombre de la escena:', scene.name);
      if (name && name.trim()) renameScene(scene.id, name);
    };
  });

  container.querySelectorAll('[data-scene-delete]').forEach(button => {
    button.onclick = event => {
      event.stopPropagation();
      if (state.project.scenes.length === 1) {
        alert('Un proyecto debe tener al menos una escena.');
        return;
      }
      const scene = state.project.scenes.find(item => item.id === button.dataset.sceneDelete);
      if (!scene || !confirm(`¿Eliminar la escena "${scene.name}"?`)) return;
      deleteScene(scene.id);
    };
  });
}

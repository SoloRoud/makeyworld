import { state } from '../core/state.js';
import { events } from '../core/events.js';
import { renderCanvas } from './canvas.js';

export function activateScene(id) {
  state.activeSceneId = id;
  state.project.activeSceneId = id;
  state.select([]);
  events.emit('scene:changed', state.scene);
  renderCanvas();
}

export function renderSceneList(container) {
  if (!state.project) return;

  const scenes = state.project.scenes;
  const sceneMarkup = scenes.map((scene) => {
    const activeClass = scene.id === state.activeSceneId ? 'active' : '';
    const safeName = String(scene.name).replace(/[<>]/g, '');
    return `<div class="tree-item ${activeClass}" data-scene="${scene.id}">
      <span>▧</span>
      <span class="scene-label">${safeName}</span>
      <span class="tree-meta">${scene.objects.length}</span>
      <button class="btn ghost small" data-scene-delete="${scene.id}" title="Eliminar escena">×</button>
    </div>`;
  }).join('');

  container.innerHTML = `<div class="section-head">Escenas <button class="btn small" data-add-scene>＋</button></div>${sceneMarkup}`;

  const addButton = container.querySelector('[data-add-scene]');
  if (addButton) {
    addButton.onclick = () => {
      const scene = {
        id: `scene_${Date.now()}`,
        name: `Escena ${state.project.scenes.length + 1}`,
        background: state.project.settings.background,
        objects: [],
        logic: []
      };
      state.project.scenes.push(scene);
      state.activeSceneId = scene.id;
      state.project.activeSceneId = scene.id;
      state.select([]);
      state.touch('Escena creada');
    };
  }

  container.querySelectorAll('[data-scene]').forEach((element) => {
    element.onclick = () => activateScene(element.dataset.scene);
    element.ondblclick = () => {
      const scene = state.project.scenes.find((item) => item.id === element.dataset.scene);
      if (!scene) return;
      const name = prompt('Nombre de la escena:', scene.name);
      if (name && name.trim()) {
        scene.name = name.trim();
        state.touch('Escena renombrada');
      }
    };
  });

  container.querySelectorAll('[data-scene-delete]').forEach((button) => {
    button.onclick = (event) => {
      event.stopPropagation();
      if (state.project.scenes.length === 1) {
        alert('Un proyecto debe tener al menos una escena.');
        return;
      }

      const scene = state.project.scenes.find((item) => item.id === button.dataset.sceneDelete);
      if (!scene) return;
      if (!confirm(`¿Eliminar la escena "${scene.name}"?`)) return;

      state.project.scenes = state.project.scenes.filter((item) => item.id !== scene.id);
      if (state.activeSceneId === scene.id) {
        state.activeSceneId = state.project.scenes[0].id;
        state.project.activeSceneId = state.activeSceneId;
      }
      state.select([]);
      state.touch('Escena eliminada');
    };
  });
}

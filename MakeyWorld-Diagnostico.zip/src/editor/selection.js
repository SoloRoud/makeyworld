export function hitTest(objects,x,y){return [...objects].sort((a,b)=>(b.z||0)-(a.z||0)).find(o=>o.visible!==false&&x>=o.x&&x<=o.x+o.width&&y>=o.y&&y<=o.y+o.height)||null;}

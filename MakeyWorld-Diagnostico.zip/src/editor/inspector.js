import { state } from '../core/state.js';
import { record } from '../core/history.js';
import { events } from '../core/events.js';
import { esc } from '../ui/dom.js';

function clamp(value, min, max) {
  const number = Number(value);
  return Number.isFinite(number) ? Math.max(min, Math.min(max, number)) : min;
}

export function renderInspector(root) {
  if (!root || !state.project) return;
  const object = state.selected[0];

  if (!object) {
    root.innerHTML = `<div class="section-head">Inspector</div><div class="inspector-content"><div class="inspector-title">Configuración del proyecto</div><div class="field"><label>Nombre del juego</label><input data-project="name" value="${esc(state.project.name)}"></div><div class="field-row"><div class="field"><label>Ancho</label><input type="number" min="160" max="3840" data-setting="width" value="${state.project.settings.width}"></div><div class="field"><label>Alto</label><input type="number" min="160" max="2160" data-setting="height" value="${state.project.settings.height}"></div></div><div class="field"><label>Fondo de escena</label><input type="color" data-background value="${esc(state.scene?.background || '#202631')}"></div><div class="divider"></div><p class="muted tiny">Selecciona un objeto en el escenario o en la jerarquía para editar sus propiedades.</p><div class="field"><label>Modo de editor</label><select data-mode><option value="basic" ${state.mode === 'basic' ? 'selected' : ''}>Básico</option><option value="advanced" ${state.mode === 'advanced' ? 'selected' : ''}>Avanzado</option></select></div></div>`;

    root.querySelector('[data-project]').onchange = event => {
      const value = event.target.value.trim() || 'Mi primer juego';
      if (value === state.project.name) return;
      record('Cambiar nombre del proyecto');
      state.project.name = value;
      state.touch('Nombre cambiado');
      events.emit('project:changed', state.project);
    };
    root.querySelectorAll('[data-setting]').forEach(input => input.onchange = event => {
      const key = event.target.dataset.setting;
      const max = key === 'width' ? 3840 : 2160;
      const value = clamp(event.target.value, 160, max);
      if (value === state.project.settings[key]) return;
      record('Cambiar resolución');
      state.project.settings[key] = value;
      event.target.value = String(value);
      state.touch('Resolución actualizada');
      events.emit('resolution:changed');
    });
    root.querySelector('[data-background]').onchange = event => {
      if (!state.scene || state.scene.background === event.target.value) return;
      record('Cambiar fondo de escena');
      state.scene.background = event.target.value;
      state.touch('Fondo actualizado');
    };
    root.querySelector('[data-mode]').onchange = event => {
      state.mode = event.target.value;
      renderInspector(root);
    };
    return;
  }

  const rules = object.logic || [];
  const lastRule = rules[0] || {};
  const selectedSceneId = lastRule.sceneId || state.project.scenes.find(scene => scene.name === lastRule.scene)?.id || state.project.scenes[0]?.id || '';
  root.innerHTML = `<div class="section-head">Inspector <span class="pill">${esc(object.type)}</span></div><div class="inspector-content"><div class="inspector-title">${esc(object.name)}</div><div class="field"><label>Nombre</label><input data-prop="name" value="${esc(object.name)}"></div><div class="field-row"><div class="field"><label>Posición X</label><input type="number" data-prop="x" value="${Number(object.x) || 0}"></div><div class="field"><label>Posición Y</label><input type="number" data-prop="y" value="${Number(object.y) || 0}"></div></div><div class="field-row"><div class="field"><label>Ancho</label><input type="number" min="1" data-prop="width" value="${Math.max(1, Number(object.width) || 1)}"></div><div class="field"><label>Alto</label><input type="number" min="1" data-prop="height" value="${Math.max(1, Number(object.height) || 1)}"></div></div><div class="field-row"><div class="field"><label>Rotación</label><input type="number" data-prop="rotation" value="${Number(object.rotation) || 0}"></div><div class="field"><label>Opacidad</label><input type="number" min="0" max="1" step="0.1" data-prop="opacity" value="${object.opacity ?? 1}"></div></div><div class="field"><label>Color</label><input type="color" data-prop="color" value="${/^#[0-9a-f]{6}$/i.test(object.color || '') ? object.color : '#ff8a24'}"></div>${object.type === 'text' ? `<div class="field"><label>Texto</label><input data-prop="text" value="${esc(object.text || '')}"></div>` : ''}<div class="divider"></div><div class="section-head" style="padding:5px 0">Componentes</div><div class="tool-group">${(object.components || []).map(component => `<span class="pill">${esc(component)}</span>`).join('') || '<span class="muted tiny">Sin componentes</span>'}</div><div class="field"><label><input type="checkbox" data-physics ${object.physics?.enabled ? 'checked' : ''}> Activar física</label></div><div class="field"><label><input type="checkbox" data-gravity ${object.physics?.gravity ? 'checked' : ''}> Usar gravedad</label></div><div class="field"><label><input type="checkbox" data-solid ${object.physics?.solid ? 'checked' : ''}> Colisionable / sólido</label></div><div class="divider"></div><div class="section-head" style="padding:5px 0">Lógica visual</div><p class="muted tiny">Define qué ocurre cuando se activa un evento de este objeto.</p><div class="field"><label>Cuando…</label><select data-rule-event><option value="touch-player">El jugador toca este objeto</option><option value="start">Al iniciar el juego</option></select></div><div class="field"><label>Entonces…</label><select data-rule-action><option value="add-variable">Sumar a una variable</option><option value="subtract-life">Restar una vida</option><option value="destroy-object">Destruir / ocultar este objeto</option><option value="play-sound">Reproducir sonido</option><option value="show-message">Escribir mensaje en consola</option><option value="change-scene">Cambiar de escena</option></select></div><div class="field-row"><div class="field"><label>Variable</label><input data-rule-variable value="${esc(lastRule.variable || 'puntos')}"></div><div class="field"><label>Cantidad</label><input type="number" data-rule-value value="${lastRule.value ?? 1}"></div></div><div class="field"><label>Escena de destino</label><select data-rule-scene>${state.project.scenes.map(scene => `<option value="${esc(scene.id)}" ${scene.id === selectedSceneId ? 'selected' : ''}>${esc(scene.name)}</option>`).join('')}</select></div><div class="field"><label>Mensaje (opcional)</label><input data-rule-message value="${esc(lastRule.message || '')}"></div><button class="btn small primary" data-add-rule>＋ Añadir comportamiento</button><div class="tiny muted" style="margin-top:8px">${rules.length} comportamiento(s) configurado(s)</div><div class="divider"></div><div class="field"><label><input type="checkbox" data-visible ${object.visible !== false ? 'checked' : ''}> Visible</label></div><div class="field"><label><input type="checkbox" data-locked ${object.locked ? 'checked' : ''}> Bloquear selección</label></div></div>`;

  root.querySelectorAll('[data-prop]').forEach(input => input.addEventListener('change', () => {
    const key = input.dataset.prop;
    let value = ['x', 'y', 'width', 'height', 'rotation', 'opacity'].includes(key) ? Number(input.value) : input.value;
    if (['x', 'y', 'width', 'height', 'rotation', 'opacity'].includes(key) && !Number.isFinite(value)) value = 0;
    if (key === 'width' || key === 'height') value = Math.max(1, value);
    if (key === 'opacity') value = clamp(value, 0, 1);
    if (object[key] === value) return;
    record('Editar propiedad');
    object[key] = value;
    state.touch('Propiedad modificada');
    events.emit('inspector:changed');
  }));

  for (const key of ['physics', 'gravity', 'solid']) {
    root.querySelector(`[data-${key}]`)?.addEventListener('change', event => {
      const property = key === 'physics' ? 'enabled' : key;
      const nextValue = event.target.checked;
      if ((object.physics?.[property] ?? false) === nextValue) return;
      record('Cambiar física');
      object.physics ??= {};
      object.physics[property] = nextValue;
      state.touch('Física modificada');
    });
  }

  root.querySelector('[data-visible]').onchange = event => {
    if ((object.visible !== false) === event.target.checked) return;
    record('Cambiar visibilidad');
    object.visible = event.target.checked;
    state.touch('Visibilidad modificada');
  };
  root.querySelector('[data-locked]').onchange = event => {
    if (!!object.locked === event.target.checked) return;
    record('Bloquear objeto');
    object.locked = event.target.checked;
    state.touch('Bloqueo modificado');
  };
  root.querySelector('[data-add-rule]').onclick = () => {
    const amountText = root.querySelector('[data-rule-value]').value.trim();
    const amount = amountText === '' ? 1 : Number(amountText);
    const targetId = root.querySelector('[data-rule-scene]').value;
    const targetScene = state.project.scenes.find(scene => scene.id === targetId);
    record('Añadir lógica');
    object.logic ??= [];
    object.logic.push({
      id: `rule_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
      event: root.querySelector('[data-rule-event]').value,
      action: root.querySelector('[data-rule-action]').value,
      variable: root.querySelector('[data-rule-variable]').value.trim() || 'puntos',
      value: Number.isFinite(amount) ? amount : 1,
      sceneId: targetId,
      scene: targetScene?.name || '',
      message: root.querySelector('[data-rule-message]').value
    });
    state.touch('Comportamiento añadido');
    events.emit('selection:changed', state.selected);
  };
}

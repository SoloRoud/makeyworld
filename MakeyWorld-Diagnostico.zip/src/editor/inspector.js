import { state } from '../core/state.js';
import { record } from '../core/history.js';
import { events } from '../core/events.js';
import { esc } from '../ui/dom.js';
import { openSpriteEditor } from '../sprite-editor/sprite-editor.js';

function clamp(value, min, max) {
  const number = Number(value);
  return Number.isFinite(number) ? Math.max(min, Math.min(max, number)) : min;
}

function measureTextLines(context, text, maxWidth, wrap) {
  const lines = [];
  for (const paragraph of String(text ?? '').replace(/\r/g, '').split('\n')) {
    if (!wrap || !paragraph) { lines.push(paragraph); continue; }
    let line = '';
    for (const word of paragraph.split(/\s+/)) {
      const candidate = line ? `${line} ${word}` : word;
      if (context.measureText(candidate).width <= maxWidth) { line = candidate; continue; }
      if (line) { lines.push(line); line = ''; }
      let chunk = '';
      for (const character of Array.from(word)) {
        if (chunk && context.measureText(chunk + character).width > maxWidth) {
          lines.push(chunk);
          chunk = character;
        } else chunk += character;
      }
      line = chunk;
    }
    lines.push(line);
  }
  return lines.length ? lines : [''];
}

function fitTextObjectSize(object) {
  if (object.type !== 'text') return false;
  const canvas = document.createElement('canvas');
  const context = canvas.getContext('2d');
  if (!context) return false;
  const size = Math.max(6, Math.min(256, Number(object.fontSize) || 26));
  const family = ['Arial','Verdana','Georgia','Courier New','Trebuchet MS','system-ui','sans-serif','serif','monospace'].includes(object.fontFamily) ? object.fontFamily : 'Arial';
  context.font = `${object.fontStyle === 'italic' || object.italic ? 'italic' : 'normal'} ${object.fontWeight === 'bold' || object.bold ? 'bold' : 'normal'} ${size}px "${family}"`;
  const padding = Math.max(0, Math.min(80, Number(object.textPadding ?? 6)));
  let changed = false;
  if (object.autoFitWidth === true) {
    const paragraphs = String(object.text ?? '').replace(/\r/g, '').split('\n');
    const widest = paragraphs.reduce((maximum, line) => Math.max(maximum, context.measureText(line).width), 1);
    const requiredWidth = Math.max(40, Math.min(1280, Math.ceil(widest + padding * 2 + 4)));
    if (Math.abs((Number(object.width) || 1) - requiredWidth) > 1) { object.width = requiredWidth; changed = true; }
  }
  if (object.autoFitText !== false) {
    const maxWidth = Math.max(1, (Number(object.width) || 1) - padding * 2);
    const lineHeight = Math.max(.8, Math.min(3, Number(object.lineHeight) || 1.2)) * size;
    const lines = measureTextLines(context, object.text, maxWidth, object.wrap !== false);
    const requiredHeight = Math.max(32, Math.ceil(padding * 2 + size + Math.max(0, lines.length - 1) * lineHeight + 4));
    if (Math.abs((Number(object.height) || 1) - requiredHeight) > 1) { object.height = requiredHeight; changed = true; }
  }
  return changed;
}

export function renderInspector(root) {
  if (!root || !state.project) return;
  const object = state.selected[0];

  if (!object) {
    root.innerHTML = `<div class="section-head">Inspector</div><div class="inspector-content"><div class="inspector-title">Configuración del proyecto</div><div class="field"><label>Nombre del juego</label><input data-project="name" value="${esc(state.project.name)}"></div><div class="field-row"><div class="field"><label>Ancho</label><input type="number" min="160" max="3840" data-setting="width" value="${state.project.settings.width}"></div><div class="field"><label>Alto</label><input type="number" min="160" max="2160" data-setting="height" value="${state.project.settings.height}"></div></div><div class="field"><label>Fondo de escena</label><input type="color" data-background value="${esc(state.scene?.background || '#202631')}"></div><div class="divider"></div><p class="muted tiny">Selecciona un objeto en el escenario o en la jerarquía para editar sus propiedades.</p><div class="field"><label>Modo de editor</label><select data-mode><option value="basic" ${state.mode === 'basic' ? 'selected' : ''}>Básico</option><option value="advanced" ${state.mode === 'advanced' ? 'selected' : ''}>Avanzado</option></select></div></div>`;

    root.querySelector('[data-project]').onchange = event => {
      const value = event.target.value.trim() || 'Mi primer juego';
      if (value === state.project.name) return;
      record('Cambiar nombre del proyecto');
      state.project.name = value;
      state.touch('Nombre cambiado');
      events.emit('project:changed', state.project);
    };
    root.querySelectorAll('[data-setting]').forEach(input => input.onchange = event => {
      const key = event.target.dataset.setting;
      const max = key === 'width' ? 3840 : 2160;
      const value = clamp(event.target.value, 160, max);
      if (value === state.project.settings[key]) return;
      record('Cambiar resolución');
      state.project.settings[key] = value;
      event.target.value = String(value);
      state.touch('Resolución actualizada');
      events.emit('resolution:changed');
    });
    root.querySelector('[data-background]').onchange = event => {
      if (!state.scene || state.scene.background === event.target.value) return;
      record('Cambiar fondo de escena');
      state.scene.background = event.target.value;
      state.touch('Fondo actualizado');
    };
    root.querySelector('[data-mode]').onchange = event => {
      state.mode = event.target.value;
      renderInspector(root);
    };
    return;
  }

  const rules = object.logic || [];
  const lastRule = rules[0] || {};
  const selectedSceneId = lastRule.sceneId || state.project.scenes.find(scene => scene.name === lastRule.scene)?.id || state.project.scenes[0]?.id || '';
  root.innerHTML = `<div class="section-head">Inspector <span class="pill">${esc(object.type)}</span></div><div class="inspector-content"><div class="inspector-title">${esc(object.name)}</div><div class="field"><label>Nombre</label><input data-prop="name" value="${esc(object.name)}"></div><div class="field-row"><div class="field"><label>Posición X</label><input type="number" data-prop="x" value="${Number(object.x) || 0}"></div><div class="field"><label>Posición Y</label><input type="number" data-prop="y" value="${Number(object.y) || 0}"></div></div><div class="field-row"><div class="field"><label>Ancho</label><input type="number" min="1" data-prop="width" value="${Math.max(1, Number(object.width) || 1)}"></div><div class="field"><label>Alto</label><input type="number" min="1" data-prop="height" value="${Math.max(1, Number(object.height) || 1)}"></div></div><div class="field-row"><div class="field"><label>Rotación</label><input type="number" data-prop="rotation" value="${Number(object.rotation) || 0}"></div><div class="field"><label>Opacidad</label><input type="number" min="0" max="1" step="0.1" data-prop="opacity" value="${object.opacity ?? 1}"></div></div><div class="field"><label>Color</label><input type="color" data-prop="color" value="${/^#[0-9a-f]{6}$/i.test(object.color || '') ? object.color : '#ff8a24'}"></div>${object.type === 'text' ? `<div class="divider"></div><div class="section-head" style="padding:5px 0">Tipografía</div><div class="field"><label>Contenido (admite varias líneas)</label><textarea rows="4" data-text-prop="text" class="text-content">${esc(object.text ?? '')}</textarea></div><div class="field"><label>Estilo rápido</label><select data-text-preset><option value="">Personalizado</option><option value="title">Título</option><option value="subtitle">Subtítulo</option><option value="body">Texto normal</option><option value="caption">Etiqueta pequeña</option></select></div><div class="field-row"><div class="field"><label>Tamaño</label><input type="number" min="6" max="256" data-text-prop="fontSize" value="${Number(object.fontSize) || 26}"></div><div class="field"><label>Interlineado</label><input type="number" min="0.8" max="3" step="0.1" data-text-prop="lineHeight" value="${Number(object.lineHeight) || 1.2}"></div></div><div class="field"><label>Fuente</label><select data-text-prop="fontFamily">${['Arial','Verdana','Georgia','Courier New','Trebuchet MS','system-ui','sans-serif','serif','monospace'].map(font => `<option value="${font}" ${(object.fontFamily || 'Arial') === font ? 'selected' : ''}>${font}</option>`).join('')}</select></div><div class="field-row"><div class="field"><label>Alineación</label><select data-text-prop="textAlign"><option value="left" ${(object.textAlign || 'left') === 'left' ? 'selected' : ''}>Izquierda</option><option value="center" ${object.textAlign === 'center' ? 'selected' : ''}>Centro</option><option value="right" ${object.textAlign === 'right' ? 'selected' : ''}>Derecha</option></select></div><div class="field"><label>Vertical</label><select data-text-prop="verticalAlign"><option value="top" ${object.verticalAlign === 'top' ? 'selected' : ''}>Arriba</option><option value="middle" ${(object.verticalAlign || 'middle') === 'middle' ? 'selected' : ''}>Centro</option><option value="bottom" ${object.verticalAlign === 'bottom' ? 'selected' : ''}>Abajo</option></select></div></div><div class="field-row"><label class="check-field"><input type="checkbox" data-text-prop="bold" ${object.bold || object.fontWeight === 'bold' ? 'checked' : ''}> Negrita</label><label class="check-field"><input type="checkbox" data-text-prop="italic" ${object.italic || object.fontStyle === 'italic' ? 'checked' : ''}> Cursiva</label></div><div class="field-row"><label class="check-field"><input type="checkbox" data-text-prop="wrap" ${object.wrap !== false ? 'checked' : ''}> Ajustar línea</label><label class="check-field"><input type="checkbox" data-text-prop="autoFitText" ${object.autoFitText !== false ? 'checked' : ''}> Autoaltura</label></div><div class="field-row"><label class="check-field"><input type="checkbox" data-text-prop="autoFitWidth" ${object.autoFitWidth === true ? 'checked' : ''}> Autoancho</label><label class="check-field"><input type="checkbox" data-text-prop="textBackground" ${object.textBackground ? 'checked' : ''}> Fondo</label></div><div class="field-row"><div class="field"><label>Contorno (px)</label><input type="number" min="0" max="20" data-text-prop="outlineWidth" value="${Number(object.outlineWidth) || 0}"></div><div class="field"><label>Color contorno</label><input type="color" data-text-prop="outlineColor" value="${/^#[0-9a-f]{6}$/i.test(object.outlineColor || '') ? object.outlineColor : '#111111'}"></div></div><div class="field-row"><div class="field"><label>Color de fondo</label><input type="color" data-text-prop="backgroundColor" value="${/^#[0-9a-f]{6}$/i.test(object.backgroundColor || '') ? object.backgroundColor : '#202631'}"></div><div class="field"><label>Margen interno</label><input type="number" min="0" max="80" data-text-prop="textPadding" value="${Number(object.textPadding ?? 4)}"></div></div>` : ''}<div class="divider"></div><div class="section-head" style="padding:5px 0">Sprite y animación</div><p class="muted tiny">${object.sprite ? 'Este objeto tiene un sprite asignado.' : 'Este objeto usa su forma y color actuales.'}${object.animation?.frames?.length > 1 ? ` · Animación de ${object.animation.frames.length} fotogramas a ${object.animation.fps || 8} FPS` : ''}</p><button class="btn small" data-edit-sprite>✎ Abrir Pixel Studio</button><div class="divider"></div><div class="section-head" style="padding:5px 0">Componentes</div><div class="tool-group">${(object.components || []).map(component => `<span class="pill">${esc(component)}</span>`).join('') || '<span class="muted tiny">Sin componentes</span>'}</div><div class="field"><label><input type="checkbox" data-physics ${object.physics?.enabled ? 'checked' : ''}> Activar física</label></div><div class="field"><label><input type="checkbox" data-gravity ${object.physics?.gravity ? 'checked' : ''}> Usar gravedad</label></div><div class="field"><label><input type="checkbox" data-solid ${object.physics?.solid ? 'checked' : ''}> Colisionable / sólido</label></div><div class="divider"></div><div class="section-head" style="padding:5px 0">Lógica visual</div><p class="muted tiny">Define qué ocurre cuando se activa un evento de este objeto.</p><div class="field"><label>Cuando…</label><select data-rule-event><option value="touch-player">El jugador toca este objeto</option><option value="start">Al iniciar el juego</option></select></div><div class="field"><label>Entonces…</label><select data-rule-action><option value="add-variable">Sumar a una variable</option><option value="subtract-life">Restar una vida</option><option value="destroy-object">Destruir / ocultar este objeto</option><option value="play-sound">Reproducir sonido</option><option value="show-message">Escribir mensaje en consola</option><option value="change-scene">Cambiar de escena</option></select></div><div class="field-row"><div class="field"><label>Variable</label><input data-rule-variable value="${esc(lastRule.variable || 'puntos')}"></div><div class="field"><label>Cantidad</label><input type="number" data-rule-value value="${lastRule.value ?? 1}"></div></div><div class="field"><label>Escena de destino</label><select data-rule-scene>${state.project.scenes.map(scene => `<option value="${esc(scene.id)}" ${scene.id === selectedSceneId ? 'selected' : ''}>${esc(scene.name)}</option>`).join('')}</select></div><div class="field"><label>Mensaje (opcional)</label><input data-rule-message value="${esc(lastRule.message || '')}"></div><button class="btn small primary" data-add-rule>＋ Añadir comportamiento</button><div class="tiny muted" style="margin-top:8px">${rules.length} comportamiento(s) configurado(s)</div><div class="divider"></div><div class="field"><label><input type="checkbox" data-visible ${object.visible !== false ? 'checked' : ''}> Visible</label></div><div class="field"><label><input type="checkbox" data-locked ${object.locked ? 'checked' : ''}> Bloquear selección</label></div></div>`;

  root.querySelector('[data-edit-sprite]').onclick = () => openSpriteEditor();

  root.querySelectorAll('[data-prop]').forEach(input => input.addEventListener('change', () => {
    const key = input.dataset.prop;
    let value = ['x', 'y', 'width', 'height', 'rotation', 'opacity'].includes(key) ? Number(input.value) : input.value;
    if (['x', 'y', 'width', 'height', 'rotation', 'opacity'].includes(key) && !Number.isFinite(value)) value = 0;
    if (key === 'width' || key === 'height') value = Math.max(1, value);
    if (key === 'opacity') value = clamp(value, 0, 1);
    if (object[key] === value) return;
    record('Editar propiedad');
    object[key] = value;
    if (object.type === 'text' && key === 'width') {
      fitTextObjectSize(object);
      const heightInput = root.querySelector('[data-prop="height"]');
      const widthInput = root.querySelector('[data-prop="width"]');
      if (heightInput) heightInput.value = String(object.height);
      if (widthInput) widthInput.value = String(object.width);
    }
    state.touch('Propiedad modificada');
    events.emit('inspector:changed');
  }));

  const textPreset = root.querySelector('[data-text-preset]');
  if (textPreset) textPreset.addEventListener('change', () => {
    const presets = {
      title: { fontSize: 48, fontWeight: 'bold', fontStyle: 'normal', lineHeight: 1.05, textAlign: 'center', verticalAlign: 'middle', textPadding: 8, autoFitText: true },
      subtitle: { fontSize: 32, fontWeight: 'bold', fontStyle: 'normal', lineHeight: 1.15, textAlign: 'center', verticalAlign: 'middle', textPadding: 7, autoFitText: true },
      body: { fontSize: 22, fontWeight: 'normal', fontStyle: 'normal', lineHeight: 1.35, textAlign: 'left', verticalAlign: 'top', textPadding: 6, autoFitText: true },
      caption: { fontSize: 16, fontWeight: 'normal', fontStyle: 'italic', lineHeight: 1.2, textAlign: 'left', verticalAlign: 'middle', textPadding: 4, autoFitText: true }
    };
    const preset = presets[textPreset.value];
    if (!preset) return;
    record('Aplicar estilo de texto');
    Object.assign(object, preset);
    fitTextObjectSize(object);
    const heightInput = root.querySelector('[data-prop="height"]');
    const widthInput = root.querySelector('[data-prop="width"]');
    if (heightInput) heightInput.value = String(object.height);
    if (widthInput) widthInput.value = String(object.width);
    state.touch('Estilo de texto aplicado');
    events.emit('inspector:changed');
  });

  const textFields = root.querySelectorAll('[data-text-prop]');
  let textHistoryRecorded = false;
  const textArea = root.querySelector('[data-text-prop="text"]');
  if (textArea) {
    textArea.addEventListener('focus', () => { textHistoryRecorded = false; });
    textArea.addEventListener('input', () => {
      if (!textHistoryRecorded) { record('Editar contenido del texto'); textHistoryRecorded = true; }
      object.text = textArea.value;
      fitTextObjectSize(object);
      const heightInput = root.querySelector('[data-prop="height"]');
      const widthInput = root.querySelector('[data-prop="width"]');
      if (heightInput) heightInput.value = String(object.height);
      if (widthInput) widthInput.value = String(object.width);
      state.touch('Texto actualizado');
    });
  }
  textFields.forEach(input => {
    if (input === textArea) return;
    const update = () => {
      const key = input.dataset.textProp;
      let value;
      if (input.type === 'checkbox') value = input.checked;
      else if (['fontSize', 'outlineWidth', 'lineHeight', 'textPadding'].includes(key)) value = Number(input.value);
      else value = input.value;
      if (['fontSize', 'outlineWidth', 'lineHeight', 'textPadding'].includes(key)) { const limits = { fontSize: [6, 256, 26], outlineWidth: [0, 20, 0], lineHeight: [0.8, 3, 1.2], textPadding: [0, 80, 4] }; const [min, max, fallback] = limits[key]; value = Number.isFinite(value) ? Math.max(min, Math.min(max, value)) : fallback; }
      const normalizedKey = key === 'bold' ? 'fontWeight' : key === 'italic' ? 'fontStyle' : key;
      const normalizedValue = key === 'bold' ? (value ? 'bold' : 'normal') : key === 'italic' ? (value ? 'italic' : 'normal') : value;
      if (object[normalizedKey] === normalizedValue) return;
      record('Formato de texto');
      object[normalizedKey] = normalizedValue;
      if (key === 'bold') object.bold = value;
      if (key === 'italic') object.italic = value;
      if (['fontSize', 'fontFamily', 'fontWeight', 'fontStyle', 'lineHeight', 'textPadding', 'wrap', 'autoFitText', 'autoFitWidth'].includes(normalizedKey)) {
        fitTextObjectSize(object);
        const heightInput = root.querySelector('[data-prop="height"]');
        const widthInput = root.querySelector('[data-prop="width"]');
        if (heightInput) heightInput.value = String(object.height);
        if (widthInput) widthInput.value = String(object.width);
      }
      state.touch('Formato de texto actualizado');
    };
    input.addEventListener('change', update);
  });

  for (const key of ['physics', 'gravity', 'solid']) {
    root.querySelector(`[data-${key}]`)?.addEventListener('change', event => {
      const property = key === 'physics' ? 'enabled' : key;
      const nextValue = event.target.checked;
      if ((object.physics?.[property] ?? false) === nextValue) return;
      record('Cambiar física');
      object.physics ??= {};
      object.physics[property] = nextValue;
      state.touch('Física modificada');
    });
  }

  root.querySelector('[data-visible]').onchange = event => {
    if ((object.visible !== false) === event.target.checked) return;
    record('Cambiar visibilidad');
    object.visible = event.target.checked;
    state.touch('Visibilidad modificada');
  };
  root.querySelector('[data-locked]').onchange = event => {
    if (!!object.locked === event.target.checked) return;
    record('Bloquear objeto');
    object.locked = event.target.checked;
    state.touch('Bloqueo modificado');
  };
  root.querySelector('[data-add-rule]').onclick = () => {
    const amountText = root.querySelector('[data-rule-value]').value.trim();
    const amount = amountText === '' ? 1 : Number(amountText);
    const targetId = root.querySelector('[data-rule-scene]').value;
    const targetScene = state.project.scenes.find(scene => scene.id === targetId);
    record('Añadir lógica');
    object.logic ??= [];
    object.logic.push({
      id: `rule_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
      event: root.querySelector('[data-rule-event]').value,
      action: root.querySelector('[data-rule-action]').value,
      variable: root.querySelector('[data-rule-variable]').value.trim() || 'puntos',
      value: Number.isFinite(amount) ? amount : 1,
      sceneId: targetId,
      scene: targetScene?.name || '',
      message: root.querySelector('[data-rule-message]').value
    });
    state.touch('Comportamiento añadido');
    events.emit('selection:changed', state.selected);
  };
}

import { state } from '../core/state.js';import { mountCanvas, renderCanvas, refreshCanvasSize } from './canvas.js';import { bindToolbar } from '../ui/toolbar.js';import { bindPanels,renderDock,renderRight,renderLeft } from '../ui/panels.js';import { GameRuntime } from '../engine/runtime.js';import { toast } from '../ui/dom.js';import { events } from '../core/events.js';import { openSpriteEditor } from '../sprite-editor/sprite-editor.js';

export function mountWorkspace(root,{onHome,onHelp}){root.innerHTML=`<div class="app-shell"><header class="topbar"><div class="brand"><div class="brand-mark">M</div><span>MakeyWorld</span></div><div class="top-separator"></div><span class="project-name" data-project-name></span><span class="pill" data-save-state>Guardado</span><div class="top-actions"><button class="btn ghost icon" title="Deshacer · Ctrl+Z" data-undo>↶</button><button class="btn ghost icon" title="Rehacer · Ctrl+Y" data-redo>↷</button><button class="btn" data-save title="Guardar · Ctrl+S">▣ <span class="label-hide">Guardar</span></button><div class="top-separator"></div><button class="btn primary" data-play>▶ <span class="label-hide">Ejecutar</span></button><button class="btn" data-pause disabled>Ⅱ</button><button class="btn" data-stop disabled>■</button><div class="top-separator"></div><button class="btn" data-sprite>✎ <span class="label-hide">Pixel Studio</span></button><button class="btn" data-export-project>↓ <span class="label-hide">Proyecto</span></button><button class="btn" data-export-html>↗ <span class="label-hide">HTML5</span></button><button class="btn ghost icon" data-help title="Ayuda">?</button><button class="btn ghost" data-home title="Volver al inicio">⌂</button></div></header><div class="workspace"><aside class="leftbar"><div class="side-tabs"><button class="tab active" data-left-tab="scene">Escena</button><button class="tab" data-left-tab="objects">Objetos</button><button class="tab" data-left-tab="assets">Recursos</button></div><div data-left-content><div data-scenes><div class="section-head">Escenas <button class="btn small" data-add-scene>＋</button></div></div><div data-objects><div class="section-head">Jerarquía</div></div><div data-assets hidden></div></div><div class="divider"></div><div class="section-head">Herramientas rápidas</div><div class="tree"><button class="tree-item" data-open-sprite>✎ Makey Pixel Studio</button><button class="tree-item" data-open-logic>⌘ Lógica visual</button><button class="tree-item" data-open-code>{ } Makey Code</button><button class="tree-item" data-open-help>ⓘ Guías y ayuda</button></div></aside><main class="center-stage"><div class="stage-toolbar"><button class="btn small selected" data-tool="select">↖ Seleccionar</button><button class="btn small" data-tool="hand">✥ Mover vista</button><span class="top-separator"></span><span class="muted tiny">Añadir:</span><button class="btn small" data-add-object="player">Jugador</button><button class="btn small" data-add-object="platform">Plataforma</button><button class="btn small" data-add-object="coin">Moneda</button><button class="btn small" data-add-object="enemy">Enemigo</button><button class="btn small" data-add-object="rect">＋ Objeto</button><button class="btn small" data-add-object="circle">◯</button><button class="btn small" data-add-object="text">T</button><span class="top-separator"></span><button class="btn small" data-copy title="Copiar · Ctrl+C">Copiar</button><button class="btn small" data-paste title="Pegar · Ctrl+V">Pegar</button><button class="btn small" data-duplicate title="Duplicar · Ctrl+D">⧉</button><button class="btn small danger" data-delete title="Eliminar · Supr">×</button><span style="margin-left:auto"></span><button class="btn small selected" data-grid title="Mostrar cuadrícula">▦</button><button class="btn small selected" data-snap title="Ajustar a cuadrícula">⊞</button><select data-zoom class="text-input" style="width:82px;padding:5px"><option value="0.6">60%</option><option value="0.8">80%</option><option value="1" selected>100%</option><option value="1.2">120%</option></select></div><section class="scene-wrap"><canvas class="scene-canvas" data-scene-canvas></canvas><div class="canvas-hint">Arrastra para mover · Shift + clic para selección múltiple · Supr para eliminar</div></section><div class="bottom-dock"><div class="dock-tabs"><button class="tab active" data-dock-tab="console">Consola</button><button class="tab" data-dock-tab="variables">Variables</button><button class="tab" data-dock-tab="scripts">Makey Code</button><button class="tab" data-dock-tab="logic">Lógica</button><span style="margin-left:auto" class="muted tiny">Ctrl+S guardar · F5 ejecutar</span></div><div class="dock-content" data-dock-content></div></div></main><aside class="inspector"></aside></div><footer class="statusbar"><div class="status-left"><span data-status>Listo</span><span data-fps></span></div><div class="status-right"><span data-resolution></span><span data-object-count></span><span>MakeyWorld 1.0</span></div></footer></div>`;
 const logs = [];
 let runtime = null;
 const cleanups = [];
 const log = (message, type = '') => {
   logs.push({ message: String(message), type, time: new Date().toLocaleTimeString('es-ES') });
   if (logs.length > 100) logs.shift();
   if (state.bottomTab === 'console' && root.isConnected) renderDock(root, logs);
 };

 root.querySelector('[data-project-name]').textContent = state.project.name;
 const canvasCleanup = mountCanvas(root.querySelector('[data-scene-canvas]'));
 if (canvasCleanup) cleanups.push(canvasCleanup);
 const toolbarCleanup = bindToolbar(root, { onPlay: play, onPause: pause, onStop: stop, onHelp, onHome: () => { stop(); onHome(); } });
 if (toolbarCleanup) cleanups.push(toolbarCleanup);
 const panelsCleanup = bindPanels(root, logs);
 if (panelsCleanup) cleanups.push(panelsCleanup);
 renderLeft(root);
 renderRight(root);
 renderDock(root, logs);
 root.querySelectorAll('[data-tool]').forEach(button => button.onclick = () => {
   state.tool = button.dataset.tool;
   root.querySelectorAll('[data-tool]').forEach(item => item.classList.toggle('selected', item === button));
 });
 root.querySelector('[data-open-sprite]').onclick = () => openSpriteEditor();
 root.querySelector('[data-open-code]').onclick = () => { state.bottomTab = 'scripts'; renderDock(root, logs); };
 root.querySelector('[data-open-logic]').onclick = () => { state.bottomTab = 'logic'; renderDock(root, logs); };
 root.querySelector('[data-open-help]').onclick = onHelp;
 root.querySelector('[data-dock-tab="logic"]').onclick = () => { state.bottomTab = 'logic'; renderDock(root, logs); };

 updateStatus(root);
 cleanups.push(events.on('scene:changed', () => { renderCanvas(); updateStatus(root); }));
 cleanups.push(events.on('project:changed', project => {
   const name = root.querySelector('[data-project-name]');
   if (name) name.textContent = project.name;
   renderCanvas();
   updateStatus(root);
 }));
 cleanups.push(events.on('resolution:changed', () => { refreshCanvasSize(); updateStatus(root); }));
 cleanups.push(events.on('project:dirty', reason => {
   const badge = root.querySelector('[data-save-state]');
   const status = root.querySelector('[data-status]');
   if (badge) { badge.textContent = 'Sin guardar'; badge.classList.add('saving'); }
   if (status) status.textContent = reason || 'Modificado';
 }));
 cleanups.push(events.on('saved', () => {
   const badge = root.querySelector('[data-save-state]');
   if (badge) { badge.textContent = 'Guardado'; badge.classList.remove('saving'); }
 }));
 cleanups.push(events.on('selection:changed', () => { renderCanvas(); updateStatus(root); }));

 const onDragOver = event => event.preventDefault();
 const onDrop = event => {
   event.preventDefault();
   if (!event.dataTransfer?.files?.length) return;
   import('../assets/asset-manager.js').then(module => module.importFiles(event.dataTransfer.files)).catch(error => toast(error.message, 'error'));
   state.leftTab = 'assets';
   renderLeft(root);
 };
 root.addEventListener('dragover', onDragOver);
 root.addEventListener('drop', onDrop);
 cleanups.push(() => { root.removeEventListener('dragover', onDragOver); root.removeEventListener('drop', onDrop); });

 return { play, pause, stop, log, logs, destroy };

 function updateStatus(element) {
   const resolution = element.querySelector('[data-resolution]');
   const count = element.querySelector('[data-object-count]');
   if (resolution) resolution.textContent = `${state.project.settings.width} × ${state.project.settings.height}`;
   if (count) count.textContent = `${state.scene?.objects.length || 0} objetos`;
 }

 function play() {
   if (runtime) return;
   const wrap = root.querySelector('.scene-wrap');
   if (!wrap) return;
   const overlay = document.createElement('div');
   overlay.className = 'run-overlay';
   const gameCanvas = document.createElement('canvas');
   gameCanvas.width = state.project.settings.width;
   gameCanvas.height = state.project.settings.height;
   gameCanvas.style.width = 'min(100%, 1100px)';
   gameCanvas.style.height = 'auto';
   overlay.append(gameCanvas);
   wrap.append(overlay);
   state.running = true;
   state.paused = false;
   root.querySelector('[data-play]').disabled = true;
   root.querySelector('[data-pause]').disabled = false;
   root.querySelector('[data-pause]').textContent = 'Ⅱ';
   root.querySelector('[data-stop]').disabled = false;
   root.querySelector('[data-status]').textContent = 'Juego en ejecución';
   runtime = new GameRuntime(gameCanvas, state.project, {
     onLog: message => log(message),
     onStop: () => {
       overlay.remove();
       runtime = null;
       state.running = false;
       state.paused = false;
       const playButton = root.querySelector('[data-play]');
       const pauseButton = root.querySelector('[data-pause]');
       const stopButton = root.querySelector('[data-stop]');
       const status = root.querySelector('[data-status]');
       if (playButton) playButton.disabled = false;
       if (pauseButton) { pauseButton.disabled = true; pauseButton.textContent = 'Ⅱ'; }
       if (stopButton) stopButton.disabled = true;
       if (status) status.textContent = 'Listo';
       renderCanvas();
     },
     onFrame: frame => {
       const fps = root.querySelector('[data-fps]');
       if (fps) fps.textContent = `${frame.fps} FPS`;
     }
   });
   runtime.start();
 }

 function pause() {
   if (!runtime) return;
   state.paused = runtime.pause();
   const button = root.querySelector('[data-pause]');
   if (button) button.textContent = state.paused ? '▶' : 'Ⅱ';
 }

 function stop() {
   if (runtime) runtime.stop();
   else { state.running = false; state.paused = false; }
 }

 function destroy() {
   stop();
   while (cleanups.length) {
     try { cleanups.pop()(); } catch (error) { console.warn('MakeyWorld cleanup', error); }
   }
 }
}

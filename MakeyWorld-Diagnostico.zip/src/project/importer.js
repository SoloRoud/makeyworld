import { parseProject } from './serializer.js';
export function readProjectFile(file){return new Promise((resolve,reject)=>{const reader=new FileReader();reader.onload=()=>{try{resolve(parseProject(reader.result));}catch(e){reject(e);}};reader.onerror=()=>reject(reader.error);reader.readAsText(file);});}

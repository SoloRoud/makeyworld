import { createProject } from '../core/state.js';import { saveProject,listProjects,loadProject,deleteProject } from '../core/storage.js';import { state } from '../core/state.js';import { events } from '../core/events.js';import { clearHistory } from '../core/history.js';
export {saveProject,listProjects,loadProject,deleteProject};
export async function openProject(id){const p=await loadProject(id);if(!p)throw new Error('No se ha encontrado el proyecto.');state.setProject(p);clearHistory();events.emit('project:opened',p);return p;}
export function newProject(name,options){const p=createProject(name,options);state.setProject(p);clearHistory();return p;}

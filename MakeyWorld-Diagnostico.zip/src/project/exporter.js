import { serializeProject } from './serializer.js';

export function downloadBlob(blob, name) {
  const url = URL.createObjectURL(blob), anchor = document.createElement('a');
  anchor.href = url; anchor.download = name; anchor.click();
  setTimeout(() => URL.revokeObjectURL(url), 1500);
}
function safeName(value) { return String(value || 'makeyworld').replace(/[^a-z0-9-_]+/gi, '-').replace(/^-|-$/g, '') || 'makeyworld'; }
function escapeHTML(value) { return String(value).replace(/[&<>"']/g, char => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[char])); }
export function exportProject(project) {
  downloadBlob(new Blob([serializeProject(project)], { type: 'application/json' }), `${safeName(project.name)}.mwproject`);
}

export function exportHTML(project) {
  const data = { ...project, activeSceneId: project.activeSceneId || project.scenes[0]?.id };
  const json = JSON.stringify(data).replace(/</g, '\\u003c').replace(/>/g, '\\u003e').replace(/&/g, '\\u0026');
  const html = `<!doctype html>
<html lang="es"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>${escapeHTML(project.name)}</title>
<style>
*{box-sizing:border-box}body{margin:0;background:#101319;color:#eee;font:14px system-ui;display:grid;place-items:center;min-height:100vh}.wrap{width:min(96vw,1280px);text-align:center}canvas{display:block;width:100%;height:auto;max-height:88vh;object-fit:contain;background:#222;border:1px solid #414956}.hint{color:#aab2c0;font-size:12px;margin:8px}.hud{font-size:12px;color:#aab2c0;display:flex;justify-content:space-between;margin:6px 0}
</style></head><body><main class="wrap"><div class="hud"><span>${escapeHTML(project.name)}</span><span id="score">Monedas: 0 · Puntos: 0</span></div><canvas id="game"></canvas><p class="hint">Controles: A / D o ← / → para moverte · Espacio, W o ↑ para saltar. En top-down usa WASD o las flechas.</p></main>
<script id="mw-data" type="application/json">${json}</script>
<script>
(()=>{
'use strict';
const project=JSON.parse(document.getElementById('mw-data').textContent),canvas=document.getElementById('game'),ctx=canvas.getContext('2d');
let scene=project.scenes.find(s=>s.id===project.activeSceneId)||project.scenes[0];
canvas.width=project.settings.width;canvas.height=project.settings.height;
let objects=structuredClone(scene.objects),vars={...project.variables},keys=Object.create(null),pressed=new Set(),last=0,player=objects.find(o=>o.type==='player'),gravity=project.settings.gravity||900;
const imageCache=new Map(),contacts=new Set(),logs=[];
addEventListener('keydown',e=>{if(!keys[e.key])pressed.add(e.key);keys[e.key]=true;keys[e.key.toLowerCase()]=true;if(['ArrowLeft','ArrowRight','ArrowUp','ArrowDown',' '].includes(e.key))e.preventDefault();});
addEventListener('keyup',e=>{keys[e.key]=false;keys[e.key.toLowerCase()]=false;});
const normalizeKey=k=>k==='Space'?' ':k;const keyDown=k=>{k=normalizeKey(k);return keys[k]||keys[String(k).toLowerCase()]||false;};const keyPressed=k=>{k=normalizeKey(k);return pressed.has(k)||pressed.has(String(k).toLowerCase());};
const hit=(a,b)=>a.x<b.x+b.width&&a.x+a.width>b.x&&a.y<b.y+b.height&&a.y+a.height>b.y;
function decorate(o){o.move=(x,y=0)=>{o.vx=x*(o.speed||220);if(o.physics?.gravity===false)o.vy=y*(o.speed||220);};o.jump=()=>{if(o.grounded){o.vy=-(o.jumpForce||420);o.grounded=false;}};return o;}
function setScene(reference){const next=project.scenes.find(s=>s.id===reference||s.name===reference);if(!next){log('No existe la escena: '+reference);return;}scene=next;objects=structuredClone(scene.objects).map(decorate);for(const o of objects)if(o.animation){o.animation.elapsed=0;o._animationFrameIndex=-1;}player=objects.find(o=>o.type==='player');contacts.clear();}
function beep(frequency=660,duration=.1){try{const AC=window.AudioContext||window.webkitAudioContext;if(!AC)return;const ac=beep.ac||(beep.ac=new AC()),osc=ac.createOscillator(),gain=ac.createGain();osc.frequency.value=frequency;gain.gain.setValueAtTime(.12,ac.currentTime);gain.gain.exponentialRampToValueAtTime(.001,ac.currentTime+duration);osc.connect(gain);gain.connect(ac.destination);osc.start();osc.stop(ac.currentTime+duration);}catch{}}
function log(message){logs.push(String(message));if(logs.length>3)logs.shift();}
const api={objects:{get:name=>objects.find(o=>o.name===name||o.id===name)},get player(){return player},variables:vars,input:{isDown:keyDown,isPressed:keyPressed},audio:{beep},scene:{change:setScene},log,create(type,x=0,y=0){const o=decorate({id:'runtime_'+Math.random(),name:type,type,x,y,width:28,height:28,color:'#ff8a24',visible:true,physics:{enabled:false,gravity:false,solid:false},logic:[]});objects.push(o);return o;}};
const compiled=[];
for(const script of project.scripts||[]){if(!script.enabled||!script.code)continue;try{compiled.push({name:script.name,run:new Function('api','dt','input','player',script.code+'\\n;if(typeof update==="function")update(dt);')});}catch(error){log('Error en '+script.name+': '+error.message);}}
objects=objects.map(decorate);player=objects.find(o=>o.type==='player');
function applyRule(rule,obj){if(rule.action==='add-variable'){const k=rule.variable||'puntos';vars[k]=(Number(vars[k])||0)+(Number(rule.value)||1);}else if(rule.action==='subtract-life')vars.vidas=Math.max(0,(Number(vars.vidas)||0)-(Number(rule.value)||1));else if(rule.action==='destroy-object')obj.visible=false;else if(rule.action==='play-sound')beep();else if(rule.action==='show-message')log(rule.message||'Acción activada');else if(rule.action==='change-scene')setScene(rule.sceneId||rule.scene);}
function update(dt){
 for(const o of objects){const a=o.animation;if(!a||!Array.isArray(a.frames)||a.frames.length<2||a.playing===false)continue;a.elapsed=(Number(a.elapsed)||0)+dt;const fps=Math.max(1,Math.min(60,Number(a.fps)||8));const raw=Math.floor(a.elapsed*fps);const index=a.loop===false?Math.min(a.frames.length-1,raw):raw%a.frames.length;if(a.loop===false&&index===a.frames.length-1)a.elapsed=(a.frames.length-1)/fps;const frame=a.frames[index];if(frame?.sprite&&o._animationFrameIndex!==index){o.sprite=frame.sprite;o._animationFrameIndex=index;}}
 if(player){player.vx??=0;player.vy??=0;const speed=player.speed||220;const left=keyDown('ArrowLeft')||keyDown('a'),right=keyDown('ArrowRight')||keyDown('d');player.vx=(right?1:0)-(left?1:0);player.vx*=speed;
 if(player.physics?.gravity===false){const up=keyDown('ArrowUp')||keyDown('w'),down=keyDown('ArrowDown')||keyDown('s');player.vy=((down?1:0)-(up?1:0))*speed;}else{player.vy+=gravity*dt;if((keyDown(' ')||keyDown('ArrowUp')||keyDown('w'))&&player.grounded){player.vy=-(player.jumpForce||420);player.grounded=false;}}
 const solids=objects.filter(o=>o!==player&&o.visible!==false&&o.physics?.enabled&&o.physics?.solid!==false);const oldX=player.x;player.x+=player.vx*dt;if(solids.some(s=>hit(player,s)))player.x=oldX;
 const oldY=player.y;player.y+=player.vy*dt;player.grounded=false;for(const s of solids){if(!hit(player,s))continue;if(player.vy>=0&&oldY+player.height<=s.y+12){player.y=s.y-player.height;player.vy=0;player.grounded=true;}else if(player.vy<0&&oldY>=s.y+s.height-12){player.y=s.y+s.height;player.vy=0;}else{player.y=oldY;player.vy=0;}}
 }
 for(const coin of objects.filter(o=>o.type==='coin'&&o.visible!==false)){if(player&&hit(player,coin)){coin.visible=false;vars.monedas=(Number(vars.monedas)||0)+1;vars.puntos=(Number(vars.puntos)||0)+10;beep(880,.08);for(const rule of coin.logic||[])applyRule(rule,coin);}}
 const nowContacts=new Set();for(const obj of objects){if(obj.type==='enemy'&&player&&Math.abs(player.x-obj.x)<240)obj.x+=(player.x<obj.x?-1:1)*(obj.aiSpeed||30)*dt;if(!player||obj===player||obj.visible===false||!hit(player,obj))continue;for(const rule of obj.logic||[]){if(rule.event!=='touch-player')continue;const k=obj.id+':'+(rule.id||rule.action);nowContacts.add(k);if(!contacts.has(k))applyRule(rule,obj);}}contacts.clear();for(const k of nowContacts)contacts.add(k);
 for(const script of compiled){try{script.run(api,dt,api.input,player);}catch(error){log('Error en '+script.name+': '+error.message);}}
}
function draw(o){if(o.visible===false)return;ctx.save();ctx.globalAlpha=o.opacity??1;ctx.translate(o.x+o.width/2,o.y+o.height/2);ctx.rotate((o.rotation||0)*Math.PI/180);if(o.sprite){let image=imageCache.get(o.sprite);if(!image){image=new Image();image.src=o.sprite;imageCache.set(o.sprite,image);}if(image.complete&&image.naturalWidth)ctx.drawImage(image,-o.width/2,-o.height/2,o.width,o.height);}else if(o.type==='circle'||o.type==='coin'){ctx.fillStyle=o.color||'#ffd34e';ctx.beginPath();ctx.ellipse(0,0,o.width/2,o.height/2,0,0,Math.PI*2);ctx.fill();if(o.type==='coin'){ctx.strokeStyle='#fff0a6';ctx.stroke();}}else if(o.type==='text'){ctx.fillStyle=o.color||'#fff';ctx.font='22px system-ui';ctx.textAlign='left';ctx.fillText(o.text||'',-o.width/2,0);}else{ctx.fillStyle=o.color||'#6ba8ff';ctx.fillRect(-o.width/2,-o.height/2,o.width,o.height);if(o.type==='player'){ctx.fillStyle='#fff';ctx.fillRect(-o.width*.2,-o.height*.25,4,4);ctx.fillRect(o.width*.1,-o.height*.25,4,4);}}ctx.restore();}
function loop(time){const dt=Math.min(.04,(time-last)/1000||0);last=time;update(dt);ctx.fillStyle=scene.background||project.settings.background||'#222';ctx.fillRect(0,0,canvas.width,canvas.height);objects.slice().sort((a,b)=>(a.z||0)-(b.z||0)).forEach(draw);document.getElementById('score').textContent='Monedas: '+(vars.monedas||0)+' · Puntos: '+(vars.puntos||0)+(logs.length?' · '+logs[logs.length-1]:'');pressed.clear();requestAnimationFrame(loop);}
for(const obj of objects)for(const rule of obj.logic||[])if(rule.event==='start')applyRule(rule,obj);
requestAnimationFrame(loop);
})();
</script></body></html>`;
  downloadBlob(new Blob([html], { type: 'text/html' }), `${safeName(project.name)}.html`);
}

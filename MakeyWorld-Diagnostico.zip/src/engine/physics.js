import { overlaps } from './collision.js';

// Resolución por ejes separados: primero X y después Y. Esto permite caminar
// sobre plataformas sin que la gravedad genere una falsa colisión lateral.
export function stepPhysics(objects, dt, gravity = 900) {
  const solids = objects.filter(object =>
    object.physics?.enabled && object.physics?.solid !== false && object.visible !== false
  );

  for (const object of objects) {
    if (!object.physics?.enabled || object.visible === false) continue;

    const oldX = object.x;
    const oldY = object.y;
    object.vx ??= 0;
    object.vy ??= 0;
    const useGravity = object.physics.gravity !== false;

    // Eje horizontal con la posición vertical previa al paso de gravedad.
    object.x += object.vx * dt;
    const horizontalHit = solids.find(solid =>
      solid.id !== object.id && overlaps(object, solid)
    );
    if (horizontalHit) {
      object.x = oldX;
      object.vx = 0;
    }

    if (useGravity) object.vy += gravity * dt;

    // Eje vertical y detección de suelo/techo.
    if (useGravity || object.vy !== 0) {
      object.y += object.vy * dt;
      object.grounded = false;
      const verticalHit = solids.find(solid =>
        solid.id !== object.id && overlaps(object, solid)
      );
      if (verticalHit) {
        if (object.vy >= 0 && oldY + object.height <= verticalHit.y + 12) {
          object.y = verticalHit.y - object.height;
          object.vy = 0;
          object.grounded = true;
        } else if (object.vy < 0 && oldY >= verticalHit.y + verticalHit.height - 12) {
          object.y = verticalHit.y + verticalHit.height;
          object.vy = 0;
        } else {
          object.y = oldY;
          object.vy = 0;
        }
      }
    }

    if (object.y > 10000) {
      object.y = -object.height;
      object.vy = 0;
    }
  }
}

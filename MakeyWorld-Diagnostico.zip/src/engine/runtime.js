import { InputManager } from './input.js';
import { drawWorld } from './renderer.js';
import { stepPhysics } from './physics.js';
import { overlaps } from './collision.js';
import { AudioEngine } from './audio.js';

export class GameRuntime {
  constructor(canvas, project, { onLog = () => {}, onStop = () => {}, onFrame = () => {} } = {}) {
    this.canvas = canvas;
    this.project = structuredClone(project);
    this.scene = this.project.scenes.find(scene => scene.id === this.project.activeSceneId) || this.project.scenes[0];
    this.objects = structuredClone(this.scene.objects);
    this.variables = { ...this.project.variables };
    this.input = new InputManager(window);
    this.audio = new AudioEngine();
    this.onLog = onLog; this.onStop = onStop; this.onFrame = onFrame;
    this.player = this.objects.find(object => object.type === 'player');
    this.decorateObjects();
    this.running = false; this.paused = false; this.last = 0; this.raf = 0;
    this.elapsed = 0; this.hitboxes = false; this.contacts = new Set(); this.scriptErrors = new Set();
    this.api = this.makeAPI();
    this.compiledScripts = this.compileScripts();
  }

  makeAPI() {
    const runtime = this;
    return {
      objects: { get(name) { return runtime.objects.find(object => object.name === name || object.id === name); } },
      get player() { return runtime.player; },
      variables: this.variables,
      input: { isDown: key => runtime.input.isDown(key), isPressed: key => runtime.input.isPressed(key) },
      audio: { beep: (frequency, duration) => runtime.audio.beep(frequency, duration) },
      scene: { change(name) {
        const next = runtime.project.scenes.find(scene => scene.name === name);
        if (!next) { runtime.onLog(`No existe la escena: ${name}`); return; }
        runtime.scene = next; runtime.objects = structuredClone(next.objects);
        runtime.player = runtime.objects.find(object => object.type === 'player'); runtime.decorateObjects(); runtime.contacts.clear();
      } },
      log: (...args) => runtime.onLog(args.join(' ')),
      create(type, x = 0, y = 0) {
        const object = { id: `runtime_${Math.random()}`, name: type, type, x, y, width: 28, height: 28, color: '#ff8a24', visible: true, physics: { enabled: false, gravity: false, solid: false }, logic: [] };
        runtime.objects.push(object); object.move = (x, y = 0) => { object.vx = x * (object.speed || 220); if (object.physics?.gravity === false) object.vy = y * (object.speed || 220); }; object.jump = () => { if (object.grounded) object.vy = -(object.jumpForce || 420); }; return object;
      }
    };
  }

  decorateObjects() {
    for (const object of this.objects) {
      object.move = (x, y = 0) => { object.vx = x * (object.speed || 220); if (object.physics?.gravity === false) object.vy = y * (object.speed || 220); };
      object.jump = () => { if (object.grounded) { object.vy = -(object.jumpForce || 420); object.grounded = false; } };
    }
  }

  compileScripts() {
    const compiled = [];
    for (const script of this.project.scripts || []) {
      if (!script.enabled || !script.code?.trim()) continue;
      try {
        const body = `${script.code}\n; if (typeof update === 'function') update(dt);`;
        compiled.push({ name: script.name || 'script', run: new Function('api', 'dt', 'input', 'player', body) });
      } catch (error) { this.scriptErrors.add(error.message); this.onLog(`Error de sintaxis en ${script.name}: ${error.message}`); }
    }
    return compiled;
  }

  start() {
    if (this.running) return;
    this.running = true; this.last = performance.now();
    for (const object of this.objects) for (const rule of object.logic || []) if (rule.event === 'start') this.runRule(rule, object);
    this.onLog('▶ Juego iniciado'); this.raf = requestAnimationFrame(time => this.loop(time));
  }

  loop(now) {
    if (!this.running) return;
    const dt = Math.min(0.04, Math.max(0, (now - this.last) / 1000)); this.last = now;
    if (!this.paused) this.update(dt);
    drawWorld(this.canvas.getContext('2d'), { ...this.scene, objects: this.objects }, this.project.settings, { hitboxes: this.hitboxes });
    this.onFrame({ fps: dt ? Math.round(1 / dt) : 0, variables: this.variables });
    this.input.endFrame(); this.raf = requestAnimationFrame(time => this.loop(time));
  }

  update(dt) {
    this.elapsed += dt;
    const player = this.player;
    if (player) {
      player.vx ??= 0; player.vy ??= 0;
      const speed = player.speed || 220;
      player.vx = ((this.input.action('left') ? -1 : 0) + (this.input.action('right') ? 1 : 0)) * speed;
      if (player.physics?.gravity === false) {
        player.vy = ((this.input.action('up') ? -1 : 0) + (this.input.action('down') ? 1 : 0)) * speed;
      } else if (this.input.action('jump') && player.grounded) {
        player.vy = -(player.jumpForce || 420); player.grounded = false;
      }
    }
    for (const script of this.compiledScripts) {
      try { script.run(this.api, dt, this.input, this.player); }
      catch (error) { if (!this.scriptErrors.has(error.message)) { this.scriptErrors.add(error.message); this.onLog(`Error en ${script.name}: ${error.message}`); } }
    }
    stepPhysics(this.objects, dt, this.project.settings.gravity || 900);
    for (const coin of [...this.objects.filter(object => object.type === 'coin' && object.visible !== false)]) {
      if (player && overlaps(player, coin)) this.collect(coin);
    }
    const nextContacts = new Set();
    for (const object of this.objects) {
      if (object.type === 'enemy' && player && Math.abs(player.x - object.x) < 240) object.x += (player.x < object.x ? -1 : 1) * (object.aiSpeed || 30) * dt;
      if (!player || object.id === player.id || object.visible === false || !overlaps(player, object)) continue;
      for (const rule of object.logic || []) {
        if (rule.event !== 'touch-player') continue;
        const contactKey = `${object.id}:${rule.id || rule.action}`;
        nextContacts.add(contactKey);
        if (!this.contacts.has(contactKey)) this.runRule(rule, object);
      }
    }
    this.contacts = nextContacts;
  }

  collect(coin) {
    coin.visible = false; this.variables.monedas = (Number(this.variables.monedas) || 0) + 1;
    this.variables.puntos = (Number(this.variables.puntos) || 0) + 10;
    this.audio.beep(880, 0.1, 'triangle'); this.onLog(`Moneda recogida · monedas: ${this.variables.monedas}`);
    for (const rule of coin.logic || []) if (rule.event === 'touch-player') this.runRule(rule, coin);
  }

  runRule(rule, object) {
    if (rule.action === 'add-variable') { const key = rule.variable || 'puntos'; this.variables[key] = (Number(this.variables[key]) || 0) + (Number(rule.value) || 1); }
    else if (rule.action === 'subtract-life') this.variables.vidas = Math.max(0, (this.variables.vidas || 0) - (Number(rule.value) || 1));
    else if (rule.action === 'destroy-object') object.visible = false;
    else if (rule.action === 'change-scene') this.api.scene.change(rule.scene);
    else if (rule.action === 'play-sound') this.audio.beep(660, 0.1);
    else if (rule.action === 'show-message') this.onLog(rule.message || '¡Acción activada!');
  }

  pause() { this.paused = !this.paused; this.onLog(this.paused ? 'Ⅱ Juego pausado' : '▶ Juego reanudado'); return this.paused; }
  stop() { this.running = false; cancelAnimationFrame(this.raf); this.input.destroy(); this.onLog('■ Juego detenido'); this.onStop(); }
}

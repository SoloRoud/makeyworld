const imageCache = new Map();

function getImage(src) {
  if (!imageCache.has(src)) {
    const image = new Image();
    image.onload = () => window.dispatchEvent(new Event('makey:image-ready'));
    image.src = src;
    imageCache.set(src, image);
  }
  return imageCache.get(src);
}

const TEXT_FONTS = new Set(['Arial', 'Verdana', 'Georgia', 'Courier New', 'Trebuchet MS', 'system-ui', 'sans-serif', 'serif', 'monospace']);

function wrapText(context, text, maxWidth, wrap) {
  const paragraphs = String(text ?? '').replace(/\r/g, '').split('\n');
  const lines = [];
  for (const paragraph of paragraphs) {
    if (!wrap || !paragraph) { lines.push(paragraph); continue; }
    let line = '';
    for (const word of paragraph.split(/\s+/)) {
      const candidate = line ? `${line} ${word}` : word;
      if (context.measureText(candidate).width <= maxWidth) {
        line = candidate;
        continue;
      }
      if (line) { lines.push(line); line = ''; }
      // Break URLs and very long words that contain no spaces instead of
      // letting Canvas silently squash or clip the whole token.
      let chunk = '';
      for (const character of Array.from(word)) {
        const next = chunk + character;
        if (chunk && context.measureText(next).width > maxWidth) {
          lines.push(chunk);
          chunk = character;
        } else chunk = next;
      }
      line = chunk;
    }
    lines.push(line);
  }
  return lines.length ? lines : [''];
}

export function drawTextObject(context, object) {
  const width = Math.max(1, Number(object.width) || 1);
  const height = Math.max(1, Number(object.height) || 1);
  const fontSize = Math.max(6, Math.min(256, Number(object.fontSize) || 26));
  const family = TEXT_FONTS.has(object.fontFamily) ? object.fontFamily : 'Arial';
  const weight = object.fontWeight === 'bold' || object.bold ? 'bold' : 'normal';
  const style = object.fontStyle === 'italic' || object.italic ? 'italic' : 'normal';
  const padding = Math.max(0, Math.min(Math.min(width, height) / 2, Number(object.textPadding ?? 4)));
  const maxWidth = Math.max(1, width - padding * 2);
  const lineHeight = Math.max(0.8, Math.min(3, Number(object.lineHeight) || 1.2)) * fontSize;
  const rawText = object.text == null ? (object.name || '') : String(object.text);
  context.save();
  context.beginPath();
  context.rect(-width / 2, -height / 2, width, height);
  context.clip();
  if (object.textBackground) {
    context.fillStyle = object.backgroundColor || '#202631';
    context.fillRect(-width / 2, -height / 2, width, height);
  }
  context.font = `${style} ${weight} ${fontSize}px "${family}"`;
  context.textAlign = ['center', 'right'].includes(object.textAlign) ? object.textAlign : 'left';
  context.textBaseline = 'middle';
  const lines = wrapText(context, rawText, maxWidth, object.wrap !== false);
  const maxLines = Math.max(1, 1 + Math.floor((height - padding * 2 - fontSize) / lineHeight));
  const visibleLines = lines.slice(0, maxLines);
  if (lines.length > maxLines && visibleLines.length) {
    let last = visibleLines[visibleLines.length - 1];
    while (last && context.measureText(`${last}…`).width > maxWidth) last = last.slice(0, -1);
    visibleLines[visibleLines.length - 1] = `${last}…`;
  }
  const totalHeight = Math.max(0, (visibleLines.length - 1) * lineHeight);
  let firstY;
  if (object.verticalAlign === 'top') firstY = -height / 2 + padding + fontSize / 2;
  else if (object.verticalAlign === 'bottom') firstY = height / 2 - padding - fontSize / 2 - totalHeight;
  else firstY = -totalHeight / 2;
  const x = context.textAlign === 'center' ? 0 : context.textAlign === 'right' ? width / 2 - padding : -width / 2 + padding;
  context.fillStyle = object.color || '#ffffff';
  const outlineWidth = Math.max(0, Math.min(20, Number(object.outlineWidth) || 0));
  if (outlineWidth > 0) {
    context.strokeStyle = object.outlineColor || '#111111';
    context.lineWidth = outlineWidth;
    context.lineJoin = 'round';
  }
  visibleLines.forEach((line, index) => {
    const y = firstY + index * lineHeight;
    if (outlineWidth > 0) context.strokeText(line, x, y, maxWidth);
    context.fillText(line, x, y, maxWidth);
  });
  context.restore();
}

export function drawObject(context, object) {
  if (object.visible === false || object.opacity <= 0) return;
  context.save();
  context.globalAlpha = object.opacity ?? 1;
  context.translate(object.x + object.width / 2, object.y + object.height / 2);
  context.rotate((object.rotation || 0) * Math.PI / 180);
  if (object.type === 'text') {
    if (object.sprite) {
      const image = getImage(object.sprite);
      if (image.complete && image.naturalWidth) context.drawImage(image, -object.width / 2, -object.height / 2, object.width, object.height);
    }
    drawTextObject(context, object);
  } else if (object.sprite) {
    const image = getImage(object.sprite);
    if (image.complete && image.naturalWidth) context.drawImage(image, -object.width / 2, -object.height / 2, object.width, object.height);
  } else if (object.type === 'circle' || object.type === 'coin') {
    context.fillStyle = object.color || '#ffcf4a';
    context.beginPath();
    context.ellipse(0, 0, object.width / 2, object.height / 2, 0, 0, Math.PI * 2);
    context.fill();
    if (object.type === 'coin') {
      context.strokeStyle = '#fff0a6';
      context.lineWidth = Math.max(1, object.width * .08);
      context.stroke();
      context.fillStyle = '#a87318';
      context.font = `bold ${Math.max(9, object.width * .65)}px sans-serif`;
      context.textAlign = 'center';
      context.textBaseline = 'middle';
      context.fillText('$', 0, 1);
    }
  } else {
    context.fillStyle = object.color || '#6ba8ff';
    context.fillRect(-object.width / 2, -object.height / 2, object.width, object.height);
    if (object.type === 'player') {
      context.fillStyle = '#ffffffb8';
      context.fillRect(-object.width * .22, -object.height * .25, Math.max(3, object.width * .14), Math.max(3, object.height * .12));
      context.fillRect(object.width * .08, -object.height * .25, Math.max(3, object.width * .14), Math.max(3, object.height * .12));
    }
  }
  context.restore();
}

export function drawWorld(context, scene, settings, options = {}) {
  context.clearRect(0, 0, context.canvas.width, context.canvas.height);
  context.fillStyle = scene.background || settings.background || '#202631';
  context.fillRect(0, 0, context.canvas.width, context.canvas.height);
  const objects = [...scene.objects].sort((a, b) => (a.z || 0) - (b.z || 0));
  for (const object of objects) drawObject(context, object);
  if (options.hitboxes) {
    context.save();
    context.strokeStyle = '#ff4c75';
    context.lineWidth = 1;
    for (const object of objects) if (object.physics?.enabled) context.strokeRect(object.x, object.y, object.width, object.height);
    context.restore();
  }
}

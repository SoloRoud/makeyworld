export function stepAnimations(objects, deltaTime) {
  for (const object of objects || []) {
    const animation = object.animation;
    const frames = animation?.frames;
    if (!Array.isArray(frames) || frames.length < 2 || animation.playing === false) continue;

    const fps = Math.max(1, Math.min(60, Number(animation.fps) || 8));
    animation.elapsed = Math.max(0, Number(animation.elapsed) || 0) + Math.max(0, Number(deltaTime) || 0);
    const rawIndex = Math.floor(animation.elapsed * fps);
    let index;
    if (animation.loop === false) {
      index = Math.min(frames.length - 1, rawIndex);
      if (index === frames.length - 1) animation.elapsed = (frames.length - 1) / fps;
    } else {
      index = rawIndex % frames.length;
    }

    const frame = frames[index];
    if (frame?.sprite && object._animationFrameIndex !== index) {
      object.sprite = frame.sprite;
      object._animationFrameIndex = index;
    }
  }
}

export function resetAnimations(objects) {
  for (const object of objects || []) {
    if (object.animation) {
      object.animation.elapsed = 0;
      object._animationFrameIndex = -1;
    }
  }
}

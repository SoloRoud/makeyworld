function resolveFrameSprite(frame, assets = []) {
  let value = typeof frame === 'string'
    ? frame
    : frame?.sprite ?? frame?.src ?? frame?.dataUrl ?? frame?.dataURL ?? frame?.image ?? frame?.assetId ?? frame?.asset ?? frame?.url ?? frame?.data;

  if (value && typeof value === 'object') {
    value = value.dataUrl ?? value.dataURL ?? value.src ?? value.url ?? value.sprite ??
      value.image ?? value.data ?? value.assetId ?? value.asset ?? value.id;
  }
  if (typeof value !== 'string' || !value.trim()) return null;
  const source = value.trim();
  const key = source.startsWith('asset:') ? source.slice(6) : source;
  const asset = assets.find(item => item.id === key || item.name === key);
  return asset?.dataUrl || source;
}

export function stepAnimations(objects, deltaTime, assets = []) {
  for (const object of objects || []) {
    const animation = object.animation;
    const frames = animation?.frames;
    if (!Array.isArray(frames) || frames.length < 2 || animation.playing === false) continue;

    const fps = Math.max(1, Math.min(60, Number(animation.fps) || 8));
    animation.elapsed = Math.max(0, Number(animation.elapsed) || 0) + Math.max(0, Number(deltaTime) || 0);
    const rawIndex = Math.floor(animation.elapsed * fps);
    let index;
    if (animation.loop === false) {
      index = Math.min(frames.length - 1, rawIndex);
      if (index === frames.length - 1) animation.elapsed = (frames.length - 1) / fps;
    } else {
      index = rawIndex % frames.length;
    }

    if (object._animationFrameIndex === index) continue;
    const source = resolveFrameSprite(frames[index], assets);
    if (source) {
      object.sprite = source;
      object._animationFrameIndex = index;
    }
  }
}

export function resetAnimations(objects, assets = []) {
  for (const object of objects || []) {
    const animation = object.animation;
    if (!animation) continue;
    animation.elapsed = 0;
    object._animationFrameIndex = -1;
    const firstFrame = Array.isArray(animation.frames) ? animation.frames[0] : null;
    const firstSource = resolveFrameSprite(firstFrame, assets);
    if (firstSource) {
      object.sprite = firstSource;
      object._animationFrameIndex = 0;
    }
  }
}

export class InputManager{
 constructor(target=window){this.down=new Set();this.pressed=new Set();this.released=new Set();this.keys={left:['ArrowLeft','a','A'],right:['ArrowRight','d','D'],up:['ArrowUp','w','W'],down:['ArrowDown','s','S'],jump:[' ','ArrowUp','w','W']};this.onDown=e=>{if(!this.down.has(e.key))this.pressed.add(e.key);this.down.add(e.key);};this.onUp=e=>{this.down.delete(e.key);this.released.add(e.key);};target.addEventListener('keydown',this.onDown);target.addEventListener('keyup',this.onUp);this.target=target;}
 normalize(key){return key==='Space'?' ':key;}
 isDown(key){key=this.normalize(key);return this.down.has(key)||this.down.has(key.toLowerCase())||this.down.has(key.toUpperCase());}
 isPressed(key){key=this.normalize(key);return this.pressed.has(key)||this.pressed.has(key.toLowerCase())||this.pressed.has(key.toUpperCase());}
 action(name){return (this.keys[name]||[]).some(k=>this.isDown(k));}
 endFrame(){this.pressed.clear();this.released.clear();}
 destroy(){this.target.removeEventListener('keydown',this.onDown);this.target.removeEventListener('keyup',this.onUp);}
}

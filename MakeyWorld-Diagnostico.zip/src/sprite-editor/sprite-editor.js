import { state } from '../core/state.js';
import { addDataAsset } from '../assets/asset-manager.js';
import { addObject } from '../core/commands.js';
import { toast } from '../ui/dom.js';

let modalEl, canvas, canvasCtx;
let spriteWidth = 32, spriteHeight = 32, zoom = 12, brushSize = 1;
let layers = [], activeLayer = 0, tool = 'pencil', color = '#ff8a24';
let frames = [], frameIndex = 0, drawing = null;

const blankCanvas = (w = spriteWidth, h = spriteHeight) => {
  const c = document.createElement('canvas'); c.width = w; c.height = h; return c;
};
const makeLayer = (name) => ({ name, canvas: blankCanvas(), visible: true, opacity: 1 });
function composite() {
  const out = blankCanvas(); const c = out.getContext('2d');
  for (const layer of layers) if (layer.visible) { c.globalAlpha = layer.opacity; c.drawImage(layer.canvas, 0, 0); }
  c.globalAlpha = 1; return out;
}
function paint() {
  if (!canvasCtx) return;
  canvasCtx.clearRect(0, 0, canvas.width, canvas.height);
  canvasCtx.imageSmoothingEnabled = false;
  canvasCtx.drawImage(composite(), 0, 0, canvas.width, canvas.height);
}
function setZoom() { canvas.style.width = `${spriteWidth * zoom}px`; canvas.style.height = `${spriteHeight * zoom}px`; paint(); }
function pointerPoint(event) {
  const rect = canvas.getBoundingClientRect();
  return {
    x: Math.max(0, Math.min(spriteWidth - 1, Math.floor((event.clientX - rect.left) * spriteWidth / rect.width))),
    y: Math.max(0, Math.min(spriteHeight - 1, Math.floor((event.clientY - rect.top) * spriteHeight / rect.height)))
  };
}
function plotPixel(x, y) {
  const ctx = layers[activeLayer].canvas.getContext('2d');
  if (tool === 'eraser') ctx.clearRect(x - Math.floor(brushSize / 2), y - Math.floor(brushSize / 2), brushSize, brushSize);
  else { ctx.fillStyle = color; ctx.fillRect(x - Math.floor(brushSize / 2), y - Math.floor(brushSize / 2), brushSize, brushSize); }
}
function linePixels(from, to) {
  let x0 = from.x, y0 = from.y, x1 = to.x, y1 = to.y;
  const dx = Math.abs(x1 - x0), sx = x0 < x1 ? 1 : -1;
  const dy = -Math.abs(y1 - y0), sy = y0 < y1 ? 1 : -1;
  let err = dx + dy;
  while (true) { plotPixel(x0, y0); if (x0 === x1 && y0 === y1) break; const e2 = 2 * err; if (e2 >= dy) { err += dy; x0 += sx; } if (e2 <= dx) { err += dx; y0 += sy; } }
}
function rgbaFromHex(hex) { return [parseInt(hex.slice(1, 3), 16), parseInt(hex.slice(3, 5), 16), parseInt(hex.slice(5, 7), 16), 255]; }
function bucketFill(x, y) {
  const ctx = layers[activeLayer].canvas.getContext('2d');
  const image = ctx.getImageData(0, 0, spriteWidth, spriteHeight), pixels = image.data;
  const offset = (y * spriteWidth + x) * 4;
  const target = [...pixels.slice(offset, offset + 4)], fill = rgbaFromHex(color);
  if (target.every((v, i) => v === fill[i])) return;
  const stack = [[x, y]], visited = new Uint8Array(spriteWidth * spriteHeight);
  while (stack.length) {
    const [px, py] = stack.pop();
    if (px < 0 || py < 0 || px >= spriteWidth || py >= spriteHeight) continue;
    const pos = py * spriteWidth + px; if (visited[pos]) continue; visited[pos] = 1;
    const i = pos * 4;
    if (pixels[i] !== target[0] || pixels[i + 1] !== target[1] || pixels[i + 2] !== target[2] || pixels[i + 3] !== target[3]) continue;
    pixels[i] = fill[0]; pixels[i + 1] = fill[1]; pixels[i + 2] = fill[2]; pixels[i + 3] = fill[3];
    stack.push([px + 1, py], [px - 1, py], [px, py + 1], [px, py - 1]);
  }
  ctx.putImageData(image, 0, 0);
}
function captureFrame() {
  return layers.map(layer => ({ name: layer.name, visible: layer.visible, opacity: layer.opacity, data: layer.canvas.toDataURL('image/png') }));
}
async function loadFrame(snapshot) {
  layers = await Promise.all(snapshot.map(async item => {
    const c = blankCanvas();
    if (item.data) {
      const image = new Image(); image.src = item.data;
      await new Promise(resolve => { image.onload = resolve; image.onerror = resolve; });
      if (image.complete && image.naturalWidth) c.getContext('2d').drawImage(image, 0, 0, spriteWidth, spriteHeight);
    }
    return { name: item.name, visible: item.visible !== false, opacity: item.opacity ?? 1, canvas: c };
  }));
  activeLayer = Math.min(activeLayer, layers.length - 1); renderLayers(); paint(); updateFrameLabel();
}
function saveCurrentFrame() { frames[frameIndex] = captureFrame(); }
function updateFrameLabel() {
  const label = modalEl.querySelector('[data-frame-label]');
  if (label) label.textContent = `Fotograma ${frameIndex + 1} de ${frames.length}`;
  modalEl.querySelector('[data-frame-prev]').disabled = frameIndex <= 0;
  modalEl.querySelector('[data-frame-next]').disabled = frameIndex >= frames.length - 1;
}
function renderLayers() {
  const list = modalEl.querySelector('[data-layers]');
  list.innerHTML = layers.map((layer, index) => `<div class="layer-row ${index === activeLayer ? 'active' : ''}" data-layer="${index}"><input type="checkbox" data-layer-visible="${index}" ${layer.visible ? 'checked' : ''}><span>${escapeHTML(layer.name)}</span></div>`).join('');
  list.querySelectorAll('[data-layer]').forEach(row => row.onclick = event => {
    if (event.target.matches('input')) return;
    activeLayer = Number(row.dataset.layer); renderLayers();
    modalEl.querySelector('[data-layer-opacity]').value = layers[activeLayer].opacity;
  });
  list.querySelectorAll('[data-layer-visible]').forEach(input => input.onchange = () => { layers[Number(input.dataset.layerVisible)].visible = input.checked; paint(); saveCurrentFrame(); });
  modalEl.querySelector('[data-layer-opacity]').value = layers[activeLayer].opacity;
}
function escapeHTML(value) { return String(value).replace(/[&<>"']/g, char => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[char])); }
function downloadDataURL(url, filename) { const a = document.createElement('a'); a.href = url; a.download = filename; a.click(); }
function drawLineOrRectPreview(point) {
  paint(); const ctx = canvasCtx; ctx.save(); ctx.scale(zoom, zoom); ctx.strokeStyle = color; ctx.lineWidth = 1;
  if (tool === 'line') { ctx.beginPath(); ctx.moveTo(drawing.start.x + .5, drawing.start.y + .5); ctx.lineTo(point.x + .5, point.y + .5); ctx.stroke(); }
  else ctx.strokeRect(drawing.start.x + .5, drawing.start.y + .5, point.x - drawing.start.x, point.y - drawing.start.y);
  ctx.restore();
}
function pointerDown(event) {
  canvas.setPointerCapture(event.pointerId);
  const point = pointerPoint(event); drawing = { start: point, last: point };
  if (tool === 'fill') { bucketFill(point.x, point.y); paint(); return; }
  if (tool === 'eyedropper') {
    const data = layers[activeLayer].canvas.getContext('2d').getImageData(point.x, point.y, 1, 1).data;
    color = `#${[...data.slice(0, 3)].map(v => v.toString(16).padStart(2, '0')).join('')}`;
    modalEl.querySelector('[data-color]').value = color; return;
  }
  if (tool === 'pencil' || tool === 'eraser') { plotPixel(point.x, point.y); paint(); }
}
function pointerMove(event) {
  if (!drawing) return;
  const point = pointerPoint(event);
  if (tool === 'pencil' || tool === 'eraser') { linePixels(drawing.last, point); drawing.last = point; paint(); }
  else if (tool === 'line' || tool === 'rect') drawLineOrRectPreview(point);
}
function pointerUp(event) {
  if (!drawing) return;
  const point = pointerPoint(event), ctx = layers[activeLayer].canvas.getContext('2d');
  if (tool === 'line') { ctx.strokeStyle = color; ctx.lineWidth = 1; ctx.beginPath(); ctx.moveTo(drawing.start.x + .5, drawing.start.y + .5); ctx.lineTo(point.x + .5, point.y + .5); ctx.stroke(); }
  if (tool === 'rect') { ctx.strokeStyle = color; ctx.lineWidth = 1; ctx.strokeRect(drawing.start.x + .5, drawing.start.y + .5, point.x - drawing.start.x, point.y - drawing.start.y); }
  drawing = null; paint(); saveCurrentFrame();
}

export function openSpriteEditor({ width = 32, height = 32 } = {}) {
  spriteWidth = Math.max(8, Math.min(256, Number(width) || 32));
  spriteHeight = Math.max(8, Math.min(256, Number(height) || 32));
  zoom = 12; brushSize = 1; layers = [makeLayer('Capa 1')]; activeLayer = 0; frames = [captureFrame()]; frameIndex = 0; tool = 'pencil'; color = '#ff8a24'; drawing = null;
  const backdrop = document.createElement('div'); backdrop.className = 'modal-backdrop';
  backdrop.innerHTML = `<section class="modal sprite-modal">
    <header class="modal-head"><span>Makey Pixel Studio <span class="pill">Editor de sprites</span></span><button class="btn ghost icon" data-close>×</button></header>
    <div class="sprite-size-controls"><span class="muted tiny">Lienzo</span> W <input type="number" data-width value="${spriteWidth}" min="8" max="256"> H <input type="number" data-height value="${spriteHeight}" min="8" max="256"><button class="btn small" data-resize>Aplicar tamaño</button><span class="muted tiny">Zoom</span><input type="range" min="4" max="24" value="12" data-zoom></div>
    <div class="sprite-workspace"><div class="sprite-tools">${[['pencil','✎','Lápiz'],['eraser','▱','Goma'],['fill','▨','Relleno'],['eyedropper','⌖','Cuentagotas'],['line','╱','Línea'],['rect','□','Rectángulo']].map(([id,icon,label]) => `<button class="btn icon ${id === tool ? 'selected' : ''}" title="${label}" data-tool="${id}">${icon}</button>`).join('')}<div class="divider"></div><input type="color" data-color value="${color}" title="Color" style="width:34px;height:34px;padding:2px;border:0;background:transparent"><label class="tiny muted">Tamaño</label><input type="range" min="1" max="8" value="1" data-brush style="width:100%"><div class="tool-hint">Dibuja con el ratón o el panel táctil.</div></div>
      <div class="sprite-canvas-wrap"><canvas class="sprite-canvas" data-canvas></canvas></div>
      <aside class="sprite-right"><div class="section-head" style="padding:2px 0 8px">Capas <button class="btn small" data-add-layer>＋</button></div><div data-layers></div><div class="field"><label>Opacidad de capa</label><input type="range" min="0" max="1" step="0.05" data-layer-opacity></div><button class="btn small" data-rename-layer>Renombrar</button> <button class="btn small danger" data-remove-layer>Eliminar</button><div class="divider"></div><div class="section-head" style="padding:2px 0 8px">Paleta rápida</div><div class="swatches">${['#ff8a24','#ffffff','#111827','#e95d5d','#65bf91','#6197ed','#f4d35e','#a78bfa','#f6a5c0','#7c5c44','#626a76','#000000'].map(value => `<button class="swatch" style="background:${value}" data-swatch="${value}"></button>`).join('')}</div><div class="divider"></div><div class="section-head" style="padding:2px 0 8px">Animación</div><div class="tool-group"><button class="btn small" data-frame-add>＋ Vacío</button><button class="btn small" data-frame-duplicate>Duplicar</button></div><div class="tool-group" style="margin-top:6px"><button class="btn small" data-frame-prev>←</button><button class="btn small" data-frame-next>→</button></div><div class="tiny muted" data-frame-label style="margin-top:8px">Fotograma 1</div></aside>
    </div><div class="sprite-bottom"><button class="btn small" data-import-sprite>Importar imagen</button><button class="btn small" data-export-sprite>Exportar PNG</button><button class="btn small" data-export-sheet>Exportar spritesheet</button><span class="muted tiny" style="margin-left:auto">Se almacena dentro del proyecto.</span><button class="btn primary" data-use-sprite>Usar en el juego</button></div>
    </section>`;
  document.body.append(back); modalEl = back; canvas = back.querySelector('[data-canvas]');
  canvas.width = spriteWidth; canvas.height = spriteHeight; canvasCtx = canvas.getContext('2d'); setZoom(); renderLayers(); updateFrameLabel();
  back.querySelector('[data-close]').onclick = () => back.remove();
  back.querySelectorAll('[data-tool]').forEach(button => button.onclick = () => { tool = button.dataset.tool; back.querySelectorAll('[data-tool]').forEach(b => b.classList.toggle('selected', b === button)); });
  canvas.addEventListener('pointerdown', pointerDown); canvas.addEventListener('pointermove', pointerMove); canvas.addEventListener('pointerup', pointerUp); canvas.addEventListener('pointercancel', pointerUp);
  back.querySelector('[data-color]').oninput = event => color = event.target.value;
  back.querySelector('[data-brush]').oninput = event => brushSize = Number(event.target.value);
  back.querySelector('[data-zoom]').oninput = event => { zoom = Number(event.target.value); setZoom(); };
  back.querySelectorAll('[data-swatch]').forEach(button => button.onclick = () => { color = button.dataset.swatch; back.querySelector('[data-color]').value = color; });
  back.querySelector('[data-add-layer]').onclick = () => { layers.push(makeLayer(`Capa ${layers.length + 1}`)); activeLayer = layers.length - 1; renderLayers(); paint(); saveCurrentFrame(); };
  back.querySelector('[data-remove-layer]').onclick = () => { if (layers.length < 2) { toast('Debe quedar al menos una capa.'); return; } layers.splice(activeLayer, 1); activeLayer = Math.max(0, activeLayer - 1); renderLayers(); paint(); saveCurrentFrame(); };
  back.querySelector('[data-rename-layer]').onclick = () => { const name = prompt('Nombre de la capa:', layers[activeLayer].name); if (name?.trim()) { layers[activeLayer].name = name.trim(); renderLayers(); saveCurrentFrame(); } };
  back.querySelector('[data-layer-opacity]').oninput = event => { layers[activeLayer].opacity = Number(event.target.value); paint(); saveCurrentFrame(); };
  back.querySelector('[data-resize]').onclick = () => resizeSprite(Number(back.querySelector('[data-width]').value), Number(back.querySelector('[data-height]').value));
  back.querySelector('[data-import-sprite]').onclick = importSpriteImage;
  back.querySelector('[data-export-sprite]').onclick = () => downloadDataURL(composite().toDataURL('image/png'), 'makey-sprite.png');
  back.querySelector('[data-export-sheet]').onclick = exportSpriteSheet;
  back.querySelector('[data-frame-add]').onclick = () => { saveCurrentFrame(); frames.splice(frameIndex + 1, 0, layers.map(layer => ({ name: layer.name, visible: layer.visible, opacity: layer.opacity, data: blankCanvas().toDataURL('image/png') }))); frameIndex++; loadFrame(frames[frameIndex]); };
  back.querySelector('[data-frame-duplicate]').onclick = () => { saveCurrentFrame(); frames.splice(frameIndex + 1, 0, structuredClone(frames[frameIndex])); frameIndex++; loadFrame(frames[frameIndex]); };
  back.querySelector('[data-frame-prev]').onclick = () => changeFrame(-1);
  back.querySelector('[data-frame-next]').onclick = () => changeFrame(1);
  back.querySelector('[data-use-sprite]').onclick = () => {
    saveCurrentFrame(); const item = addDataAsset(`sprite-${Date.now()}.png`, composite().toDataURL('image/png'));
    const selected = state.selected[0];
    if (selected) { selected.sprite = item.dataUrl; selected.color = '#ffffff'; state.touch('Sprite aplicado'); toast('Sprite aplicado al objeto.', 'success'); }
    else { const object = addObject('rect', { name: 'Sprite nuevo', width: spriteWidth, height: spriteHeight, sprite: item.dataUrl, color: '#ffffff' }); toast(`Creado ${object.name} en la escena.`, 'success'); }
    back.remove();
  };
}

function changeFrame(delta) { saveCurrentFrame(); const next = frameIndex + delta; if (next < 0 || next >= frames.length) return; frameIndex = next; loadFrame(frames[frameIndex]); }
function resizeSprite(width, height) {
  const nextWidth = Math.max(8, Math.min(256, Number(width) || 32)), nextHeight = Math.max(8, Math.min(256, Number(height) || 32));
  spriteWidth = nextWidth; spriteHeight = nextHeight;
  layers = layers.map(layer => { const c = blankCanvas(); c.getContext('2d').drawImage(layer.canvas, 0, 0, nextWidth, nextHeight); return { ...layer, canvas: c }; });
  frames = [captureFrame()]; frameIndex = 0; canvas.width = spriteWidth; canvas.height = spriteHeight; setZoom(); updateFrameLabel();
}
function importSpriteImage() {
  const input = document.createElement('input'); input.type = 'file'; input.accept = 'image/*';
  input.onchange = () => { const file = input.files?.[0]; if (!file) return; const url = URL.createObjectURL(file), image = new Image();
    image.onload = () => { const ctx = layers[activeLayer].canvas.getContext('2d'); ctx.clearRect(0, 0, spriteWidth, spriteHeight); ctx.drawImage(image, 0, 0, spriteWidth, spriteHeight); URL.revokeObjectURL(url); paint(); saveCurrentFrame(); };
    image.onerror = () => { URL.revokeObjectURL(url); toast('No se ha podido abrir esa imagen.', 'error'); }; image.src = url;
  }; input.click();
}
async function exportSpriteSheet() {
  saveCurrentFrame(); const sheet = document.createElement('canvas'); sheet.width = spriteWidth * frames.length; sheet.height = spriteHeight; const ctx = sheet.getContext('2d');
  for (let i = 0; i < frames.length; i++) {
    const combined = blankCanvas(); const c = combined.getContext('2d');
    for (const layer of frames[i]) if (layer.visible) { const image = new Image(); image.src = layer.data; await new Promise(resolve => { image.onload = resolve; image.onerror = resolve; }); if (image.complete && image.naturalWidth) { c.globalAlpha = layer.opacity ?? 1; c.drawImage(image, 0, 0, spriteWidth, spriteHeight); } }
    ctx.drawImage(combined, i * spriteWidth, 0);
  }
  downloadDataURL(sheet.toDataURL('image/png'), 'makey-spritesheet.png');
}

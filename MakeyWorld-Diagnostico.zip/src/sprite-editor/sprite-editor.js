import { state } from '../core/state.js';
import { addDataAsset } from '../assets/asset-manager.js';
import { addObject } from '../core/commands.js';
import { record } from '../core/history.js';
import { toast } from '../ui/dom.js';
import { moveFrame, movedFrameIndex } from './frame-utils.js';

let modalEl = null;
let canvas = null;
let canvasCtx = null;
let previewCanvas = null;
let previewCtx = null;
let spriteWidth = 32;
let spriteHeight = 32;
let zoom = 12;
let brushSize = 1;
let layers = [];
let activeLayer = 0;
let tool = 'pencil';
let color = '#ff8a24';
let frames = [];
let frameIndex = 0;
let drawing = null;
let previewTimer = null;
let previewIndex = 0;
let previewPlaying = false;
let fps = 8;
let loopAnimation = true;
let targetObjectId = null;
let spriteUndoStack = [];
let spriteRedoStack = [];
let timelineRenderVersion = 0;
let previewRenderVersion = 0;
let previewImages = [];
let previewCacheVersion = 0;
let previewLoading = false;
let previewRequestVersion = 0;
let frameLoadVersion = 0;
let spriteSession = 0;
let artworkLoadFailed = false;

const clamp = (value, min, max) => Math.max(min, Math.min(max, Number(value) || min));
const blankCanvas = (w = spriteWidth, h = spriteHeight) => {
  const element = document.createElement('canvas');
  element.width = w;
  element.height = h;
  return element;
};
const makeLayer = (name) => ({ name, canvas: blankCanvas(), visible: true, opacity: 1 });

function escapeHTML(value) {
  return String(value ?? '').replace(/[&<>"']/g, char => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[char]));
}

function loadImage(source) {
  return new Promise(resolve => {
    if (!source) return resolve(null);
    const image = new Image();
    let settled = false;
    const finish = value => {
      if (settled) return;
      settled = true;
      clearTimeout(timeout);
      resolve(value);
    };
    const timeout = setTimeout(() => finish(null), 8000);
    image.onload = () => finish(image);
    image.onerror = () => finish(null);
    if (!/^(data:|blob:)/i.test(String(source))) image.crossOrigin = 'anonymous';
    image.src = source;
  });
}

function imageHasVisiblePixels(image) {
  if (!image) return false;
  try {
    const probe = blankCanvas(spriteWidth, spriteHeight);
    const context = probe.getContext('2d', { willReadFrequently: true });
    context.drawImage(image, 0, 0, spriteWidth, spriteHeight);
    const pixels = context.getImageData(0, 0, spriteWidth, spriteHeight).data;
    for (let index = 3; index < pixels.length; index += 4) {
      if (pixels[index] > 0) return true;
    }
    return false;
  } catch {
    // Cross-origin images may be drawable but taint the canvas. Treat them as
    // non-empty; the editor must never replace a valid drawing with a blank.
    return true;
  }
}

function imageLayerSnapshot(image, name = 'Sprite recuperado') {
  const target = blankCanvas(spriteWidth, spriteHeight);
  if (image) target.getContext('2d').drawImage(image, 0, 0, spriteWidth, spriteHeight);
  return [{ name, visible: true, opacity: 1, data: target.toDataURL('image/png') }];
}

function savedLayersMatchImage(checkedLayers, expectedImage) {
  if (!expectedImage) return true;
  try {
    const compositeCanvas = blankCanvas(spriteWidth, spriteHeight);
    const compositeContext = compositeCanvas.getContext('2d', { willReadFrequently: true });
    for (const { layer, image } of checkedLayers) {
      if (!image || layer?.visible === false) continue;
      compositeContext.globalAlpha = clamp(layer?.opacity ?? 1, 0, 1);
      compositeContext.drawImage(image, 0, 0, spriteWidth, spriteHeight);
    }
    compositeContext.globalAlpha = 1;
    const expectedCanvas = blankCanvas(spriteWidth, spriteHeight);
    expectedCanvas.getContext('2d').drawImage(expectedImage, 0, 0, spriteWidth, spriteHeight);
    const actual = compositeContext.getImageData(0, 0, spriteWidth, spriteHeight).data;
    const expected = expectedCanvas.getContext('2d', { willReadFrequently: true }).getImageData(0, 0, spriteWidth, spriteHeight).data;
    let differentPixels = 0;
    for (let index = 0; index < actual.length; index += 4) {
      if (Math.abs(actual[index] - expected[index]) > 2 ||
          Math.abs(actual[index + 1] - expected[index + 1]) > 2 ||
          Math.abs(actual[index + 2] - expected[index + 2]) > 2 ||
          Math.abs(actual[index + 3] - expected[index + 3]) > 2) {
        differentPixels++;
        if (differentPixels > Math.max(2, spriteWidth * spriteHeight * 0.001)) return false;
      }
    }
    return true;
  } catch {
    // If pixel comparison is blocked (for example by a remote image without
    // CORS), don't trust a possibly incomplete layer stack over the PNG.
    return false;
  }
}

function composite(sourceLayers = layers) {
  const output = blankCanvas();
  const context = output.getContext('2d');
  context.imageSmoothingEnabled = false;
  for (const layer of sourceLayers) {
    if (!layer.visible) continue;
    context.globalAlpha = layer.opacity ?? 1;
    context.drawImage(layer.canvas, 0, 0);
  }
  context.globalAlpha = 1;
  return output;
}

function paint() {
  if (!canvasCtx || !canvas) return;
  canvasCtx.clearRect(0, 0, canvas.width, canvas.height);
  canvasCtx.imageSmoothingEnabled = false;
  canvasCtx.drawImage(composite(), 0, 0);
}

function setZoom() {
  if (!canvas) return;
  canvas.style.width = `${spriteWidth * zoom}px`;
  canvas.style.height = `${spriteHeight * zoom}px`;
  paint();
}

function pointerPoint(event) {
  const rect = canvas.getBoundingClientRect();
  return {
    x: Math.max(0, Math.min(spriteWidth - 1, Math.floor((event.clientX - rect.left) * spriteWidth / Math.max(1, rect.width)))),
    y: Math.max(0, Math.min(spriteHeight - 1, Math.floor((event.clientY - rect.top) * spriteHeight / Math.max(1, rect.height))))
  };
}

function plotPixel(x, y) {
  const context = layers[activeLayer].canvas.getContext('2d');
  const offset = Math.floor(brushSize / 2);
  if (tool === 'eraser') context.clearRect(x - offset, y - offset, brushSize, brushSize);
  else {
    context.fillStyle = color;
    context.fillRect(x - offset, y - offset, brushSize, brushSize);
  }
}

function linePixels(from, to) {
  let x0 = from.x, y0 = from.y, x1 = to.x, y1 = to.y;
  const dx = Math.abs(x1 - x0), sx = x0 < x1 ? 1 : -1;
  const dy = -Math.abs(y1 - y0), sy = y0 < y1 ? 1 : -1;
  let error = dx + dy;
  while (true) {
    plotPixel(x0, y0);
    if (x0 === x1 && y0 === y1) break;
    const twice = 2 * error;
    if (twice >= dy) { error += dy; x0 += sx; }
    if (twice <= dx) { error += dx; y0 += sy; }
  }
}

function rgbaFromHex(hex) {
  return [parseInt(hex.slice(1, 3), 16), parseInt(hex.slice(3, 5), 16), parseInt(hex.slice(5, 7), 16), 255];
}

function bucketFill(x, y) {
  const context = layers[activeLayer].canvas.getContext('2d');
  const image = context.getImageData(0, 0, spriteWidth, spriteHeight);
  const pixels = image.data;
  const offset = (y * spriteWidth + x) * 4;
  const target = [...pixels.slice(offset, offset + 4)];
  const fill = rgbaFromHex(color);
  if (target.every((value, index) => value === fill[index])) return;
  const stack = [[x, y]];
  const visited = new Uint8Array(spriteWidth * spriteHeight);
  while (stack.length) {
    const [px, py] = stack.pop();
    if (px < 0 || py < 0 || px >= spriteWidth || py >= spriteHeight) continue;
    const position = py * spriteWidth + px;
    if (visited[position]) continue;
    visited[position] = 1;
    const index = position * 4;
    if (pixels[index] !== target[0] || pixels[index + 1] !== target[1] || pixels[index + 2] !== target[2] || pixels[index + 3] !== target[3]) continue;
    pixels[index] = fill[0]; pixels[index + 1] = fill[1]; pixels[index + 2] = fill[2]; pixels[index + 3] = fill[3];
    stack.push([px + 1, py], [px - 1, py], [px, py + 1], [px, py - 1]);
  }
  context.putImageData(image, 0, 0);
}

function captureFrame() {
  return layers.map(layer => ({
    name: layer.name,
    visible: layer.visible,
    opacity: layer.opacity,
    data: layer.canvas.toDataURL('image/png')
  }));
}

async function loadFrame(snapshot) {
  const version = ++frameLoadVersion;
  const source = Array.isArray(snapshot) && snapshot.length ? snapshot : [{ name: 'Capa 1', visible: true, opacity: 1, data: '' }];
  const loadedLayers = await Promise.all(source.map(async (item, index) => {
    const target = blankCanvas();
    const image = await loadImage(item.data);
    if (image) target.getContext('2d').drawImage(image, 0, 0, spriteWidth, spriteHeight);
    return {
      name: item.name || `Capa ${index + 1}`,
      visible: item.visible !== false,
      opacity: clamp(item.opacity ?? 1, 0, 1),
      canvas: target
    };
  }));
  if (version !== frameLoadVersion || !modalEl) return;
  layers = loadedLayers;
  activeLayer = clamp(activeLayer, 0, layers.length - 1);
  renderLayers();
  paint();
  updateFrameLabel();
  renderTimeline();
}

function pushSpriteUndo() {
  if (!layers.length) return;
  if (previewPlaying || previewLoading) stopPreview();
  saveCurrentFrame();
  spriteUndoStack.push({
    frameIndex,
    frames: structuredClone(frames),
    width: spriteWidth,
    height: spriteHeight,
    activeLayer
  });
  if (spriteUndoStack.length > 30) spriteUndoStack.shift();
  spriteRedoStack.length = 0;
  updateSpriteHistoryButtons();
}

function updateSpriteHistoryButtons() {
  const undoButton = modalEl?.querySelector('[data-sprite-undo]');
  const redoButton = modalEl?.querySelector('[data-sprite-redo]');
  if (undoButton) undoButton.disabled = spriteUndoStack.length === 0;
  if (redoButton) redoButton.disabled = spriteRedoStack.length === 0;
}

async function applySpriteHistory(from, to) {
  if (!from.length) return;
  saveCurrentFrame();
  const current = {
    frameIndex,
    frames: structuredClone(frames),
    width: spriteWidth,
    height: spriteHeight,
    activeLayer
  };
  to.push(current);
  const entry = from.pop();
  frames = structuredClone(entry.frames || [entry.snapshot || captureFrame()]);
  spriteWidth = entry.width || spriteWidth;
  spriteHeight = entry.height || spriteHeight;
  frameIndex = Math.max(0, Math.min(frames.length - 1, entry.frameIndex));
  activeLayer = entry.activeLayer || 0;
  if (canvas) { canvas.width = spriteWidth; canvas.height = spriteHeight; }
  await loadFrame(frames[frameIndex]);
  if (modalEl) {
    modalEl.querySelector('[data-width]').value = spriteWidth;
    modalEl.querySelector('[data-height]').value = spriteHeight;
    modalEl.querySelector('[data-dimensions]').textContent = `${spriteWidth}×${spriteHeight}px`;
    setZoom();
    drawPreviewFrame(frameIndex);
  }
  updateSpriteHistoryButtons();
}

function saveCurrentFrame() {
  if (!layers.length || !frames.length) return;
  frames[frameIndex] = captureFrame();
  previewImages = [];
  previewCacheVersion++;
  renderTimeline();
}

function resolveSpriteSource(value) {
  if (!value) return null;
  if (typeof value === 'object') {
    const nested = value.dataUrl || value.dataURL || value.src || value.url || value.sprite || value.image || value.data;
    if (nested && nested !== value) return resolveSpriteSource(nested);
    if (value.assetId || value.id) return resolveSpriteSource(value.assetId || value.id);
    return null;
  }
  const source = String(value).trim();
  if (!source) return null;
  const assetKey = source.startsWith('asset:') ? source.slice(6) : source;
  const asset = state.project?.assets?.find(item => item.id === assetKey || item.name === assetKey);
  if (asset?.dataUrl) return asset.dataUrl;
  return source;
}

function getFrameSource(frame) {
  if (typeof frame === 'string') return resolveSpriteSource(frame);
  if (!frame || typeof frame !== 'object') return null;
  return resolveSpriteSource(
    frame.sprite ?? frame.src ?? frame.dataUrl ?? frame.dataURL ?? frame.image ??
    frame.assetId ?? frame.asset ?? frame.url ?? frame.data
  );
}

async function loadExistingArtwork(object, session) {
  if (!object) return false;

  const animationFrames = Array.isArray(object.animation?.frames) ? object.animation.frames : [];
  // Empty arrays were previously treated as existing artwork. That could make
  // an object with an empty spriteLayers field open as a blank canvas.
  const staticLayers = Array.isArray(object.spriteLayers) && object.spriteLayers.length
    ? object.spriteLayers
    : null;
  const frameSources = animationFrames.map(getFrameSource);
  const baseSource = resolveSpriteSource(
    object.sprite ?? object.spriteData ?? object.spriteAssetId ?? object.assetId
  );
  const hasSourceReference = Boolean(baseSource || frameSources.some(Boolean));

  const [loadedFrameImages, baseImage] = await Promise.all([
    Promise.all(frameSources.map(source => loadImage(source))),
    loadImage(baseSource)
  ]);
  if (session !== spriteSession || !modalEl) return false;

  const firstImage = loadedFrameImages.find(Boolean) || baseImage || null;
  const hasLayerData = Boolean(staticLayers) || animationFrames.some(frame => Array.isArray(frame?.layers) && frame.layers.length);
  if (!firstImage && !hasLayerData) {
    if (hasSourceReference) {
      artworkLoadFailed = true;
      const saveButton = modalEl?.querySelector('[data-use-sprite]');
      if (saveButton) saveButton.disabled = true;
      toast('No se pudo recuperar el archivo de imagen del objeto. El guardado queda bloqueado para no borrar el diseño.', 'error');
      return false;
    }
    // No image is not a load failure: selected objects without a sprite are
    // valid blank canvases which the user may start drawing on.
    frames = [captureFrame()];
    frameIndex = 0;
    return false;
  }

  const animationWidth = Number(object.animation?.width);
  const animationHeight = Number(object.animation?.height);
  spriteWidth = clamp(animationWidth || firstImage?.naturalWidth || spriteWidth, 8, 256);
  spriteHeight = clamp(animationHeight || firstImage?.naturalHeight || spriteHeight, 8, 256);
  canvas.width = spriteWidth;
  canvas.height = spriteHeight;

  const frameCount = Math.max(animationFrames.length, 1);
  const rebuiltFrames = [];
  for (let index = 0; index < frameCount; index++) {
    if (session !== spriteSession || !modalEl) return false;
    const frame = animationFrames[index];
    const savedLayers = Array.isArray(frame?.layers) && frame.layers.length
      ? frame.layers
      : (index === 0 ? staticLayers : null);
    const frameImage = loadedFrameImages[index] || (index === 0 ? baseImage : null);

    let rebuiltLayers = null;
    if (frameSources[index] && !loadedFrameImages[index] && !savedLayers?.length) {
      artworkLoadFailed = true;
      const saveButton = modalEl?.querySelector('[data-use-sprite]');
      if (saveButton) saveButton.disabled = true;
      toast(`La imagen del fotograma ${index + 1} no se pudo cargar. El guardado queda bloqueado para proteger el diseño.`, 'error');
      return false;
    }
    if (savedLayers?.length) {
      const checkedLayers = await Promise.all(savedLayers.map(async (layer, layerIndex) => ({
        layer,
        image: await loadImage(layer?.data || layer?.dataUrl || layer?.src),
        layerIndex
      })));
      if (session !== spriteSession || !modalEl) return false;
      const hasLoadedLayer = checkedLayers.some(({ image }) => Boolean(image));
      if (!hasLoadedLayer && !frameImage && (hasSourceReference || savedLayers.some(layer => layer?.data || layer?.dataUrl || layer?.src))) {
        artworkLoadFailed = true;
        const saveButton = modalEl?.querySelector('[data-use-sprite]');
        if (saveButton) saveButton.disabled = true;
        toast(`No se pudo recuperar el fotograma ${index + 1}. No se permitirá guardar para evitar perderlo.`, 'error');
        return false;
      }
      const hasPaintedLayer = checkedLayers.some(({ layer, image }) =>
        image && layer?.visible !== false && Number(layer?.opacity ?? 1) > 0 && imageHasVisiblePixels(image)
      );
      if (frameSources[index] && !loadedFrameImages[index] && !hasPaintedLayer) {
        artworkLoadFailed = true;
        const saveButton = modalEl?.querySelector('[data-use-sprite]');
        if (saveButton) saveButton.disabled = true;
        toast(`La imagen del fotograma ${index + 1} no se pudo cargar. El guardado queda bloqueado para proteger el diseño.`, 'error');
        return false;
      }

      const layersMatch = !frameImage || savedLayersMatchImage(checkedLayers, frameImage);
      if ((hasPaintedLayer && layersMatch) || !frameImage || !imageHasVisiblePixels(frameImage)) {
        rebuiltLayers = checkedLayers.map(({ layer, image, layerIndex }) => {
          const fallback = blankCanvas(spriteWidth, spriteHeight);
          if (image) fallback.getContext('2d').drawImage(image, 0, 0, spriteWidth, spriteHeight);
          return {
            name: layer?.name || `Capa ${layerIndex + 1}`,
            visible: layer?.visible !== false,
            opacity: clamp(layer?.opacity ?? 1, 0, 1),
            data: fallback.toDataURL('image/png')
          };
        });
      }
    }

    // Several older versions persisted empty/transparent layer snapshots next
    // to a valid flattened PNG. Prefer the real PNG in that case rather than
    // silently replacing a user's drawing with transparent pixels.
    if (!rebuiltLayers?.length) {
      if (frameImage) rebuiltLayers = imageLayerSnapshot(frameImage, 'Sprite recuperado');
      else if (savedLayers?.length) {
        rebuiltLayers = savedLayers.map((layer, layerIndex) => ({
          name: layer?.name || `Capa ${layerIndex + 1}`,
          visible: layer?.visible !== false,
          opacity: clamp(layer?.opacity ?? 1, 0, 1),
          data: layer?.data || layer?.dataUrl || layer?.src || blankCanvas().toDataURL('image/png')
        }));
      } else rebuiltLayers = imageLayerSnapshot(baseImage, 'Sprite');
    }
    rebuiltFrames.push(rebuiltLayers);
  }

  frames = rebuiltFrames.length ? rebuiltFrames : [imageLayerSnapshot(firstImage, 'Sprite')];
  frameIndex = 0;
  activeLayer = 0;
  fps = clamp(object.animation?.fps ?? 8, 1, 30);
  loopAnimation = object.animation?.loop !== false;
  await loadFrame(frames[0]);
  if (session !== spriteSession || !modalEl) return false;

  const widthInput = modalEl.querySelector('[data-width]');
  const heightInput = modalEl.querySelector('[data-height]');
  if (widthInput) widthInput.value = spriteWidth;
  if (heightInput) heightInput.value = spriteHeight;
  const fpsInput = modalEl.querySelector('[data-fps]');
  if (fpsInput) fpsInput.value = fps;
  const loopInput = modalEl.querySelector('[data-loop]');
  if (loopInput) loopInput.checked = loopAnimation;
  const dimensions = modalEl.querySelector('[data-dimensions]');
  if (dimensions) dimensions.textContent = `${spriteWidth}×${spriteHeight}px`;
  setZoom();
  renderTimeline();
  drawPreviewFrame(0);
  updateFrameLabel();
  return true;
}

function updateFrameLabel() {
  if (!modalEl) return;
  const label = modalEl.querySelector('[data-frame-label]');
  if (label) label.textContent = `Fotograma ${frameIndex + 1} de ${frames.length}`;
  const prev = modalEl.querySelector('[data-frame-prev]');
  const next = modalEl.querySelector('[data-frame-next]');
  const remove = modalEl.querySelector('[data-frame-delete]');
  const moveLeft = modalEl.querySelector('[data-frame-move-left]');
  const moveRight = modalEl.querySelector('[data-frame-move-right]');
  if (prev) prev.disabled = frameIndex <= 0;
  if (next) next.disabled = frameIndex >= frames.length - 1;
  if (remove) remove.disabled = frames.length <= 1;
  if (moveLeft) moveLeft.disabled = frameIndex <= 0;
  if (moveRight) moveRight.disabled = frameIndex >= frames.length - 1;
  const previewButton = modalEl.querySelector('[data-preview-play]');
  if (previewButton) previewButton.disabled = frames.length < 2;
}

function renderLayers() {
  if (!modalEl) return;
  const list = modalEl.querySelector('[data-layers]');
  if (!list) return;
  list.innerHTML = layers.map((layer, index) => `<div class="layer-row ${index === activeLayer ? 'active' : ''}" data-layer="${index}"><input type="checkbox" data-layer-visible="${index}" ${layer.visible ? 'checked' : ''}><span>${escapeHTML(layer.name)}</span></div>`).join('');
  list.querySelectorAll('[data-layer]').forEach(row => row.onclick = event => {
    if (event.target.matches('input')) return;
    activeLayer = Number(row.dataset.layer);
    renderLayers();
  });
  list.querySelectorAll('[data-layer-visible]').forEach(input => input.onchange = () => {
    pushSpriteUndo();
    layers[Number(input.dataset.layerVisible)].visible = input.checked;
    paint();
    saveCurrentFrame();
  });
  const opacity = modalEl.querySelector('[data-layer-opacity]');
  if (opacity) opacity.value = layers[activeLayer]?.opacity ?? 1;
}

async function snapshotToDataURL(snapshot) {
  const output = blankCanvas();
  const context = output.getContext('2d');
  for (const layer of snapshot || []) {
    if (layer.visible === false || !layer.data) continue;
    const image = await loadImage(layer.data);
    if (!image) continue;
    context.globalAlpha = layer.opacity ?? 1;
    context.drawImage(image, 0, 0, spriteWidth, spriteHeight);
  }
  context.globalAlpha = 1;
  return output.toDataURL('image/png');
}

async function renderTimeline() {
  if (!modalEl) return;
  const version = ++timelineRenderVersion;
  const timeline = modalEl.querySelector('[data-timeline]');
  if (!timeline) return;
  timeline.innerHTML = '';
  for (let index = 0; index < frames.length; index++) {
    const button = document.createElement('button');
    button.type = 'button';
    button.className = `sprite-frame ${index === frameIndex ? 'active' : ''}`;
    button.draggable = true;
    button.title = `Ir al fotograma ${index + 1}`;
    button.setAttribute('aria-label', `Fotograma ${index + 1}. Arrastra para cambiar su orden`);
    button.dataset.frameIndex = String(index);
    button.innerHTML = `<span class="sprite-frame-number">${index + 1}</span><img alt="Fotograma ${index + 1}"><span class="sprite-frame-drag" aria-hidden="true">⠿</span>`;
    button.onclick = () => changeFrameTo(index);
    button.addEventListener('dragstart', event => {
      if (!event.dataTransfer) return;
      event.dataTransfer.effectAllowed = 'move';
      event.dataTransfer.setData('application/x-makeyworld-frame', String(index));
      event.dataTransfer.setData('text/plain', String(index));
      button.classList.add('dragging');
    });
    button.addEventListener('dragend', () => button.classList.remove('dragging'));
    button.addEventListener('dragover', event => {
      event.preventDefault();
      if (event.dataTransfer) event.dataTransfer.dropEffect = 'move';
    });
    button.addEventListener('drop', event => {
      event.preventDefault();
      const payload = event.dataTransfer?.getData('application/x-makeyworld-frame') || event.dataTransfer?.getData('text/plain');
      if (payload == null || payload === '') return;
      const from = Number(payload);
      if (Number.isInteger(from)) reorderFrame(from, index);
    });
    timeline.append(button);
    const image = button.querySelector('img');
    const data = await snapshotToDataURL(frames[index]);
    if (version !== timelineRenderVersion || !modalEl || !timeline.isConnected) return;
    image.src = data;
  }
}

async function drawPreviewFrame(index) {
  if (!previewCtx || !frames.length) return;
  const version = ++previewRenderVersion;
  const cached = previewImages[index];
  if (cached && previewCtx && previewCanvas) {
    previewCtx.clearRect(0, 0, previewCanvas.width, previewCanvas.height);
    previewCtx.drawImage(cached, 0, 0, previewCanvas.width, previewCanvas.height);
    return;
  }
  const frame = frames[index] || frames[0];
  const image = await loadImage(await snapshotToDataURL(frame));
  if (version !== previewRenderVersion || !previewCtx || !previewCanvas) return;
  previewCtx.clearRect(0, 0, previewCanvas.width, previewCanvas.height);
  if (image) previewCtx.drawImage(image, 0, 0, previewCanvas.width, previewCanvas.height);
}

function stopPreview() {
  previewRequestVersion++;
  previewLoading = false;
  if (previewTimer) clearInterval(previewTimer);
  previewTimer = null;
  previewPlaying = false;
  const button = modalEl?.querySelector('[data-preview-play]');
  if (button) {
    button.textContent = '▶ Vista previa';
    button.disabled = frames.length < 2;
  }
}

async function startPreview() {
  if (previewPlaying || previewLoading || frames.length < 2) return;
  previewLoading = true;
  const requestVersion = ++previewRequestVersion;
  const button = modalEl?.querySelector('[data-preview-play]');
  if (button) { button.disabled = true; button.textContent = 'Cargando…'; }
  saveCurrentFrame();
  const session = spriteSession;
  const cacheVersion = previewCacheVersion;
  const snapshots = structuredClone(frames);
  try {
    const images = await Promise.all(snapshots.map(async snapshot => {
      const source = await snapshotToDataURL(snapshot);
      return loadImage(source);
    }));
    if (requestVersion !== previewRequestVersion || session !== spriteSession || !modalEl || cacheVersion !== previewCacheVersion) return;
    previewImages = images;
    previewPlaying = true;
    previewIndex = 0;
    if (button) { button.textContent = 'Ⅱ Pausar'; button.disabled = false; }
    drawPreviewImage(previewIndex);
    previewTimer = setInterval(() => {
      previewIndex += 1;
      if (previewIndex >= frames.length) {
        if (!loopAnimation) {
          previewIndex = frames.length - 1;
          drawPreviewImage(previewIndex);
          stopPreview();
          return;
        }
        previewIndex = 0;
      }
      drawPreviewImage(previewIndex);
    }, 1000 / clamp(fps, 1, 30));
  } finally {
    if (requestVersion === previewRequestVersion) {
      previewLoading = false;
      const currentButton = modalEl?.querySelector('[data-preview-play]');
      if (currentButton && !previewPlaying) {
        currentButton.disabled = frames.length < 2;
        currentButton.textContent = '▶ Vista previa';
      }
    }
  }
}

function drawPreviewImage(index) {
  const image = previewImages[index];
  if (!image || !previewCtx || !previewCanvas) return;
  previewCtx.clearRect(0, 0, previewCanvas.width, previewCanvas.height);
  previewCtx.imageSmoothingEnabled = false;
  previewCtx.drawImage(image, 0, 0, previewCanvas.width, previewCanvas.height);
}

function drawShape(context, start, end) {
  context.strokeStyle = color;
  context.lineWidth = 1;
  context.beginPath();
  if (tool === 'line') {
    context.moveTo(start.x + 0.5, start.y + 0.5);
    context.lineTo(end.x + 0.5, end.y + 0.5);
  } else if (tool === 'ellipse') {
    const left = Math.min(start.x, end.x), top = Math.min(start.y, end.y);
    const width = Math.abs(end.x - start.x), height = Math.abs(end.y - start.y);
    context.ellipse(left + width / 2 + 0.5, top + height / 2 + 0.5, Math.max(.5, width / 2), Math.max(.5, height / 2), 0, 0, Math.PI * 2);
  } else {
    context.rect(start.x + 0.5, start.y + 0.5, end.x - start.x, end.y - start.y);
  }
  context.stroke();
}

function drawShapePreview(point) {
  paint();
  const context = canvasCtx;
  context.save();
  drawShape(context, drawing.start, point);
  context.restore();
}

function pointerDown(event) {
  if (!canvas || !layers[activeLayer]) return;
  canvas.setPointerCapture?.(event.pointerId);
  const point = pointerPoint(event);
  if (tool === 'fill') {
    pushSpriteUndo();
    bucketFill(point.x, point.y);
    paint();
    saveCurrentFrame();
    return;
  }
  if (tool === 'eyedropper') {
    const data = layers[activeLayer].canvas.getContext('2d').getImageData(point.x, point.y, 1, 1).data;
    color = `#${[...data.slice(0, 3)].map(value => value.toString(16).padStart(2, '0')).join('')}`;
    modalEl.querySelector('[data-color]').value = color;
    return;
  }
  drawing = { start: point, last: point };
  canvas.focus();
  pushSpriteUndo();
  if (tool === 'pencil' || tool === 'eraser') {
    plotPixel(point.x, point.y);
    paint();
  }
}

function pointerMove(event) {
  if (!drawing) return;
  const point = pointerPoint(event);
  if (tool === 'pencil' || tool === 'eraser') {
    linePixels(drawing.last, point);
    drawing.last = point;
    paint();
  } else if (['line', 'rect', 'ellipse'].includes(tool)) {
    drawShapePreview(point);
  }
}

function pointerUp(event) {
  if (!drawing) return;
  const point = pointerPoint(event);
  if (['line', 'rect', 'ellipse'].includes(tool)) drawShape(layers[activeLayer].canvas.getContext('2d'), drawing.start, point);
  drawing = null;
  paint();
  saveCurrentFrame();
  drawPreviewFrame(frameIndex);
}

function changeFrameTo(index) {
  if (index < 0 || index >= frames.length || index === frameIndex) return;
  stopPreview();
  saveCurrentFrame();
  frameIndex = index;
  loadFrame(frames[frameIndex]);
  drawPreviewFrame(frameIndex);
}

function changeFrame(delta) { changeFrameTo(frameIndex + delta); }

function reorderFrame(from, to) {
  if (!Number.isInteger(from) || !Number.isInteger(to) || from < 0 || to < 0 ||
      from >= frames.length || to >= frames.length || from === to) return false;
  stopPreview();
  saveCurrentFrame();
  pushSpriteUndo();
  frameIndex = movedFrameIndex(frameIndex, from, to);
  frames = moveFrame(frames, from, to);
  loadFrame(frames[frameIndex]);
  renderTimeline();
  drawPreviewFrame(frameIndex);
  updateFrameLabel();
  return true;
}

function moveCurrentFrame(direction) {
  reorderFrame(frameIndex, frameIndex + direction);
}

function addBlankFrame() {
  stopPreview();
  saveCurrentFrame();
  pushSpriteUndo();
  const blank = layers.map(layer => ({
    name: layer.name,
    visible: layer.visible,
    opacity: layer.opacity,
    data: blankCanvas().toDataURL('image/png')
  }));
  frames.splice(frameIndex + 1, 0, blank);
  frameIndex += 1;
  loadFrame(frames[frameIndex]);
  drawPreviewFrame(frameIndex);
}

function duplicateFrame() {
  stopPreview();
  saveCurrentFrame();
  pushSpriteUndo();
  frames.splice(frameIndex + 1, 0, structuredClone(frames[frameIndex]));
  frameIndex += 1;
  loadFrame(frames[frameIndex]);
  drawPreviewFrame(frameIndex);
}

function deleteFrame() {
  if (frames.length <= 1) return;
  stopPreview();
  saveCurrentFrame();
  pushSpriteUndo();
  frames.splice(frameIndex, 1);
  frameIndex = Math.min(frameIndex, frames.length - 1);
  loadFrame(frames[frameIndex]);
  drawPreviewFrame(frameIndex);
}

async function resizeSprite(width, height) {
  const nextWidth = clamp(width, 8, 256);
  const nextHeight = clamp(height, 8, 256);
  if (nextWidth === spriteWidth && nextHeight === spriteHeight) return;
  stopPreview();
  saveCurrentFrame();
  pushSpriteUndo();
  const oldWidth = spriteWidth, oldHeight = spriteHeight;
  spriteWidth = nextWidth;
  spriteHeight = nextHeight;
  const resizedFrames = [];
  for (const frame of frames) {
    const resized = [];
    for (const layer of frame) {
      const source = await loadImage(layer.data);
      const target = blankCanvas();
      if (source) target.getContext('2d').drawImage(source, 0, 0, nextWidth, nextHeight);
      resized.push({ ...layer, data: target.toDataURL('image/png') });
    }
    resizedFrames.push(resized);
  }
  frames = resizedFrames;
  canvas.width = spriteWidth;
  canvas.height = spriteHeight;
  frameIndex = Math.min(frameIndex, frames.length - 1);
  await loadFrame(frames[frameIndex]);
  setZoom();
  modalEl.querySelector('[data-width]').value = nextWidth;
  modalEl.querySelector('[data-height]').value = nextHeight;
  const dimensions = modalEl.querySelector('[data-dimensions]');
  if (dimensions) dimensions.textContent = `${nextWidth}×${nextHeight}px`;
  updateFrameLabel();
  drawPreviewFrame(frameIndex);
  toast(`Lienzo redimensionado a ${oldWidth}×${oldHeight} → ${nextWidth}×${nextHeight}.`, 'success');
}

function moveActiveLayer(direction) {
  const next = activeLayer + direction;
  if (next < 0 || next >= layers.length) return;
  pushSpriteUndo();
  [layers[activeLayer], layers[next]] = [layers[next], layers[activeLayer]];
  activeLayer = next;
  renderLayers();
  paint();
  saveCurrentFrame();
}

function transformActiveLayer(mode) {
  const layer = layers[activeLayer];
  if (!layer) return;
  pushSpriteUndo();
  const source = layer.canvas;
  const target = blankCanvas(spriteWidth, spriteHeight);
  const context = target.getContext('2d');
  context.imageSmoothingEnabled = false;
  if (mode === 'horizontal') {
    context.translate(spriteWidth, 0);
    context.scale(-1, 1);
  } else {
    context.translate(0, spriteHeight);
    context.scale(1, -1);
  }
  context.drawImage(source, 0, 0);
  layer.canvas = target;
  paint();
  saveCurrentFrame();
  drawPreviewFrame(frameIndex);
}

function clearActiveLayer() {
  const layer = layers[activeLayer];
  if (!layer) return;
  pushSpriteUndo();
  layer.canvas.getContext('2d').clearRect(0, 0, spriteWidth, spriteHeight);
  paint();
  saveCurrentFrame();
  drawPreviewFrame(frameIndex);
}

function importSpriteImage() {
  const input = document.createElement('input');
  input.type = 'file';
  input.accept = 'image/*';
  input.onchange = async () => {
    const file = input.files?.[0];
    if (!file) return;
    const url = URL.createObjectURL(file);
    const image = await loadImage(url);
    URL.revokeObjectURL(url);
    if (!image) { toast('No se ha podido abrir esa imagen.', 'error'); return; }
    pushSpriteUndo();
    const context = layers[activeLayer].canvas.getContext('2d');
    context.clearRect(0, 0, spriteWidth, spriteHeight);
    context.drawImage(image, 0, 0, spriteWidth, spriteHeight);
    paint();
    saveCurrentFrame();
    drawPreviewFrame(frameIndex);
  };
  input.click();
}

function downloadDataURL(url, filename) {
  const anchor = document.createElement('a');
  anchor.href = url;
  anchor.download = filename;
  anchor.click();
}

async function exportSpriteSheet() {
  saveCurrentFrame();
  const sheet = document.createElement('canvas');
  sheet.width = spriteWidth * frames.length;
  sheet.height = spriteHeight;
  const context = sheet.getContext('2d');
  for (let index = 0; index < frames.length; index++) {
    const data = await snapshotToDataURL(frames[index]);
    const image = await loadImage(data);
    if (image) context.drawImage(image, index * spriteWidth, 0);
  }
  downloadDataURL(sheet.toDataURL('image/png'), 'makey-spritesheet.png');
}

function buildModal() {
  const backdrop = document.createElement('div');
  backdrop.className = 'modal-backdrop sprite-backdrop';
  backdrop.innerHTML = `<section class="modal sprite-modal" role="dialog" aria-modal="true" aria-label="Makey Pixel Studio">
    <header class="modal-head"><span>Makey Pixel Studio <span class="pill">Pixel art + animación</span></span><button class="btn ghost icon" data-close aria-label="Cerrar">×</button></header>
    <div class="sprite-size-controls"><button class="btn small" data-sprite-undo title="Deshacer dibujo" disabled>↶</button><button class="btn small" data-sprite-redo title="Rehacer dibujo" disabled>↷</button><span class="muted tiny">Lienzo</span> W <input type="number" data-width value="${spriteWidth}" min="8" max="256"> H <input type="number" data-height value="${spriteHeight}" min="8" max="256"><button class="btn small" data-resize>Aplicar tamaño</button><span class="muted tiny">Zoom</span><input type="range" min="4" max="24" value="${zoom}" data-zoom><span class="muted tiny" data-dimensions>${spriteWidth}×${spriteHeight}px</span></div>
    <div class="sprite-workspace">
      <div class="sprite-tools">${[['pencil','✎','Lápiz'],['eraser','▱','Goma'],['fill','▨','Relleno'],['eyedropper','⌖','Cuentagotas'],['line','╱','Línea'],['rect','□','Rectángulo'],['ellipse','◯','Elipse']].map(([id, icon, label]) => `<button class="btn icon ${id === tool ? 'selected' : ''}" title="${label}" aria-label="${label}" data-tool="${id}">${icon}</button>`).join('')}<div class="divider"></div><input type="color" data-color value="${color}" title="Color" style="width:34px;height:34px;padding:2px;border:0;background:transparent"><label class="tiny muted">Tamaño</label><input type="range" min="1" max="8" value="${brushSize}" data-brush style="width:100%"><div class="divider"></div><button class="btn small" data-flip-h title="Voltear horizontalmente">↔ Voltear H</button><button class="btn small" data-flip-v title="Voltear verticalmente">↕ Voltear V</button><button class="btn small danger" data-clear-layer>Limpiar capa</button><div class="tool-hint">B: lápiz · E: goma · G: relleno · Ctrl+Z: deshacer</div></div>
      <div class="sprite-canvas-wrap"><canvas class="sprite-canvas" data-canvas aria-label="Lienzo de píxeles" tabindex="0"></canvas></div>
      <aside class="sprite-right">
        <div class="section-head sprite-section-head">Capas <button class="btn small" data-add-layer>＋</button></div><div data-layers></div><div class="field"><label>Opacidad de capa</label><input type="range" min="0" max="1" step="0.05" data-layer-opacity></div><div class="tool-group"><button class="btn small" data-layer-up title="Subir capa">↑ Capa</button><button class="btn small" data-layer-down title="Bajar capa">↓ Capa</button></div><button class="btn small" data-rename-layer>Renombrar</button> <button class="btn small danger" data-remove-layer>Eliminar</button>
        <div class="divider"></div><div class="section-head sprite-section-head">Paleta rápida</div><div class="swatches">${['#ff8a24','#ffffff','#111827','#e95d5d','#65bf91','#6197ed','#f4d35e','#a78bfa','#f6a5c0','#7c5c44','#626a76','#000000'].map(value => `<button class="swatch" style="background:${value}" data-swatch="${value}" aria-label="Color ${value}"></button>`).join('')}</div>
        <div class="divider"></div><div class="section-head sprite-section-head">Vista previa</div><div class="sprite-preview-wrap"><canvas data-preview width="96" height="96"></canvas></div><div class="tool-group sprite-preview-controls"><button class="btn small" data-preview-play>▶ Vista previa</button><label class="tiny muted">FPS <input type="number" data-fps min="1" max="30" value="${fps}"></label></div><label class="tiny muted sprite-loop"><input type="checkbox" data-loop ${loopAnimation ? 'checked' : ''}> Repetir animación</label>
      </aside>
    </div>
    <div class="sprite-timeline-head"><strong>Fotogramas</strong><span class="tiny muted" data-frame-label></span><div class="sprite-frame-actions"><button class="btn small" data-frame-add>＋ Vacío</button><button class="btn small" data-frame-duplicate>Duplicar</button><button class="btn small danger" data-frame-delete>Eliminar</button><button class="btn small" data-frame-prev title="Fotograma anterior">← Ver</button><button class="btn small" data-frame-next title="Fotograma siguiente">Ver →</button><button class="btn small" data-frame-move-left title="Mover el fotograma a la izquierda">⇦ Orden</button><button class="btn small" data-frame-move-right title="Mover el fotograma a la derecha">Orden ⇨</button></div></div>
    <div class="sprite-timeline" data-timeline></div>
    <div class="sprite-bottom"><button class="btn small" data-import-sprite>Importar imagen</button><button class="btn small" data-export-sprite>Exportar PNG</button><button class="btn small" data-export-sheet>Exportar spritesheet</button><span class="muted tiny sprite-save-hint">Se guardará en el objeto seleccionado.</span><button class="btn primary" data-use-sprite>Guardar en el juego</button></div>
  </section>`;
  document.body.append(backdrop);
  return backdrop;
}

function bindModal() {
  const close = () => {
    spriteSession++;
    stopPreview();
    drawing = null;
    modalEl?.remove();
    modalEl = null;
    timelineRenderVersion++;
    previewRenderVersion++;
    canvas = null;
    canvasCtx = null;
    previewCanvas = null;
    previewCtx = null;
  };
  modalEl.querySelector('[data-close]').onclick = close;
  modalEl.addEventListener('pointerdown', event => { if (event.target === modalEl) close(); });
  modalEl.addEventListener('keydown', event => {
    const mod = event.ctrlKey || event.metaKey;
    const targetTag = document.activeElement?.tagName;
    if (mod && ['z', 'y'].includes(event.key.toLowerCase()) && !['INPUT', 'TEXTAREA', 'SELECT'].includes(targetTag)) {
      event.preventDefault();
      event.stopPropagation();
      if (event.key.toLowerCase() === 'z' && event.shiftKey) applySpriteHistory(spriteRedoStack, spriteUndoStack);
      else if (event.key.toLowerCase() === 'z') applySpriteHistory(spriteUndoStack, spriteRedoStack);
      else applySpriteHistory(spriteRedoStack, spriteUndoStack);
      return;
    }
    if (event.altKey && event.key === 'ArrowLeft') {
      event.preventDefault();
      moveCurrentFrame(-1);
      return;
    }
    if (event.altKey && event.key === 'ArrowRight') {
      event.preventDefault();
      moveCurrentFrame(1);
      return;
    }
    if (mod || ['INPUT', 'TEXTAREA', 'SELECT'].includes(targetTag) || event.altKey) return;
    const shortcuts = { b: 'pencil', e: 'eraser', g: 'fill', l: 'line', r: 'rect' };
    const nextTool = shortcuts[event.key.toLowerCase()];
    if (nextTool) {
      event.preventDefault();
      tool = nextTool;
      modalEl.querySelectorAll('[data-tool]').forEach(button => button.classList.toggle('selected', button.dataset.tool === tool));
    }
  });
  modalEl.querySelectorAll('[data-tool]').forEach(button => button.onclick = () => {
    tool = button.dataset.tool;
    modalEl.querySelectorAll('[data-tool]').forEach(item => item.classList.toggle('selected', item === button));
  });
  canvas.addEventListener('pointerdown', pointerDown);
  canvas.addEventListener('pointermove', pointerMove);
  canvas.addEventListener('pointerup', pointerUp);
  canvas.addEventListener('pointercancel', pointerUp);
  modalEl.querySelector('[data-sprite-undo]').onclick = () => applySpriteHistory(spriteUndoStack, spriteRedoStack);
  modalEl.querySelector('[data-sprite-redo]').onclick = () => applySpriteHistory(spriteRedoStack, spriteUndoStack);
  modalEl.querySelector('[data-flip-h]').onclick = () => transformActiveLayer('horizontal');
  modalEl.querySelector('[data-flip-v]').onclick = () => transformActiveLayer('vertical');
  modalEl.querySelector('[data-clear-layer]').onclick = clearActiveLayer;
  modalEl.querySelector('[data-layer-up]').onclick = () => moveActiveLayer(-1);
  modalEl.querySelector('[data-layer-down]').onclick = () => moveActiveLayer(1);
  modalEl.querySelector('[data-color]').oninput = event => { color = event.target.value; };
  modalEl.querySelector('[data-brush]').oninput = event => { brushSize = Number(event.target.value); };
  modalEl.querySelector('[data-zoom]').oninput = event => { zoom = Number(event.target.value); setZoom(); };
  modalEl.querySelectorAll('[data-swatch]').forEach(button => button.onclick = () => {
    color = button.dataset.swatch;
    modalEl.querySelector('[data-color]').value = color;
  });
  modalEl.querySelector('[data-add-layer]').onclick = () => {
    pushSpriteUndo();
    layers.push(makeLayer(`Capa ${layers.length + 1}`));
    activeLayer = layers.length - 1;
    renderLayers(); paint(); saveCurrentFrame();
  };
  modalEl.querySelector('[data-remove-layer]').onclick = () => {
    if (layers.length < 2) { toast('Debe quedar al menos una capa.'); return; }
    pushSpriteUndo();
    layers.splice(activeLayer, 1);
    activeLayer = Math.max(0, activeLayer - 1);
    renderLayers(); paint(); saveCurrentFrame();
  };
  modalEl.querySelector('[data-rename-layer]').onclick = () => {
    const name = prompt('Nombre de la capa:', layers[activeLayer].name);
    if (name?.trim()) { pushSpriteUndo(); layers[activeLayer].name = name.trim(); renderLayers(); saveCurrentFrame(); }
  };
  modalEl.querySelector('[data-layer-opacity]').onpointerdown = () => pushSpriteUndo();
  modalEl.querySelector('[data-layer-opacity]').onkeydown = () => pushSpriteUndo();
  modalEl.querySelector('[data-layer-opacity]').oninput = event => {
    layers[activeLayer].opacity = Number(event.target.value);
    paint(); saveCurrentFrame();
  };
  modalEl.querySelector('[data-resize]').onclick = () => resizeSprite(modalEl.querySelector('[data-width]').value, modalEl.querySelector('[data-height]').value);
  modalEl.querySelector('[data-import-sprite]').onclick = importSpriteImage;
  modalEl.querySelector('[data-export-sprite]').onclick = () => {
    saveCurrentFrame();
    downloadDataURL(composite().toDataURL('image/png'), 'makey-sprite.png');
  };
  modalEl.querySelector('[data-export-sheet]').onclick = exportSpriteSheet;
  modalEl.querySelector('[data-frame-add]').onclick = addBlankFrame;
  modalEl.querySelector('[data-frame-duplicate]').onclick = duplicateFrame;
  modalEl.querySelector('[data-frame-delete]').onclick = deleteFrame;
  modalEl.querySelector('[data-frame-prev]').onclick = () => changeFrame(-1);
  modalEl.querySelector('[data-frame-next]').onclick = () => changeFrame(1);
  modalEl.querySelector('[data-frame-move-left]').onclick = () => moveCurrentFrame(-1);
  modalEl.querySelector('[data-frame-move-right]').onclick = () => moveCurrentFrame(1);
  modalEl.querySelector('[data-preview-play]').onclick = () => previewPlaying ? stopPreview() : startPreview();
  modalEl.querySelector('[data-fps]').onchange = event => {
    fps = clamp(event.target.value, 1, 30);
    event.target.value = fps;
    if (previewPlaying) { stopPreview(); startPreview(); }
  };
  modalEl.querySelector('[data-loop]').onchange = event => { loopAnimation = event.target.checked; };
  modalEl.querySelector('[data-use-sprite]').onclick = saveSpriteToProject;
}

async function saveSpriteToProject() {
  if (artworkLoadFailed) { toast('No se puede guardar porque el sprite original no se pudo cargar.', 'error'); return; }
  if (!state.project) { toast('No hay ningún proyecto abierto.', 'error'); return; }
  stopPreview();
  saveCurrentFrame();
  const session = spriteSession;
  const objectId = targetObjectId;
  const frameSnapshots = frames.map(frame => structuredClone(frame));
  const savedWidth = spriteWidth, savedHeight = spriteHeight, savedFps = fps, savedLoop = loopAnimation;
  const frameSources = [];
  for (const frame of frameSnapshots) {
    frameSources.push(await snapshotToDataURL(frame));
    if (session !== spriteSession) return;
  }
  if (!frameSources.length) return;
  const object = objectId ? state.project?.scenes.flatMap(scene => scene.objects).find(item => item.id === objectId) || null : null;
  if (objectId && !object) { toast('El objeto que estabas editando ya no existe. No se ha guardado.', 'error'); return; }
  record('Guardar sprite');
  const asset = addDataAsset(`${(object?.name || 'sprite').replace(/[^a-z0-9_-]+/gi, '-').toLowerCase()}-${Date.now()}.png`, frameSources[0]);
  const animation = frameSources.length > 1 ? {
    width: savedWidth,
    height: savedHeight,
    fps: clamp(savedFps, 1, 30),
    loop: savedLoop,
    frames: frameSources.map((sprite, index) => ({ sprite, layers: frameSnapshots[index] }))
  } : null;
  if (object) {
    object.sprite = asset.dataUrl;
    object.spriteAssetId = asset.id;
    object.spriteLayers = frameSnapshots[0] || [];
    object.color = '#ffffff';
    if (animation) object.animation = animation;
    else delete object.animation;
    state.select(object.id);
    state.touch(animation ? 'Sprite y animación guardados' : 'Sprite guardado');
    toast(animation ? `Sprite y animación de ${frameSources.length} fotogramas guardados.` : 'Sprite actualizado.', 'success');
  } else {
    const created = addObject('rect', {
      name: 'Sprite nuevo', width: savedWidth, height: savedHeight,
      sprite: asset.dataUrl, spriteAssetId: asset.id, spriteLayers: frameSnapshots[0] || [], color: '#ffffff',
      ...(animation ? { animation } : {})
    });
    toast(created ? `Creado ${created.name}${animation ? ` con ${frameSources.length} fotogramas` : ''}.` : 'No se pudo crear el sprite.', created ? 'success' : 'error');
  }
  spriteSession++;
  modalEl?.remove();
  modalEl = null;
  timelineRenderVersion++;
  previewRenderVersion++;
  canvas = null;
  canvasCtx = null;
  previewCanvas = null;
  previewCtx = null;
}

export async function openSpriteEditor({ width = 32, height = 32 } = {}) {
  const session = ++spriteSession;
  if (!state.project) { toast('Primero crea o abre un proyecto.'); return; }
  stopPreview();
  const selected = state.selected[0] || null;
  targetObjectId = selected?.id || null;
  spriteWidth = clamp(width, 8, 256);
  spriteHeight = clamp(height, 8, 256);
  zoom = 12;
  brushSize = 1;
  layers = [makeLayer('Capa 1')];
  activeLayer = 0;
  frames = [captureFrame()];
  spriteUndoStack = [];
  spriteRedoStack = [];
  frameIndex = 0;
  tool = 'pencil';
  color = '#ff8a24';
  drawing = null;
  artworkLoadFailed = false;
  fps = clamp(selected?.animation?.fps ?? 8, 1, 30);
  loopAnimation = selected?.animation?.loop !== false;

  modalEl?.remove();
  modalEl = buildModal();
  canvas = modalEl.querySelector('[data-canvas]');
  canvas.width = spriteWidth;
  canvas.height = spriteHeight;
  canvasCtx = canvas.getContext('2d');
  previewCanvas = modalEl.querySelector('[data-preview]');
  previewCtx = previewCanvas.getContext('2d');
  bindModal();
  updateSpriteHistoryButtons();
  setZoom();
  renderLayers();
  updateFrameLabel();
  await loadExistingArtwork(selected, session);
  if (session !== spriteSession || !modalEl) return;
  if (!selected) {
    frames = [captureFrame()];
    saveCurrentFrame();
    renderTimeline();
    drawPreviewFrame(0);
  }
  const hint = modalEl.querySelector('.sprite-save-hint');
  if (hint) hint.textContent = selected ? `Editando: ${selected.name}` : 'Crea un sprite nuevo y añádelo a la escena.';
  return modalEl;
}

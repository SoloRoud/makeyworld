/** Move one animation frame to a new timeline index without mutating the input. */
export function moveFrame(frames, from, to) {
  if (!Array.isArray(frames)) throw new TypeError('frames debe ser un array');
  if (!Number.isInteger(from) || !Number.isInteger(to) || from < 0 || to < 0 ||
      from >= frames.length || to >= frames.length) return frames.slice();
  if (from === to) return frames.slice();
  const result = frames.slice();
  const [moving] = result.splice(from, 1);
  result.splice(to, 0, moving);
  return result;
}

/** Keep the active frame selected when another frame is moved around it. */
export function movedFrameIndex(activeIndex, from, to) {
  if (activeIndex === from) return to;
  if (from < activeIndex && to >= activeIndex) return activeIndex - 1;
  if (from > activeIndex && to <= activeIndex) return activeIndex + 1;
  return activeIndex;
}

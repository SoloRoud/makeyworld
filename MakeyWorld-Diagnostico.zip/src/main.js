import { startApp } from './core/app.js';
const root=document.querySelector('#app');
startApp(root).catch(error=>{console.error(error);root.innerHTML=`<div class="boot-screen"><h2>No se pudo iniciar MakeyWorld</h2><p>${String(error.message||error)}</p><button class="btn" onclick="location.reload()">Recargar</button></div>`;});
if('serviceWorker' in navigator && location.protocol.startsWith('http')){window.addEventListener('load',()=>navigator.serviceWorker.register('./service-worker.js').catch(error=>console.warn('PWA no disponible:',error)));}

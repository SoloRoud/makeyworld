export const tutorials=[
 ['Crear mi primer proyecto','En la pantalla de inicio pulsa Crear proyecto, escribe un nombre y elige la plantilla Plataformas 2D.'],
 ['Crear un personaje','En el editor pulsa Jugador en la barra superior. Después selecciónalo para cambiar su posición, tamaño y color.'],
 ['Importar un sprite','Abre Recursos → Importar o arrastra una imagen a MakeyWorld. Selecciona un objeto y pulsa el recurso para asignarlo. Después puedes abrir Pixel Studio desde el Inspector para editar ese mismo sprite sin perder el dibujo.'],
 ['Crear una animación','Selecciona un objeto y abre Pixel Studio desde el Inspector. Dibuja el primer fotograma, añade o duplica fotogramas, ajusta los FPS y pulsa Guardar en el juego. En Play la animación se reproducirá automáticamente.'],
 ['Crear un escenario','Añade plataformas desde la barra superior y arrástralas en el lienzo. Activa la cuadrícula y el ajuste para alinear.'],
 ['Añadir movimiento','El objeto de tipo Jugador incluye control de teclado en el modo Play: A/D o flechas para moverse y Espacio/W/↑ para saltar.'],
 ['Crear colisiones','Selecciona una plataforma y activa Física + Colisionable. En el jugador activa Física y Gravedad.'],
 ['Añadir enemigos','Pulsa Enemigo. Durante Play el enemigo se desplaza hacia el jugador cuando está cerca.'],
 ['Crear monedas','Añade una Moneda. Al tocarla el jugador suma una moneda y diez puntos automáticamente.'],
 ['Crear un menú','Añade objetos de texto y configura escenas. El cambio de escena se puede asociar con una regla visual.'],
 ['Exportar mi videojuego','Pulsa Exportar HTML5 para descargar un archivo autónomo que se puede publicar en un alojamiento estático.']
];
